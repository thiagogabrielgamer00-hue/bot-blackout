# Bot — Blackout Community 3.0

Veja o `README.md` na raiz do projeto para instruções de deploy e compilação.
Este arquivo lista todos os comandos.

## RP

- `/roletar atributo:<id>` — sorteia um valor para um atributo do tema ativo (gasta 1 giro).
- `/perfil [usuario]` — mostra o perfil de RP no tema ativo.
- `/tema listar|usar|criar|copiar|remover`
- `/atributo adicionar|remover|opcao-adicionar|opcao-remover|opcao-raridade|limite|listar`
- `/giros usuario atributo quantidade` — define quantos giros um jogador tem.
- `/perfil-admin apagar|limpar-todos|limpar-tema|limpar-tudo`

## Vínculo de conta e cargo automático

- `/registrar nick:<seu-nick-no-servidor>` — vincula sua conta do Discord ao seu nick do Minecraft.
- `/desvincular` — remove seu próprio vínculo.
- `/vinculo [usuario]` — mostra o nick vinculado (o de outra pessoa exige o grupo `rp`).
- `/cargo-automatico ativar|atributo|comando|mapear|desmapear|listar|sincronizar|sincronizar-todos`
  — configura qual atributo do tema ativo concede um cargo (ex.: LuckPerms) e qual
  comando de console é executado no servidor quando ele é definido.

## Permissões

- `/permissao adicionar-cargo|remover-cargo|listar` (só o dono permanente)

## Moderação

- `/warn usuario motivo`
- `/warnings listar|limpar`
- `/mute usuario minutos [motivo]` / `/unmute usuario`
- `/kick usuario [motivo]`
- `/ban usuario [motivo]`
- `/limpar quantidade`

## Configuração

- `/config boas-vindas|boas-vindas-alternar|despedida|despedida-alternar|logs|ver`
- `/automod ativar|anti-link|anti-convite|anti-caps|anti-spam|palavra-adicionar|palavra-remover|cargo-isento|ver`
- `/nivel-cargo definir|remover|listar|alternar`
- `/verificacao configurar|desativar`

## Minecraft

- `/minecraft status` — consulta o servidor configurado (host/porta fixos no
  código; dá pra trocar em `Store.db.minecraftHost/Port` se precisar de outro
  servidor no futuro).
- `/minecraft bridge-canal canal:<#canal>` — define onde entrada/saída de
  jogadores do Minecraft são avisadas (só informativo, nunca entra no jogo).
- `/minecraft bridge-info` — mostra a URL e a chave que o plugin precisa no
  `config.yml` dele.
- `/minecraft bridge-regerar-chave` — invalida a chave atual e gera outra
  (use se desconfiar que ela vazou).
- `/minecraft anunciar mensagem:<texto>` — manda um aviso DELIBERADO pra
  dentro do jogo, marcado como aviso (não é espelho automático de chat — veja
  `minecraft-plugin/README.md` pra entender por que o bridge é assim).

## Diversão / utilidade

- `/embed titulo texto`
- `/enquete pergunta`
- `/avisar mensagem [titulo] [cargo] [usuario] [todos] [aqui] [imagem] [cor] [link] [botao] [link2] [botao2]`
- `/cargo dar|remover`
- `/userinfo [usuario]`, `/serverinfo`, `/avatar [usuario]`
- `/parceria painel|divulgar|listar|remover|estatisticas` e `/parceria canal-divulgacao|canal-analise|cargo-parceiro|cargo-ping|regras|alternar|ver` (veja o README da raiz)
- `/ticket abrir|fechar` (também tem botão "Fechar ticket" na mensagem)
- `/comando-custom criar|remover|listar|prefixo` — comandos de texto simples
  (ex.: digitar `!regras` no chat responde o texto configurado).
- `/cargo-reacao criar|adicionar-opcao` — menu de cargo por reação.
- `/sorteio criar|finalizar|rerolar` — sorteio com participação por botão.
- `/rank [usuario]`, `/rank-top` — sistema de XP por mensagem.

## Sobre o arquivo de dados

Tudo fica em `data/blackout-community.json`. É JSON puro, então em uma
emergência (por exemplo, um valor errado travando algo) dá pra abrir o
arquivo, corrigir manualmente e reiniciar o bot. Sempre pare o bot antes de
editar o arquivo na mão, e faça uma cópia de segurança antes.
