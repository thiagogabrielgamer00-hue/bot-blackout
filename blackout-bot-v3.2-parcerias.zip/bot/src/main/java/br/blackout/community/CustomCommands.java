package br.blackout.community;

import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;

final class CustomCommands {

    private CustomCommands() {}

    /** Retorna true se a mensagem era um comando customizado e já foi respondida. */
    static boolean handle(MessageReceivedEvent event) {
        if (event.getAuthor().isBot()) return false;
        String prefix = Store.db.customCommandPrefix;
        if (prefix == null || prefix.isBlank()) return false;
        String content = event.getMessage().getContentRaw();
        if (!content.startsWith(prefix)) return false;
        String name = content.substring(prefix.length()).trim().toLowerCase();
        // permite "!comando argumentos" reconhecendo só a primeira palavra
        int spaceIndex = name.indexOf(' ');
        if (spaceIndex > -1) name = name.substring(0, spaceIndex);
        String response = Store.db.customCommands.get(name);
        if (response == null) return false;
        event.getChannel().sendMessage(response).queue();
        return true;
    }

    static void manage(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_DIVERSAO)) return;
        String sub = e.getSubcommandName();
        switch (sub) {
            case "criar" -> {
                String name = e.getOption("nome").getAsString().trim().toLowerCase();
                Store.db.customCommands.put(name, e.getOption("resposta").getAsString());
                Store.save();
                Reply.of(e, "Comando `" + Store.db.customCommandPrefix + name + "` salvo.", true);
            }
            case "remover" -> {
                String name = e.getOption("nome").getAsString().trim().toLowerCase();
                Store.db.customCommands.remove(name);
                Store.save();
                Reply.of(e, "Comando removido.", true);
            }
            case "listar" -> {
                if (Store.db.customCommands.isEmpty()) {
                    Reply.of(e, "Nenhum comando customizado cadastrado.", true);
                    return;
                }
                StringBuilder text = new StringBuilder("**Comandos customizados (prefixo `" + Store.db.customCommandPrefix + "`):**\n");
                Store.db.customCommands.keySet().forEach(name -> text.append("• ").append(name).append("\n"));
                Reply.of(e, text.toString(), true);
            }
            case "prefixo" -> {
                Store.db.customCommandPrefix = e.getOption("prefixo").getAsString();
                Store.save();
                Reply.of(e, "Prefixo atualizado para `" + Store.db.customCommandPrefix + "`.", true);
            }
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }
}
