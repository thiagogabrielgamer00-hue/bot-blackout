package br.blackout.community;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.channel.ChannelType;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.build.SubcommandData;

import java.util.ArrayList;
import java.util.List;

/**
 * Registra todos os comandos de barra (/) do bot junto ao Discord.
 * O registro é GLOBAL: pode levar até ~1 hora para aparecer em todos os servidores
 * na primeira vez. Alterações depois costumam ser mais rápidas.
 */
final class CommandRegistry {

    private CommandRegistry() {}

    static void register(JDA jda) {
        List<CommandData> commands = new ArrayList<>();

        // ---------- RP: temas, atributos, roleta, perfil ----------
        commands.add(Commands.slash("roletar", "Rola um atributo configurado do tema atual")
                .addOption(OptionType.STRING, "atributo", "Ex.: cla, vila, raca", true));

        commands.add(Commands.slash("perfil", "Mostra o perfil de RP do tema atual")
                .addOption(OptionType.USER, "usuario", "Jogador (padrão: você)", false));

        commands.add(Commands.slash("tema", "Cria, seleciona e administra universos de RP")
                .addSubcommands(
                        new SubcommandData("listar", "Lista todos os temas"),
                        new SubcommandData("usar", "Ativa um tema existente")
                                .addOption(OptionType.STRING, "id", "ID do tema", true),
                        new SubcommandData("criar", "Cria um tema vazio")
                                .addOption(OptionType.STRING, "id", "ID sem espaços (ex.: naruto)", true)
                                .addOption(OptionType.STRING, "nome", "Nome exibido (ex.: Naruto RP)", true),
                        new SubcommandData("copiar", "Duplica a estrutura de campos de um tema para outro novo")
                                .addOption(OptionType.STRING, "origem", "ID do tema a copiar", true)
                                .addOption(OptionType.STRING, "novo-id", "ID do novo tema", true)
                                .addOption(OptionType.STRING, "novo-nome", "Nome exibido do novo tema", true),
                        new SubcommandData("remover", "Remove um tema (não pode ser o ativo)")
                                .addOption(OptionType.STRING, "id", "ID do tema", true)));

        commands.add(Commands.slash("atributo", "Configura os atributos (clã, raça, reino...) do tema ativo")
                .addSubcommands(
                        new SubcommandData("adicionar", "Cria um atributo novo no tema ativo")
                                .addOption(OptionType.STRING, "id", "Ex.: cla", true)
                                .addOption(OptionType.STRING, "nome", "Ex.: Clã", true),
                        new SubcommandData("remover", "Remove um atributo do tema ativo")
                                .addOption(OptionType.STRING, "id", "ID do atributo", true),
                        new SubcommandData("opcao-adicionar", "Adiciona uma opção de roleta a um atributo")
                                .addOption(OptionType.STRING, "atributo", "ID do atributo", true)
                                .addOption(OptionType.STRING, "valor", "Valor a adicionar", true),
                        new SubcommandData("opcao-remover", "Remove uma opção de um atributo")
                                .addOption(OptionType.STRING, "atributo", "ID do atributo", true)
                                .addOption(OptionType.STRING, "valor", "Valor a remover", true),
                        new SubcommandData("opcao-raridade", "Define a raridade (peso) de uma opção na roleta")
                                .addOption(OptionType.STRING, "atributo", "ID do atributo", true)
                                .addOption(OptionType.STRING, "valor", "Valor já existente", true)
                                .addOption(OptionType.INTEGER, "peso", "1 a 1000 (padrão 10). Menor = mais raro", true),
                        new SubcommandData("limite", "Define o tamanho máximo de um valor do atributo")
                                .addOption(OptionType.STRING, "atributo", "ID do atributo", true)
                                .addOption(OptionType.INTEGER, "maximo", "1 a 100 caracteres", true),
                        new SubcommandData("opcao-cargo", "Define um cargo do Discord dado automaticamente a quem tiver essa opção")
                                .addOption(OptionType.STRING, "atributo", "ID do atributo, ex.: reino", true)
                                .addOption(OptionType.STRING, "valor", "Valor já existente, ex.: Aethelgard", true)
                                .addOption(OptionType.ROLE, "cargo", "Cargo a conceder quando o jogador tiver esse valor", true),
                        new SubcommandData("opcao-cargo-remover", "Remove a associação de cargo de uma opção")
                                .addOption(OptionType.STRING, "atributo", "ID do atributo", true)
                                .addOption(OptionType.STRING, "valor", "Valor já existente", true),
                        new SubcommandData("listar", "Lista os atributos e opções do tema ativo")));

        commands.add(Commands.slash("giros", "Define quantos giros de roleta um jogador tem")
                .addOption(OptionType.USER, "usuario", "Jogador", true)
                .addOption(OptionType.STRING, "atributo", "ID do atributo ou 'todos'", true)
                .addOption(OptionType.INTEGER, "quantidade", "0 a 1000", true));

        commands.add(Commands.slash("perfil-admin", "Administra perfis de RP dos jogadores")
                .addSubcommands(
                        new SubcommandData("apagar", "Apaga o perfil de UM jogador no tema ativo")
                                .addOption(OptionType.USER, "usuario", "Jogador", true),
                        new SubcommandData("limpar-todos", "Apaga TODOS os perfis do tema atualmente ativo"),
                        new SubcommandData("limpar-tema", "Apaga todos os perfis de um tema específico (ativo ou não)")
                                .addOption(OptionType.STRING, "id", "ID do tema", true),
                        new SubcommandData("limpar-tudo", "Apaga TODOS os perfis de TODOS os temas de TODOS os jogadores (irreversível)")));

        // ---------- Vínculo de conta e cargo automático (ex.: LuckPerms) ----------
        commands.add(Commands.slash("registrar", "Vincula sua conta do Discord ao seu nick do Minecraft")
                .addOption(OptionType.STRING, "nick", "O mesmo nick que você usa para entrar no servidor", true));

        commands.add(Commands.slash("desvincular", "Remove o vínculo entre sua conta do Discord e seu nick do Minecraft"));

        commands.add(Commands.slash("vinculo", "Mostra o nick do Minecraft vinculado a uma conta do Discord")
                .addOption(OptionType.USER, "usuario", "Jogador (padrão: você)", false));

        commands.add(Commands.slash("cargo-automatico", "Configura o cargo (ex.: LuckPerms) concedido conforme um atributo de RP")
                .addSubcommands(
                        new SubcommandData("ativar", "Liga/desliga o cargo automático")
                                .addOption(OptionType.BOOLEAN, "ativo", "true/false", true),
                        new SubcommandData("atributo", "Define qual atributo do tema ativo dispara o cargo automático")
                                .addOption(OptionType.STRING, "atributo", "ID do atributo, ex.: reino", true),
                        new SubcommandData("comando", "Define o comando de console que CONCEDE o grupo")
                                .addOption(OptionType.STRING, "modelo", "Use %jogador% e %grupo%, ex.: lp user %jogador% parent set %grupo%", true),
                        new SubcommandData("comando-remover", "Define o comando de console que REVOGA o grupo (roda sozinho ao apagar/zerar perfis)")
                                .addOption(OptionType.STRING, "modelo", "Use %jogador% e %grupo%, ex.: lp user %jogador% parent remove %grupo%", true),
                        new SubcommandData("mapear", "Associa um valor do atributo a um grupo (ex.: LuckPerms)")
                                .addOption(OptionType.STRING, "valor", "Valor do atributo, ex.: Eldoria", true)
                                .addOption(OptionType.STRING, "grupo", "Nome do grupo, ex.: reino_eldoria", true),
                        new SubcommandData("desmapear", "Remove a associação de um valor")
                                .addOption(OptionType.STRING, "valor", "Valor do atributo", true),
                        new SubcommandData("listar", "Mostra a configuração atual do cargo automático"),
                        new SubcommandData("sincronizar", "Força a sincronização de um jogador já vinculado")
                                .addOption(OptionType.USER, "usuario", "Jogador", true),
                        new SubcommandData("sincronizar-todos", "Força a sincronização de todos os jogadores vinculados")));

        // ---------- Permissões ----------
        commands.add(Commands.slash("permissao", "Define quais cargos podem usar quais grupos de comando")
                .addSubcommands(
                        new SubcommandData("adicionar-cargo", "Autoriza um cargo em um grupo de comandos")
                                .addOption(OptionType.STRING, "grupo", "rp, moderacao, configuracao, diversao ou parcerias", true)
                                .addOption(OptionType.ROLE, "cargo", "Cargo a autorizar", true),
                        new SubcommandData("remover-cargo", "Remove a autorização de um cargo em um grupo")
                                .addOption(OptionType.STRING, "grupo", "rp, moderacao, configuracao, diversao ou parcerias", true)
                                .addOption(OptionType.ROLE, "cargo", "Cargo a desautorizar", true),
                        new SubcommandData("listar", "Lista o dono permanente e os cargos autorizados por grupo")));

        // ---------- Moderação ----------
        commands.add(Commands.slash("warn", "Registra uma advertência")
                .addOption(OptionType.USER, "usuario", "Membro", true)
                .addOption(OptionType.STRING, "motivo", "Motivo", true));

        commands.add(Commands.slash("warnings", "Consulta ou limpa advertências de um membro")
                .addSubcommands(
                        new SubcommandData("listar", "Lista as advertências de um membro")
                                .addOption(OptionType.USER, "usuario", "Membro", true),
                        new SubcommandData("limpar", "Remove todas as advertências de um membro")
                                .addOption(OptionType.USER, "usuario", "Membro", true)));

        commands.add(Commands.slash("mute", "Silencia (timeout) um membro por um tempo")
                .addOption(OptionType.USER, "usuario", "Membro", true)
                .addOption(OptionType.INTEGER, "minutos", "1 a 40320 (28 dias)", true)
                .addOption(OptionType.STRING, "motivo", "Motivo", false));

        commands.add(Commands.slash("unmute", "Remove o silenciamento de um membro")
                .addOption(OptionType.USER, "usuario", "Membro", true));

        commands.add(Commands.slash("kick", "Expulsa um membro do servidor")
                .addOption(OptionType.USER, "usuario", "Membro", true)
                .addOption(OptionType.STRING, "motivo", "Motivo", false));

        commands.add(Commands.slash("ban", "Bane um membro do servidor")
                .addOption(OptionType.USER, "usuario", "Membro", true)
                .addOption(OptionType.STRING, "motivo", "Motivo", false));

        commands.add(Commands.slash("limpar", "Apaga até 100 mensagens do canal atual")
                .addOption(OptionType.INTEGER, "quantidade", "1 a 100", true));

        // ---------- Configuração ----------
        commands.add(Commands.slash("config", "Configura boas-vindas, despedida e logs")
                .addSubcommands(
                        new SubcommandData("boas-vindas", "Define canal e mensagem de entrada")
                                .addOption(OptionType.CHANNEL, "canal", "Canal", true)
                                .addOption(OptionType.STRING, "mensagem", "Use {user}, {server} e {count}", true),
                        new SubcommandData("boas-vindas-alternar", "Liga/desliga a mensagem de entrada")
                                .addOption(OptionType.BOOLEAN, "ativo", "true para ligar, false para desligar", true),
                        new SubcommandData("despedida", "Define canal e mensagem de saída")
                                .addOption(OptionType.CHANNEL, "canal", "Canal", true)
                                .addOption(OptionType.STRING, "mensagem", "Use {user} e {server}", true),
                        new SubcommandData("despedida-alternar", "Liga/desliga a mensagem de saída")
                                .addOption(OptionType.BOOLEAN, "ativo", "true para ligar, false para desligar", true),
                        new SubcommandData("logs", "Define o canal de logs administrativos")
                                .addOption(OptionType.CHANNEL, "canal", "Canal", true),
                        new SubcommandData("ver", "Mostra a configuração atual")));

        commands.add(Commands.slash("automod", "Configura o filtro automático de mensagens")
                .addSubcommands(
                        new SubcommandData("ativar", "Liga ou desliga o automod")
                                .addOption(OptionType.BOOLEAN, "ativo", "true para ligar, false para desligar", true),
                        new SubcommandData("anti-link", "Liga/desliga bloqueio de links genéricos")
                                .addOption(OptionType.BOOLEAN, "ativo", "true/false", true),
                        new SubcommandData("anti-convite", "Liga/desliga bloqueio de convites de outros servidores")
                                .addOption(OptionType.BOOLEAN, "ativo", "true/false", true),
                        new SubcommandData("anti-caps", "Liga/desliga bloqueio de mensagens em CAIXA ALTA")
                                .addOption(OptionType.BOOLEAN, "ativo", "true/false", true),
                        new SubcommandData("anti-spam", "Liga/desliga bloqueio de spam (mensagens repetidas rápidas)")
                                .addOption(OptionType.BOOLEAN, "ativo", "true/false", true),
                        new SubcommandData("palavra-adicionar", "Adiciona uma palavra à lista de bloqueio")
                                .addOption(OptionType.STRING, "palavra", "Palavra ou expressão", true),
                        new SubcommandData("palavra-remover", "Remove uma palavra da lista de bloqueio")
                                .addOption(OptionType.STRING, "palavra", "Palavra ou expressão", true),
                        new SubcommandData("cargo-isento", "Isenta um cargo do automod")
                                .addOption(OptionType.ROLE, "cargo", "Cargo", true),
                        new SubcommandData("ver", "Mostra a configuração atual do automod")));

        commands.add(Commands.slash("nivel-cargo", "Define cargos concedidos automaticamente por nível")
                .addSubcommands(
                        new SubcommandData("definir", "Define o cargo de recompensa de um nível")
                                .addOption(OptionType.INTEGER, "nivel", "Nível necessário", true)
                                .addOption(OptionType.ROLE, "cargo", "Cargo a conceder", true),
                        new SubcommandData("remover", "Remove a recompensa de um nível")
                                .addOption(OptionType.INTEGER, "nivel", "Nível", true),
                        new SubcommandData("listar", "Lista as recompensas de nível configuradas"),
                        new SubcommandData("alternar", "Liga/desliga o sistema de níveis")
                                .addOption(OptionType.BOOLEAN, "ativo", "true/false", true)));

        commands.add(Commands.slash("verificacao", "Configura a verificação de novos membros")
                .addSubcommands(
                        new SubcommandData("configurar", "Ativa a verificação em um canal, concedendo um cargo")
                                .addOption(OptionType.CHANNEL, "canal", "Canal onde o botão de verificação aparece", true)
                                .addOption(OptionType.ROLE, "cargo", "Cargo concedido ao verificar", true),
                        new SubcommandData("desativar", "Desativa a verificação")));

        // ---------- Minecraft ----------
        commands.add(Commands.slash("minecraft", "Integração com o servidor de Minecraft")
                .addSubcommands(
                        new SubcommandData("status", "Mostra jogadores, versão e disponibilidade do servidor"),
                        new SubcommandData("bridge-canal", "Define o canal onde entradas/saídas do Minecraft são avisadas")
                                .addOption(OptionType.CHANNEL, "canal", "Canal", true),
                        new SubcommandData("bridge-info", "Mostra as credenciais que o plugin do Minecraft precisa"),
                        new SubcommandData("bridge-regerar-chave", "Gera uma nova chave secreta do bridge (invalida a antiga)"),
                        new SubcommandData("anunciar", "Envia um aviso deliberado para dentro do jogo (não é espelho automático de chat)")
                                .addOption(OptionType.STRING, "mensagem", "Texto do aviso", true)));

        // ---------- Diversão / utilidade / comunidade ----------
        commands.add(Commands.slash("embed", "Envia um anúncio formatado (aceita links, imagem e botões de link)")
                .addOption(OptionType.STRING, "titulo", "Título", true)
                .addOption(OptionType.STRING, "texto", "Texto (use \\n para quebrar linha; links [texto](url) funcionam)", true)
                .addOption(OptionType.STRING, "imagem", "Link de uma imagem/banner grande (opcional)", false)
                .addOption(OptionType.STRING, "cor", "Cor da barra lateral em hex, ex.: #ff8800 (opcional)", false)
                .addOption(OptionType.STRING, "link", "Link para um botão clicável, ex.: convite ou site (opcional)", false)
                .addOption(OptionType.STRING, "botao", "Texto do botão do link (padrão: 🔗 Abrir link)", false)
                .addOption(OptionType.STRING, "link2", "Link de um segundo botão (opcional)", false)
                .addOption(OptionType.STRING, "botao2", "Texto do segundo botão", false));

        commands.add(Commands.slash("enquete", "Cria uma enquete simples com reações")
                .addOption(OptionType.STRING, "pergunta", "Pergunta", true));

        commands.add(Commands.slash("avisar", "Envia um aviso destacado (embed), marca quem quiser e aceita links/botões")
                .addOption(OptionType.STRING, "mensagem", "Mensagem (use \\n para quebrar linha; links [texto](url) funcionam)", true)
                .addOption(OptionType.STRING, "titulo", "Título do aviso (padrão: 📢 Aviso)", false)
                .addOption(OptionType.ROLE, "cargo", "Cargo a mencionar junto do aviso", false)
                .addOption(OptionType.USER, "usuario", "Usuário a mencionar junto do aviso", false)
                .addOption(OptionType.BOOLEAN, "todos", "Mencionar @everyone (requer permissão de Mencionar @everyone)", false)
                .addOption(OptionType.BOOLEAN, "aqui", "Mencionar @here (requer permissão de Mencionar @everyone)", false)
                .addOption(OptionType.STRING, "imagem", "Link de uma imagem/banner grande (opcional)", false)
                .addOption(OptionType.STRING, "cor", "Cor da barra lateral em hex, ex.: #ff8800 (opcional)", false)
                .addOption(OptionType.STRING, "link", "Link para um botão clicável, ex.: convite ou site (opcional)", false)
                .addOption(OptionType.STRING, "botao", "Texto do botão do link (padrão: 🔗 Abrir link)", false)
                .addOption(OptionType.STRING, "link2", "Link de um segundo botão (opcional)", false)
                .addOption(OptionType.STRING, "botao2", "Texto do segundo botão", false));

        // ---------- Parcerias ----------
        commands.add(Commands.slash("parceria", "Sistema de parcerias: pedidos com formulário, aprovação da staff e anúncio automático")
                .addSubcommands(
                        new SubcommandData("painel", "Publica o painel com o botão 'Solicitar parceria'")
                                .addOptions(new OptionData(OptionType.CHANNEL, "canal", "Canal do painel (padrão: o atual)", false)
                                        .setChannelTypes(ChannelType.TEXT)),
                        new SubcommandData("divulgar", "Publica uma parceria direto, sem formulário")
                                .addOption(OptionType.STRING, "nome", "Nome do servidor parceiro", true)
                                .addOption(OptionType.STRING, "convite", "Convite do servidor (discord.gg/...)", true)
                                .addOptions(new OptionData(OptionType.STRING, "descricao", "Descrição (use \\n para quebrar linha)", true)
                                        .setMaxLength(1500))
                                .addOption(OptionType.USER, "representante", "Representante do servidor (recebe o cargo de parceiro)", false)
                                .addOption(OptionType.STRING, "imagem", "Link de uma imagem/banner (opcional)", false),
                        new SubcommandData("listar", "Lista as parcerias ativas"),
                        new SubcommandData("remover", "Encerra uma parceria: apaga o anúncio e retira o cargo")
                                .addOption(OptionType.STRING, "id", "ID da parceria (veja em /parceria listar)", true),
                        new SubcommandData("estatisticas", "Mostra números de parcerias e a staff que mais analisou"),
                        new SubcommandData("canal-divulgacao", "Define o canal onde os anúncios são publicados")
                                .addOptions(new OptionData(OptionType.CHANNEL, "canal", "Canal de divulgação", true)
                                        .setChannelTypes(ChannelType.TEXT)),
                        new SubcommandData("canal-analise", "Define o canal (da staff) onde chegam os pedidos")
                                .addOptions(new OptionData(OptionType.CHANNEL, "canal", "Canal de análise", true)
                                        .setChannelTypes(ChannelType.TEXT)),
                        new SubcommandData("cargo-parceiro", "Cargo dado ao representante quando aprovado (vazio = nenhum)")
                                .addOption(OptionType.ROLE, "cargo", "Cargo de parceiro", false),
                        new SubcommandData("cargo-ping", "Cargo marcado em cada anúncio novo (vazio = nenhum)")
                                .addOption(OptionType.ROLE, "cargo", "Cargo a marcar", false),
                        new SubcommandData("regras", "Define o texto de regras mostrado no painel")
                                .addOption(OptionType.STRING, "texto", "Regras (use \\n para quebrar linha)", true),
                        new SubcommandData("alternar", "Abre ou fecha os pedidos de parceria")
                                .addOption(OptionType.BOOLEAN, "ativo", "true para abrir, false para fechar", true),
                        new SubcommandData("ver", "Mostra a configuração atual das parcerias")));

        commands.add(Commands.slash("cargo", "Adiciona ou remove um cargo de um membro")
                .addSubcommands(
                        new SubcommandData("dar", "Dá um cargo a um membro")
                                .addOption(OptionType.USER, "usuario", "Membro", true)
                                .addOption(OptionType.ROLE, "cargo", "Cargo", true),
                        new SubcommandData("remover", "Remove um cargo de um membro")
                                .addOption(OptionType.USER, "usuario", "Membro", true)
                                .addOption(OptionType.ROLE, "cargo", "Cargo", true)));

        commands.add(Commands.slash("userinfo", "Mostra informações de um membro")
                .addOption(OptionType.USER, "usuario", "Membro (padrão: você)", false));

        commands.add(Commands.slash("serverinfo", "Mostra informações do servidor"));

        commands.add(Commands.slash("avatar", "Mostra o avatar de um usuário em tamanho grande")
                .addOption(OptionType.USER, "usuario", "Usuário (padrão: você)", false));

        commands.add(Commands.slash("ticket", "Abre ou fecha um atendimento privado")
                .addSubcommands(
                        new SubcommandData("abrir", "Abre um canal de atendimento")
                                .addOption(OptionType.STRING, "assunto", "Motivo", false),
                        new SubcommandData("fechar", "Fecha seu ticket atual")));

        commands.add(Commands.slash("comando-custom", "Cria comandos de texto customizados (ex.: !regras)")
                .addSubcommands(
                        new SubcommandData("criar", "Cria ou substitui um comando customizado")
                                .addOption(OptionType.STRING, "nome", "Nome sem o prefixo, ex.: regras", true)
                                .addOption(OptionType.STRING, "resposta", "O que o bot deve responder", true),
                        new SubcommandData("remover", "Remove um comando customizado")
                                .addOption(OptionType.STRING, "nome", "Nome do comando", true),
                        new SubcommandData("listar", "Lista todos os comandos customizados"),
                        new SubcommandData("prefixo", "Define o prefixo usado pelos comandos customizados")
                                .addOption(OptionType.STRING, "prefixo", "Ex.: ! ou .", true)));

        commands.add(Commands.slash("cargo-reacao", "Cria menus de cargo por reação")
                .addSubcommands(
                        new SubcommandData("criar", "Envia a mensagem base do menu de cargos por reação")
                                .addOption(OptionType.STRING, "titulo", "Título do menu", true)
                                .addOption(OptionType.STRING, "descricao", "Texto explicando as opções", true),
                        new SubcommandData("adicionar-opcao", "Associa uma reação a um cargo em um menu já criado")
                                .addOption(OptionType.STRING, "id-mensagem", "ID da mensagem do menu", true)
                                .addOption(OptionType.STRING, "emoji", "Emoji unicode (ex.: 🔥)", true)
                                .addOption(OptionType.ROLE, "cargo", "Cargo a conceder", true)));

        commands.add(Commands.slash("sorteio", "Cria e gerencia sorteios")
                .addSubcommands(
                        new SubcommandData("criar", "Cria um sorteio com participação por botão")
                                .addOption(OptionType.STRING, "premio", "O que será sorteado", true)
                                .addOption(OptionType.INTEGER, "minutos", "Duração em minutos", true)
                                .addOption(OptionType.INTEGER, "vencedores", "Quantidade de vencedores", true),
                        new SubcommandData("finalizar", "Encerra um sorteio antes do tempo e sorteia agora")
                                .addOption(OptionType.STRING, "id", "ID do sorteio", true),
                        new SubcommandData("rerolar", "Sorteia novos vencedores para um sorteio já encerrado")
                                .addOption(OptionType.STRING, "id", "ID do sorteio", true)));

        commands.add(Commands.slash("rank", "Mostra o nível e XP de um membro")
                .addOption(OptionType.USER, "usuario", "Membro (padrão: você)", false));

        commands.add(Commands.slash("rank-top", "Mostra o ranking de níveis do servidor"));

        commands.add(Commands.slash("nivel-admin", "Administra o nível/XP de um jogador diretamente (sem precisar mandar mensagem)")
                .addSubcommands(
                        new SubcommandData("definir-xp", "Define o XP total exato de um jogador (recalcula o nível)")
                                .addOption(OptionType.USER, "usuario", "Jogador", true)
                                .addOption(OptionType.INTEGER, "quantidade", "XP total desejado", true),
                        new SubcommandData("definir-nivel", "Define o nível exato de um jogador (recalcula o XP)")
                                .addOption(OptionType.USER, "usuario", "Jogador", true)
                                .addOption(OptionType.INTEGER, "quantidade", "Nível desejado", true),
                        new SubcommandData("adicionar-xp", "Soma (ou subtrai, com número negativo) XP de um jogador")
                                .addOption(OptionType.USER, "usuario", "Jogador", true)
                                .addOption(OptionType.INTEGER, "quantidade", "XP a adicionar (negativo para remover)", true),
                        new SubcommandData("resetar", "Zera o nível e XP de um jogador")
                                .addOption(OptionType.USER, "usuario", "Jogador", true)));

        // ---------- Administração extra ----------
        commands.add(Commands.slash("slowmode", "Define o modo lento do canal atual")
                .addOption(OptionType.INTEGER, "segundos", "0 (desligado) a 21600", true));

        commands.add(Commands.slash("lock", "Tranca o canal atual (impede @everyone de enviar mensagens)"));
        commands.add(Commands.slash("unlock", "Destranca o canal atual"));

        commands.add(Commands.slash("apelido", "Altera o apelido de um membro")
                .addOption(OptionType.USER, "usuario", "Membro", true)
                .addOption(OptionType.STRING, "apelido", "Novo apelido (deixe vazio para remover)", false));

        commands.add(Commands.slash("limpar-usuario", "Apaga mensagens recentes de um usuário específico no canal atual")
                .addOption(OptionType.USER, "usuario", "Membro", true)
                .addOption(OptionType.INTEGER, "quantidade", "Quantas mensagens verificar (1 a 200)", true));

        // ---------- Utilidade / diversão extra ----------
        commands.add(Commands.slash("ping", "Mostra a latência do bot"));
        commands.add(Commands.slash("stats", "Mostra estatísticas gerais do bot"));
        commands.add(Commands.slash("convite", "Gera um link de convite permanente do servidor"));

        commands.add(Commands.slash("bola8", "Pergunte algo à bola 8 mágica")
                .addOption(OptionType.STRING, "pergunta", "Sua pergunta", true));

        commands.add(Commands.slash("moeda", "Joga uma moeda para o alto"));

        commands.add(Commands.slash("dado", "Rola um dado")
                .addOption(OptionType.INTEGER, "lados", "Número de lados (padrão 6)", false));

        commands.add(Commands.slash("afk", "Marca ou desmarca você como ausente (AFK)")
                .addOption(OptionType.STRING, "motivo", "Motivo (opcional)", false));

        commands.add(Commands.slash("lembrete", "Cria lembretes pessoais")
                .addSubcommands(
                        new SubcommandData("criar", "Cria um novo lembrete")
                                .addOption(OptionType.INTEGER, "minutos", "Em quantos minutos te lembrar (1 a 10080)", true)
                                .addOption(OptionType.STRING, "mensagem", "O que devo te lembrar", true),
                        new SubcommandData("listar", "Lista seus lembretes pendentes"),
                        new SubcommandData("cancelar", "Cancela um lembrete pelo ID")
                                .addOption(OptionType.STRING, "id", "ID do lembrete (veja em /lembrete listar)", true)));

        commands.add(Commands.slash("sugestao", "Sistema de sugestões da comunidade")
                .addSubcommands(
                        new SubcommandData("canal", "Define o canal onde as sugestões são publicadas")
                                .addOption(OptionType.CHANNEL, "canal", "Canal", true),
                        new SubcommandData("alternar", "Liga/desliga o sistema de sugestões")
                                .addOption(OptionType.BOOLEAN, "ativo", "true/false", true),
                        new SubcommandData("enviar", "Envia uma sugestão para o canal configurado")
                                .addOption(OptionType.STRING, "texto", "Sua sugestão", true)));

        jda.updateCommands().addCommands(commands).queue();
    }
}
