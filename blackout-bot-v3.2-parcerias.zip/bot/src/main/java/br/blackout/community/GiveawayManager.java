package br.blackout.community;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.interactions.components.buttons.Button;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

final class GiveawayManager {

    private GiveawayManager() {}

    static void create(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_DIVERSAO)) return;
        if (e.getChannel() == null) return;
        String prize = e.getOption("premio").getAsString();
        int minutes = e.getOption("minutos").getAsInt();
        int winners = e.getOption("vencedores").getAsInt();
        if (minutes < 1) {
            Reply.of(e, "A duração precisa ser de pelo menos 1 minuto.", true);
            return;
        }
        if (winners < 1) {
            Reply.of(e, "É preciso pelo menos 1 vencedor.", true);
            return;
        }
        Model.Giveaway giveaway = new Model.Giveaway();
        giveaway.id = UUID.randomUUID().toString().substring(0, 8);
        giveaway.channelId = e.getChannel().getIdLong();
        giveaway.prize = prize;
        giveaway.winnerCount = winners;
        giveaway.endsAtEpochMillis = System.currentTimeMillis() + minutes * 60_000L;
        giveaway.hostId = e.getUser().getIdLong();

        EmbedBuilder embed = buildEmbed(giveaway);
        e.replyEmbeds(embed.build())
                .setActionRow(Button.primary("giveaway-join-" + giveaway.id, "🎉 Participar"))
                .queue(hook -> hook.retrieveOriginal().queue(message -> {
                    giveaway.messageId = message.getIdLong();
                    Store.db.giveaways.put(giveaway.id, giveaway);
                    Store.save();
                }));
    }

    private static EmbedBuilder buildEmbed(Model.Giveaway giveaway) {
        return new EmbedBuilder()
                .setTitle("🎉 Sorteio: " + giveaway.prize)
                .setDescription("Clique no botão abaixo para participar!\nVencedores: **" + giveaway.winnerCount + "**"
                        + "\nTermina em: <t:" + (giveaway.endsAtEpochMillis / 1000) + ":R>"
                        + "\nParticipantes: **" + giveaway.participantIds.size() + "**"
                        + "\nID do sorteio: `" + giveaway.id + "`")
                .setColor(Reply.BRAND_COLOR);
    }

    static void onButton(ButtonInteractionEvent event) {
        String buttonId = event.getComponentId();
        if (!buttonId.startsWith("giveaway-join-")) return;
        String giveawayId = buttonId.substring("giveaway-join-".length());
        Model.Giveaway giveaway = Store.db.giveaways.get(giveawayId);
        if (giveaway == null || giveaway.ended) {
            event.reply("Este sorteio não está mais disponível.").setEphemeral(true).queue();
            return;
        }
        boolean added = giveaway.participantIds.add(event.getUser().getIdLong());
        Store.save();
        event.reply(added ? "Você está participando! Boa sorte 🍀" : "Você já estava participando.").setEphemeral(true).queue();
        updateGiveawayMessage(event.getJDA(), giveaway);
    }

    private static void updateGiveawayMessage(JDA jda, Model.Giveaway giveaway) {
        if (giveaway.messageId == 0) return;
        TextChannel channel = jda.getTextChannelById(giveaway.channelId);
        if (channel == null) return;
        channel.editMessageEmbedsById(giveaway.messageId, buildEmbed(giveaway).build()).queue(v -> {}, error -> {});
    }

    /** Chamado periodicamente (ex.: a cada 30s) para encerrar sorteios cujo tempo já passou. */
    static void checkExpired(JDA jda) {
        long now = System.currentTimeMillis();
        for (Model.Giveaway giveaway : Store.db.giveaways.values()) {
            if (!giveaway.ended && giveaway.endsAtEpochMillis <= now) {
                finish(jda, giveaway);
            }
        }
    }

    static void finalizeNow(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_DIVERSAO)) return;
        Model.Giveaway giveaway = Store.db.giveaways.get(e.getOption("id").getAsString());
        if (giveaway == null) {
            Reply.of(e, "Sorteio não encontrado.", true);
            return;
        }
        if (giveaway.ended) {
            Reply.of(e, "Esse sorteio já foi encerrado. Use `/sorteio rerolar` se quiser sortear de novo.", true);
            return;
        }
        finish(e.getJDA(), giveaway);
        Reply.of(e, "Sorteio encerrado.", true);
    }

    static void reroll(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_DIVERSAO)) return;
        Model.Giveaway giveaway = Store.db.giveaways.get(e.getOption("id").getAsString());
        if (giveaway == null) {
            Reply.of(e, "Sorteio não encontrado.", true);
            return;
        }
        if (!giveaway.ended) {
            Reply.of(e, "Esse sorteio ainda não foi encerrado.", true);
            return;
        }
        announceWinners(e.getJDA(), giveaway, true);
        Reply.of(e, "Novos vencedores sorteados.", true);
    }

    private static void finish(JDA jda, Model.Giveaway giveaway) {
        giveaway.ended = true;
        Store.save();
        announceWinners(jda, giveaway, false);
    }

    private static void announceWinners(JDA jda, Model.Giveaway giveaway, boolean isReroll) {
        TextChannel channel = jda.getTextChannelById(giveaway.channelId);
        if (channel == null) return;
        List<Long> participants = new ArrayList<>(giveaway.participantIds);
        Collections.shuffle(participants);
        List<Long> winners = participants.subList(0, Math.min(giveaway.winnerCount, participants.size()));
        if (winners.isEmpty()) {
            channel.sendMessage("😕 O sorteio de **" + giveaway.prize + "** encerrou sem participantes.").queue();
            return;
        }
        StringBuilder mentions = new StringBuilder();
        for (Long winnerId : winners) mentions.append("<@").append(winnerId).append("> ");
        String prefix = isReroll ? "🔄 Novo(s) vencedor(es) do sorteio de " : "🎉 Vencedor(es) do sorteio de ";
        channel.sendMessage(prefix + "**" + giveaway.prize + "**: " + mentions).queue();
    }
}
