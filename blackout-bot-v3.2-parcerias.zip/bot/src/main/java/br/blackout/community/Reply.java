package br.blackout.community;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;

import java.awt.Color;

/** Pequeno utilitário para não repetir a lógica de "responder ou seguir a resposta" em todo comando. */
final class Reply {

    static final Color BRAND_COLOR = new Color(0x8B5CF6);

    private Reply() {}

    static void of(SlashCommandInteractionEvent e, String text, boolean ephemeral) {
        if (e.isAcknowledged()) {
            e.getHook().sendMessage(text).setEphemeral(ephemeral).queue();
        } else {
            e.reply(text).setEphemeral(ephemeral).queue();
        }
    }

    static void embed(SlashCommandInteractionEvent e, EmbedBuilder builder, boolean ephemeral) {
        if (e.isAcknowledged()) {
            e.getHook().sendMessageEmbeds(builder.build()).setEphemeral(ephemeral).queue();
        } else {
            e.replyEmbeds(builder.build()).setEphemeral(ephemeral).queue();
        }
    }
}
