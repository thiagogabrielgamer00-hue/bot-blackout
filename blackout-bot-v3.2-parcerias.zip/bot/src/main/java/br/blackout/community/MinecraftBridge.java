package br.blackout.community;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * Ponte HTTP entre o bot do Discord e o plugin de Minecraft.
 *
 * IMPORTANTE: isto NÃO é mais um espelho automático de chat. Para um servidor 100% RP,
 * misturar toda conversa do Discord com o chat imersivo do jogo (e vice-versa) quebra a
 * imersão. Por isso o fluxo agora é só sob demanda:
 *   1. POST /event  -> o plugin avisa o bot quando um jogador entra ou sai (opcional,
 *      apenas informativo, aparece só no canal do Discord — nunca dentro do jogo).
 *   2. GET  /poll    -> o plugin pergunta periodicamente se há algum AVISO DELIBERADO
 *      enfileirado com `/minecraft anunciar`, para exibir no jogo já marcado como aviso.
 *      Nada mais entra nessa fila — nenhuma conversa comum do Discord é repassada.
 *      O mesmo /poll também traz uma fila separada de COMANDOS DE CONSOLE, usada pelo
 *      cargo automático (ex.: LuckPerms) configurado com /cargo-automatico — o plugin
 *      executa cada comando no console do servidor assim que o busca.
 *
 * Toda requisição precisa do cabeçalho "X-Bridge-Secret" com a chave gerada em
 * /minecraft bridge-info. Sem a chave certa, o bot recusa (403).
 *
 * IMPORTANTE: para o plugin conseguir alcançar este servidor, a porta HTTP do bot
 * (padrão 8712) precisa estar acessível a partir do servidor de Minecraft. Se o bot
 * e o Minecraft estiverem hospedados em lugares diferentes, confirme com o host
 * (ex.: WispByte) que essa porta pode ser exposta publicamente — hospedagens
 * gratuitas às vezes só liberam a porta principal do serviço.
 */
final class MinecraftBridge {

    private static final Gson GSON = new Gson();
    private static final int MAX_QUEUE = 300;
    private static final ConcurrentLinkedDeque<OutgoingMessage> OUTGOING = new ConcurrentLinkedDeque<>();
    private static final ConcurrentLinkedDeque<OutgoingCommand> OUTGOING_COMMANDS = new ConcurrentLinkedDeque<>();

    private static JDA jdaRef;
    private static HttpServer server;

    private MinecraftBridge() {}

    static void start(JDA jda) {
        jdaRef = jda;
        try {
            server = HttpServer.create(new InetSocketAddress(Store.db.bridgeHttpPort), 0);
            server.createContext("/event", MinecraftBridge::handleEvent);
            server.createContext("/poll", MinecraftBridge::handlePoll);
            server.setExecutor(null);
            server.start();
            System.out.println("Bridge HTTP do Minecraft ouvindo na porta " + Store.db.bridgeHttpPort);
        } catch (IOException e) {
            System.err.println("Não consegui iniciar o servidor da bridge do Minecraft: " + e.getMessage());
        }
    }

    /** Chamado por /minecraft anunciar (e por eventos internos) para enfileirar algo que o plugin vai buscar no /poll. */
    static void queueOutgoing(String author, String content) {
        OUTGOING.addLast(new OutgoingMessage(System.currentTimeMillis(), author, content));
        while (OUTGOING.size() > MAX_QUEUE) OUTGOING.pollFirst();
    }

    /**
     * Enfileira um comando de console para o plugin executar no servidor (ex.: comando do
     * LuckPerms gerado pelo cargo automático). O plugin decide, pelo próprio config.yml,
     * se aceita executar comandos remotos ou não.
     */
    static void queueCommand(String command) {
        if (command == null || command.isBlank()) return;
        OUTGOING_COMMANDS.addLast(new OutgoingCommand(System.currentTimeMillis(), command));
        while (OUTGOING_COMMANDS.size() > MAX_QUEUE) OUTGOING_COMMANDS.pollFirst();
    }

    private static void handleEvent(HttpExchange exchange) throws IOException {
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            respond(exchange, 405, "{\"error\":\"method not allowed\"}");
            return;
        }
        if (!authorized(exchange)) {
            respond(exchange, 403, "{\"error\":\"invalid secret\"}");
            return;
        }
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        IncomingEvent event;
        try {
            event = GSON.fromJson(body, IncomingEvent.class);
        } catch (Exception ex) {
            respond(exchange, 400, "{\"error\":\"invalid json\"}");
            return;
        }
        if (event == null || event.type == null || event.player == null) {
            respond(exchange, 400, "{\"error\":\"missing fields\"}");
            return;
        }
        relayToDiscord(event);
        respond(exchange, 200, "{\"ok\":true}");
    }

    private static void relayToDiscord(IncomingEvent event) {
        if (jdaRef == null || Store.db.minecraftBridgeChannelId == 0) return;
        TextChannel channel = jdaRef.getTextChannelById(Store.db.minecraftBridgeChannelId);
        if (channel == null) return;
        String text = switch (event.type) {
            case "join" -> "🟢 **" + event.player + "** entrou no servidor.";
            case "leave" -> "🔴 **" + event.player + "** saiu do servidor.";
            case "chat" -> "📨 **" + event.player + "** usou `/discord` no jogo: " + (event.message == null ? "" : event.message);
            default -> null;
        };
        if (text != null) channel.sendMessage(text).queue(v -> {}, error -> {});
    }

    private static void handlePoll(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            respond(exchange, 405, "{\"error\":\"method not allowed\"}");
            return;
        }
        if (!authorized(exchange)) {
            respond(exchange, 403, "{\"error\":\"invalid secret\"}");
            return;
        }
        long since = parseSince(exchange);
        List<OutgoingMessage> pending = new ArrayList<>();
        for (OutgoingMessage message : OUTGOING) {
            if (message.timestamp > since) pending.add(message);
        }
        List<OutgoingCommand> pendingCommands = new ArrayList<>();
        for (OutgoingCommand command : OUTGOING_COMMANDS) {
            if (command.timestamp > since) pendingCommands.add(command);
        }
        respond(exchange, 200, GSON.toJson(Map.of(
                "now", System.currentTimeMillis(),
                "messages", pending,
                "commands", pendingCommands)));
    }

    private static long parseSince(HttpExchange exchange) {
        String query = exchange.getRequestURI().getQuery();
        if (query == null) return 0L;
        for (String part : query.split("&")) {
            String[] kv = part.split("=", 2);
            if (kv.length == 2 && kv[0].equals("since")) {
                try {
                    return Long.parseLong(kv[1]);
                } catch (NumberFormatException ignored) {
                    return 0L;
                }
            }
        }
        return 0L;
    }

    private static boolean authorized(HttpExchange exchange) {
        List<String> headers = exchange.getRequestHeaders().get("X-Bridge-Secret");
        if (headers == null || headers.isEmpty()) return false;
        return Store.db.minecraftBridgeSecret.equals(headers.get(0));
    }

    private static void respond(HttpExchange exchange, int status, String jsonBody) throws IOException {
        byte[] bytes = jsonBody.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(bytes);
        }
    }

    // ---------------- comandos /minecraft ----------------

    static void status(SlashCommandInteractionEvent e) {
        e.deferReply().queue();
        new Thread(() -> {
            try {
                String result = MinecraftStatus.query(Store.db.minecraftHost, Store.db.minecraftPort);
                e.getHook().sendMessage(result).queue();
            } catch (Exception ex) {
                e.getHook().sendMessage("🔴 **Servidor offline ou inacessível**\nEndereço: `"
                        + Store.db.minecraftHost + ":" + Store.db.minecraftPort + "`").queue();
            }
        }).start();
    }

    static void bridgeChannel(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        Store.db.minecraftBridgeChannelId = e.getOption("canal").getAsChannel().getIdLong();
        Store.save();
        Reply.of(e, "Canal-ponte do Minecraft configurado. Entradas/saídas de jogadores vão aparecer lá "
                + "(só isso — nenhuma conversa do jogo ou do Discord é espelhada automaticamente).", true);
    }

    static void bridgeInfo(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        String text = "**Configuração do plugin (config.yml):**\n"
                + "```\n"
                + "bot-url: \"http://SEU_HOST_DO_BOT:" + Store.db.bridgeHttpPort + "\"\n"
                + "secret: \"" + Store.db.minecraftBridgeSecret + "\"\n"
                + "```\n"
                + "Troque `SEU_HOST_DO_BOT` pelo endereço público onde o bot está rodando (ex.: o host do WispByte). "
                + "Guarde a chave em segredo: quem a tiver pode enviar eventos falsos para o bridge.";
        Reply.of(e, text, true);
    }

    static void regenerateSecret(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        Store.db.minecraftBridgeSecret = java.util.UUID.randomUUID().toString().replace("-", "");
        Store.save();
        Reply.of(e, "Nova chave gerada. Use `/minecraft bridge-info` para pegar o valor e atualize o config.yml do plugin.", true);
    }

    /**
     * Envia uma mensagem DE PROPÓSITO para o jogo, marcada como aviso — não é um espelho
     * automático de chat. Só quem tem permissão do grupo "configuracao" pode usar.
     */
    static void announce(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        String mensagem = e.getOption("mensagem").getAsString();
        queueOutgoing("Aviso de " + e.getUser().getName(), mensagem);
        Reply.of(e, "Aviso enfileirado. Ele aparece no jogo assim que o plugin consultar o bot (poll-interval-seconds).", true);
    }

    private static final class IncomingEvent {
        String type;
        String player;
        String message;
    }

    private static final class OutgoingMessage {
        long timestamp;
        String author;
        String content;
        OutgoingMessage(long timestamp, String author, String content) {
            this.timestamp = timestamp;
            this.author = author;
            this.content = content;
        }
    }

    private static final class OutgoingCommand {
        long timestamp;
        String command;
        OutgoingCommand(long timestamp, String command) {
            this.timestamp = timestamp;
            this.command = command;
        }
    }
}
