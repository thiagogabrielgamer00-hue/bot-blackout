package br.blackout.community;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Todo o estado persistente do bot. Tudo aqui é salvo em data/blackout-community.json
 * pelo Store. Não existem tipos "Serializable" nem banco externo: é um arquivo JSON
 * legível, fácil de inspecionar ou editar manualmente em caso de emergência.
 */
final class Model {

    /** Raiz de tudo que o bot guarda. */
    static final class Database {
        // Dono permanente do bot. Definido uma vez a partir do projeto original e
        // nunca pode ser removido por comando, nem pelo próprio dono.
        long ownerId = 1333822923194105917L;

        // Grupos de permissão. Cada grupo controla um conjunto de comandos.
        // Chave: nome do grupo ("rp", "moderacao", "configuracao", "diversao").
        // Valor: IDs de cargos autorizados a usar aquele grupo.
        Map<String, Set<Long>> permissionGroups = new LinkedHashMap<>();

        // --- Sistema de RP / temas ---
        Map<String, Theme> themes = new LinkedHashMap<>();
        String activeTheme = "medieval";
        Map<Long, UserProfiles> profiles = new HashMap<>();

        // --- Moderação ---
        Map<Long, List<Warning>> warnings = new HashMap<>();

        // --- Boas-vindas / despedida / logs ---
        long welcomeChannelId = 0;
        boolean welcomeEnabled = true;
        String welcomeMessage = "Bem-vindo(a), {user}, à **{server}**! Você é o membro número {count}.";
        long leaveChannelId = 0;
        boolean leaveEnabled = true;
        String leaveMessage = "{user} saiu do servidor. Até mais!";
        long logChannelId = 0;

        // --- Tickets ---
        Map<Long, Long> tickets = new HashMap<>(); // userId -> channelId
        long ticketCategoryId = 0;

        // --- Minecraft ---
        String minecraftHost = "enx-soc-8.enx.host";
        int minecraftPort = 10018;
        long minecraftBridgeChannelId = 0;
        String minecraftBridgeSecret = "";
        int bridgeHttpPort = 8712;

        // --- Vínculo de conta (Discord <-> nick do Minecraft) e cargo automático ---
        // O jogador já deve ter se registrado no servidor (plugin de login, ex.: AuthMe).
        // Aqui ele só informa qual é o nick dele para o bot saber pra quem mandar o
        // comando de cargo (ex.: LuckPerms) quando o atributo configurado for definido.
        Map<Long, String> minecraftLinks = new HashMap<>(); // discordUserId -> nick do Minecraft
        RankSyncConfig rankSync = new RankSyncConfig();

        // --- Automod ---
        AutoModConfig automod = new AutoModConfig();

        // --- Nível / XP ---
        boolean levelingEnabled = true;
        Map<Long, LevelData> levels = new HashMap<>();
        Map<Integer, Long> levelRoleRewards = new LinkedHashMap<>(); // nível -> cargo

        // --- Comandos customizados ---
        String customCommandPrefix = "!";
        Map<String, String> customCommands = new LinkedHashMap<>();

        // --- Cargos por reação ---
        Map<Long, Map<String, Long>> reactionRoleMenus = new HashMap<>(); // messageId -> (emoji -> roleId)

        // --- Verificação ---
        boolean verificationEnabled = false;
        long verificationRoleId = 0;
        long verificationChannelId = 0;

        // --- Sorteios ---
        Map<String, Giveaway> giveaways = new LinkedHashMap<>();

        // --- AFK ---
        Map<Long, AfkData> afk = new HashMap<>();

        // --- Lembretes ---
        Map<String, Reminder> reminders = new LinkedHashMap<>();

        // --- Sugestões ---
        long suggestionChannelId = 0;
        boolean suggestionEnabled = false;

        // --- Parcerias ---
        // Fluxo: parceiro clica no botão do painel -> preenche o formulário -> a staff recebe o pedido
        // no canal de análise -> Aprovar publica o anúncio bonito no canal de divulgação.
        boolean partnerEnabled = false;
        long partnerAdChannelId = 0;      // onde o anúncio final é publicado
        long partnerReviewChannelId = 0;  // onde a staff analisa os pedidos (aprovar/recusar)
        long partnerRoleId = 0;           // cargo dado ao representante quando aprovado (opcional)
        long partnerPingRoleId = 0;       // cargo marcado em cada anúncio novo (opcional)
        String partnerRules = DEFAULT_PARTNER_RULES;
        Map<String, Partnership> partnerships = new LinkedHashMap<>();

        static final String DEFAULT_PARTNER_RULES =
                "• O servidor precisa respeitar os Termos de Serviço do Discord.\n"
                + "• Nada de conteúdo NSFW, golpes ou discurso de ódio.\n"
                + "• O convite enviado deve ser **permanente** (sem expiração).\n"
                + "• A staff pode recusar ou remover a parceria a qualquer momento.";
    }

    /** Uma parceria (pedido pendente, aprovada, recusada ou removida). */
    static final class Partnership {
        String id;
        String status = "PENDENTE"; // PENDENTE, APROVADA, RECUSADA, REMOVIDA
        long requesterId;           // representante do servidor parceiro
        String serverName;
        String inviteCode;
        String inviteUrl;
        String description;
        String bannerUrl;           // opcional
        String notes;               // observações só para a staff (não aparecem no anúncio)
        long partnerGuildId;        // ID do servidor parceiro (lido do convite) — evita pedidos duplicados
        String iconUrl;             // ícone do servidor parceiro, lido do convite
        int memberCount;            // lido do convite no momento do pedido
        int onlineCount;
        long createdAt;
        long handledBy;             // staff que aprovou/recusou
        long handledAt;
        String rejectReason;
        long reviewChannelId;
        long reviewMessageId;
        long adChannelId;
        long adMessageId;
    }

    static final class Warning {
        String reason;
        long moderatorId;
        long timestamp;
        Warning() {}
        Warning(String reason, long moderatorId, long timestamp) {
            this.reason = reason;
            this.moderatorId = moderatorId;
            this.timestamp = timestamp;
        }
    }

    static final class AutoModConfig {
        boolean enabled = false;
        boolean blockInvites = true;
        boolean blockLinks = false;
        boolean blockExcessiveCaps = true;
        int capsThresholdPercent = 70;
        int capsMinLength = 10;
        boolean blockSpam = true;
        int spamMessageCount = 5;
        int spamWindowSeconds = 7;
        Set<String> bannedWords = new HashSet<>();
        Set<Long> exemptRoleIds = new HashSet<>();
        Set<Long> exemptChannelIds = new HashSet<>();
    }

    static final class LevelData {
        long xp = 0;
        int level = 0;
        long lastMessageTimestamp = 0;
    }

    static final class Theme {
        String id;
        String displayName;
        int defaultRolls = 3;
        Map<String, Field> fields = new LinkedHashMap<>();
        Theme() {}
        Theme(String id, String name) {
            this.id = id;
            this.displayName = name;
        }
    }

    static final class Field {
        String id;
        String label;
        int maxValueLength = 48;
        List<String> options = new ArrayList<>();
        // valor da opção -> raridade (peso). Maior = mais comum. Opções sem entrada aqui usam DEFAULT_WEIGHT.
        Map<String, Integer> weights = new LinkedHashMap<>();
        // valor da opção -> ID de um cargo do Discord concedido diretamente quando o jogador
        // rola (ou recebe) esse valor. Ex.: reino "Aethelgard" -> cargo @Aethelgard.
        // Ao trocar de valor, o cargo referente ao valor anterior desse mesmo atributo é removido.
        Map<String, Long> optionRoles = new LinkedHashMap<>();
        Field() {}
        Field(String id, String label, List<String> values) {
            this.id = id;
            this.label = label;
            this.options.addAll(values);
        }

        static final int DEFAULT_WEIGHT = 10;

        int weightOf(String value) {
            return weights.getOrDefault(value, DEFAULT_WEIGHT);
        }

        Long roleFor(String value) {
            return optionRoles == null ? null : optionRoles.get(value);
        }
    }

    /**
     * Configuração do cargo automático (ex.: LuckPerms) concedido conforme o valor
     * de um atributo de RP do jogador (ex.: campo "reino" -> grupo "reino_eldoria").
     * Tudo aqui é configurável por comando, nada é fixo no código:
     *   - qual atributo do tema ativo dispara a sincronização (themeFieldId)
     *   - qual comando de console concede o grupo (commandTemplate)
     *   - qual comando de console REVOGA o grupo (removeCommandTemplate) — usado
     *     automaticamente quando um perfil é apagado/zerado (ex.: troca de tema),
     *     já que o LuckPerms é um plugin de terceiro que a staff não edita na mão
     *   - qual grupo cada valor do atributo corresponde (valueToGroup)
     * O vínculo de conta (Store.db.minecraftLinks) NUNCA é apagado por essas
     * limpezas de perfil — só o cargo é revogado, a conta continua vinculada.
     */
    static final class RankSyncConfig {
        boolean enabled = false;
        String themeFieldId = "reino";
        String commandTemplate = "lp user %jogador% parent set %grupo%";
        String removeCommandTemplate = "lp user %jogador% parent remove %grupo%";
        Map<String, String> valueToGroup = new LinkedHashMap<>();
    }

    static final class UserProfiles {
        Map<String, Profile> byTheme = new LinkedHashMap<>();
    }

    static final class Profile {
        Map<String, String> values = new LinkedHashMap<>();
        Map<String, Integer> rolls = new LinkedHashMap<>();
    }

    static final class AfkData {
        String reason;
        long since;
        AfkData() {}
        AfkData(String reason, long since) {
            this.reason = reason;
            this.since = since;
        }
    }

    static final class Reminder {
        String id;
        long userId;
        long channelId;
        String message;
        long dueAtEpochMillis;
        Reminder() {}
        Reminder(String id, long userId, long channelId, String message, long dueAtEpochMillis) {
            this.id = id;
            this.userId = userId;
            this.channelId = channelId;
            this.message = message;
            this.dueAtEpochMillis = dueAtEpochMillis;
        }
    }

    static final class Giveaway {
        String id;
        long channelId;
        long messageId;
        String prize;
        int winnerCount;
        long endsAtEpochMillis;
        long hostId;
        Set<Long> participantIds = new HashSet<>();
        boolean ended = false;
    }
}
