package br.blackout.community;

import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;

/**
 * Vínculo de conta (Discord <-> nick do Minecraft) e cargo automático.
 *
 * Fluxo pensado para servidores com tema (ex.: RP medieval):
 *   1. O jogador se registra normalmente no servidor de Minecraft (plugin de
 *      login já existente, ex.: AuthMe) — isso é externo, este bot não mexe nisso.
 *   2. O jogador usa /registrar no Discord informando o mesmo nick que usou no
 *      servidor, vinculando a conta do Discord ao nick do Minecraft.
 *   3. Quando o atributo configurado (padrão: "reino") do perfil de RP dele é
 *      definido — por /roletar ou manualmente por um admin — o bot manda o
 *      plugin do Minecraft executar o comando configurado (padrão: comando do
 *      LuckPerms) para colocar o jogador no grupo correspondente.
 *
 * Nada disso é fixo no código: o atributo que dispara a sincronização, o comando
 * executado e o mapeamento valor -> grupo são todos configurados com /cargo-automatico.
 */
final class RankSyncHandlers {

    private RankSyncHandlers() {}

    // ---------------- comandos do jogador ----------------

    static void link(SlashCommandInteractionEvent e) {
        String nick = e.getOption("nick").getAsString().trim();
        if (nick.isEmpty() || nick.length() > 32) {
            Reply.of(e, "Nick inválido. Use o mesmo nick com que você entra no servidor.", true);
            return;
        }
        Store.db.minecraftLinks.put(e.getUser().getIdLong(), nick);
        Store.save();
        Reply.of(e, "✅ Conta vinculada ao nick **" + nick + "** do Minecraft.\n"
                + "Isso só funciona se você já tiver se registrado no servidor com esse mesmo nick.", true);
        trySync(e.getUser().getIdLong());
    }

    static void unlink(SlashCommandInteractionEvent e) {
        String removed = Store.db.minecraftLinks.remove(e.getUser().getIdLong());
        Store.save();
        Reply.of(e, removed == null ? "Você não tinha nenhum vínculo salvo." : "Vínculo com **" + removed + "** removido.", true);
    }

    static void status(SlashCommandInteractionEvent e) {
        User target = e.getOption("usuario") == null ? e.getUser() : e.getOption("usuario").getAsUser();
        if (target.getIdLong() != e.getUser().getIdLong() && !Permissions.require(e, Permissions.GROUP_RP)) return;
        String nick = Store.db.minecraftLinks.get(target.getIdLong());
        Reply.of(e, nick == null
                ? target.getName() + " ainda não vinculou nenhum nick do Minecraft."
                : target.getName() + " está vinculado ao nick **" + nick + "**.", true);
    }

    // ---------------- /cargo-automatico (admin) ----------------

    static void admin(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        Model.RankSyncConfig cfg = Store.db.rankSync;
        String sub = e.getSubcommandName();
        switch (sub) {
            case "ativar" -> {
                cfg.enabled = e.getOption("ativo").getAsBoolean();
                Store.save();
                Reply.of(e, "Cargo automático " + (cfg.enabled ? "ativado" : "desativado") + ".", true);
            }
            case "atributo" -> {
                String fieldId = e.getOption("atributo").getAsString().trim().toLowerCase(java.util.Locale.ROOT);
                cfg.themeFieldId = fieldId;
                Store.save();
                Reply.of(e, "Atributo que dispara o cargo automático agora é `" + fieldId
                        + "`. Ele é lido do tema ativo no momento em que for definido.", true);
            }
            case "comando" -> {
                String template = e.getOption("modelo").getAsString();
                if (!template.contains("%jogador%") || !template.contains("%grupo%")) {
                    Reply.of(e, "O modelo precisa conter `%jogador%` e `%grupo%`. Ex.: `lp user %jogador% parent set %grupo%`", true);
                    return;
                }
                cfg.commandTemplate = template;
                Store.save();
                Reply.of(e, "Comando de console (concessão) atualizado para: `" + template + "`", true);
            }
            case "comando-remover" -> {
                String template = e.getOption("modelo").getAsString();
                if (!template.contains("%jogador%") || !template.contains("%grupo%")) {
                    Reply.of(e, "O modelo precisa conter `%jogador%` e `%grupo%`. Ex.: `lp user %jogador% parent remove %grupo%`", true);
                    return;
                }
                cfg.removeCommandTemplate = template;
                Store.save();
                Reply.of(e, "Comando de console (revogação) atualizado para: `" + template + "`\n"
                        + "Ele roda sozinho quando um perfil que já tinha esse atributo definido é apagado ou zerado "
                        + "(ex.: `/perfil-admin limpar-todos`), pra tirar o cargo antigo sem a staff precisar mexer no LuckPerms na mão.", true);
            }
            case "mapear" -> {
                String valor = e.getOption("valor").getAsString().trim();
                String grupo = e.getOption("grupo").getAsString().trim();
                cfg.valueToGroup.put(valor, grupo);
                Store.save();
                Reply.of(e, "Valor **" + valor + "** agora concede o grupo `" + grupo + "`.", true);
            }
            case "desmapear" -> {
                String valor = e.getOption("valor").getAsString().trim();
                cfg.valueToGroup.remove(valor);
                Store.save();
                Reply.of(e, "Mapeamento de **" + valor + "** removido.", true);
            }
            case "listar" -> {
                StringBuilder text = new StringBuilder();
                text.append("**Cargo automático:** ").append(cfg.enabled ? "ativado" : "desativado").append("\n");
                text.append("**Atributo:** `").append(cfg.themeFieldId).append("`\n");
                text.append("**Comando (concessão):** `").append(cfg.commandTemplate).append("`\n");
                text.append("**Comando (revogação):** `").append(cfg.removeCommandTemplate).append("`\n");
                text.append("**Mapeamentos:**\n");
                if (cfg.valueToGroup.isEmpty()) {
                    text.append("Nenhum ainda. Use `/cargo-automatico mapear`.\n");
                } else {
                    cfg.valueToGroup.forEach((valor, grupo) -> text.append("• ").append(valor).append(" → `").append(grupo).append("`\n"));
                }
                text.append("**Contas vinculadas:** ").append(Store.db.minecraftLinks.size());
                Reply.of(e, text.toString(), true);
            }
            case "sincronizar" -> {
                User target = e.getOption("usuario").getAsUser();
                if (!Store.db.minecraftLinks.containsKey(target.getIdLong())) {
                    Reply.of(e, target.getName() + " não tem nick do Minecraft vinculado.", true);
                    return;
                }
                boolean applied = trySync(target.getIdLong());
                Reply.of(e, applied
                        ? "Comando enfileirado para o plugin aplicar em " + target.getName() + "."
                        : "Não sincronizei: cargo automático desativado, sem valor definido no atributo, ou valor sem grupo mapeado.", true);
            }
            case "sincronizar-todos" -> {
                int total = 0;
                for (long discordId : Store.db.minecraftLinks.keySet()) {
                    if (trySync(discordId)) total++;
                }
                Reply.of(e, "Sincronizados " + total + " de " + Store.db.minecraftLinks.size() + " jogadores vinculados.", true);
            }
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }

    /**
     * Tenta enfileirar o comando de cargo automático para um jogador, usando o valor
     * atual do atributo configurado no perfil dele do tema ativo. Chamado sempre que:
     *   - o jogador vincula a conta (/registrar);
     *   - um admin força uma sincronização (/cargo-automatico sincronizar[-todos]);
     *   - o valor do atributo configurado é definido (RpHandlers.roll).
     * Retorna true se um comando foi de fato enfileirado.
     */
    static boolean trySync(long discordUserId) {
        Model.RankSyncConfig cfg = Store.db.rankSync;
        if (!cfg.enabled) return false;
        String nick = Store.db.minecraftLinks.get(discordUserId);
        if (nick == null) return false;
        Model.Theme theme = Store.theme();
        if (theme == null) return false;
        Model.Profile profile = Store.profile(discordUserId);
        String value = profile.values.get(cfg.themeFieldId);
        if (value == null) return false;
        String group = cfg.valueToGroup.get(value);
        if (group == null) return false;
        String command = cfg.commandTemplate.replace("%jogador%", nick).replace("%grupo%", group);
        MinecraftBridge.queueCommand(command);
        return true;
    }

    // ---------------- revogação automática ao apagar/zerar perfis ----------------
    //
    // O vínculo de conta (Store.db.minecraftLinks) NUNCA é apagado por essas rotinas —
    // só o comando de REVOGAÇÃO do cargo é enfileirado, usando o valor que o atributo
    // tinha antes de ser apagado. Assim a staff não precisa entrar no LuckPerms na mão
    // toda vez que zera perfis (ex.: ao trocar de tema/reino).

    /** Chamado antes de apagar o perfil de UM jogador num tema (RpHandlers.profileAdmin "apagar"). */
    static void revokeBeforeWipe(long discordUserId, String themeId) {
        Model.UserProfiles up = Store.db.profiles.get(discordUserId);
        if (up == null || up.byTheme == null) return;
        Model.Profile profile = up.byTheme.get(themeId);
        if (profile == null) return;
        String value = profile.values.get(Store.db.rankSync.themeFieldId);
        if (value != null) revokeGroup(discordUserId, value);
    }

    /** Chamado antes de zerar todos os perfis de UM tema (ativo ou não). */
    static void revokeForTheme(String themeId) {
        if (!Store.db.rankSync.enabled) return;
        for (var entry : Store.db.minecraftLinks.entrySet()) {
            long discordUserId = entry.getKey();
            Model.UserProfiles up = Store.db.profiles.get(discordUserId);
            if (up == null || up.byTheme == null) continue;
            Model.Profile profile = up.byTheme.get(themeId);
            if (profile == null) continue;
            String value = profile.values.get(Store.db.rankSync.themeFieldId);
            if (value != null) revokeGroup(discordUserId, value);
        }
    }

    /** Chamado antes de zerar literalmente todos os perfis de todos os temas. */
    static void revokeForAllThemes() {
        if (!Store.db.rankSync.enabled) return;
        for (var entry : Store.db.minecraftLinks.entrySet()) {
            long discordUserId = entry.getKey();
            Model.UserProfiles up = Store.db.profiles.get(discordUserId);
            if (up == null || up.byTheme == null) continue;
            for (Model.Profile profile : up.byTheme.values()) {
                String value = profile.values.get(Store.db.rankSync.themeFieldId);
                if (value != null) {
                    revokeGroup(discordUserId, value);
                    break; // um jogador só tem um nick vinculado — uma revogação já basta
                }
            }
        }
    }

    /** Monta e enfileira o comando de revogação para um valor de atributo específico. */
    private static void revokeGroup(long discordUserId, String value) {
        Model.RankSyncConfig cfg = Store.db.rankSync;
        String nick = Store.db.minecraftLinks.get(discordUserId);
        if (nick == null) return;
        String group = cfg.valueToGroup.get(value);
        if (group == null) return;
        String command = cfg.removeCommandTemplate.replace("%jogador%", nick).replace("%grupo%", group);
        MinecraftBridge.queueCommand(command);
    }
}
