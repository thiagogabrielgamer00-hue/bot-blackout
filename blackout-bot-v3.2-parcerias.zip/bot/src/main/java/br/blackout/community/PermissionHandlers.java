package br.blackout.community;

import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class PermissionHandlers {

    private static final Set<String> VALID_GROUPS = Set.of(
            Permissions.GROUP_RP, Permissions.GROUP_MODERACAO, Permissions.GROUP_CONFIGURACAO, Permissions.GROUP_DIVERSAO, Permissions.GROUP_PARCERIAS);

    private PermissionHandlers() {}

    static void handle(SlashCommandInteractionEvent e) {
        // Somente o dono permanente mexe em permissões. Isso é intencional:
        // ele é o único que nunca pode perder acesso ao bot.
        if (e.getUser().getIdLong() != Store.db.ownerId) {
            Reply.of(e, "Só o dono permanente do bot pode alterar permissões.", true);
            return;
        }
        String sub = e.getSubcommandName();
        if ("listar".equals(sub)) {
            StringBuilder text = new StringBuilder("**Dono permanente:** <@" + Store.db.ownerId + "> (nunca perde acesso)\n\n");
            for (String group : List.of(Permissions.GROUP_RP, Permissions.GROUP_MODERACAO,
                    Permissions.GROUP_CONFIGURACAO, Permissions.GROUP_DIVERSAO, Permissions.GROUP_PARCERIAS)) {
                Set<Long> roles = Store.db.permissionGroups.getOrDefault(group, Set.of());
                text.append("**").append(group).append(":** ");
                if (roles.isEmpty()) {
                    text.append("nenhum cargo autorizado");
                } else {
                    text.append(roles.stream().map(id -> "<@&" + id + ">").reduce("", (a, b) -> a + " " + b));
                }
                text.append("\n");
            }
            Reply.of(e, text.toString(), true);
            return;
        }
        String group = e.getOption("grupo").getAsString().toLowerCase();
        if (!VALID_GROUPS.contains(group)) {
            Reply.of(e, "Grupo inválido. Use: rp, moderacao, configuracao, diversao ou parcerias.", true);
            return;
        }
        long roleId = e.getOption("cargo").getAsRole().getIdLong();
        Set<Long> roles = Store.db.permissionGroups.computeIfAbsent(group, k -> new HashSet<>());
        if ("adicionar-cargo".equals(sub)) {
            roles.add(roleId);
        } else if ("remover-cargo".equals(sub)) {
            roles.remove(roleId);
        } else {
            Reply.of(e, "Subcomando desconhecido.", true);
            return;
        }
        Store.save();
        Reply.of(e, "Permissões do grupo **" + group + "** atualizadas. O dono permanente nunca perde acesso.", true);
    }
}
