package br.blackout.community;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Invite;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.channel.ChannelType;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.ModalInteractionEvent;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.interactions.components.ActionRow;
import net.dv8tion.jda.api.interactions.components.buttons.Button;
import net.dv8tion.jda.api.interactions.components.text.TextInput;
import net.dv8tion.jda.api.interactions.components.text.TextInputStyle;
import net.dv8tion.jda.api.interactions.modals.Modal;

import java.awt.Color;
import java.time.Instant;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Sistema de parcerias.
 *
 * Fluxo do parceiro:  botão "Solicitar parceria" -> formulário (modal) -> a staff recebe o pedido
 *                     no canal de análise -> Aprovar publica o anúncio no canal de divulgação.
 * Fluxo da staff:     /parceria divulgar publica direto, sem passar pelo formulário.
 *
 * O convite é validado de verdade no Discord (existe? de qual servidor? quantos membros?), então a staff
 * já vê os números reais no pedido e o anúncio sai com ícone e contagem de membros automaticamente.
 */
final class PartnershipHandlers {

    static final String BTN_OPEN = "parceria-abrir";
    static final String BTN_APPROVE = "parceria-ok-";
    static final String BTN_REFUSE = "parceria-no-";
    static final String MODAL_FORM = "parceria-form";
    static final String MODAL_REFUSE = "parceria-recusa-";

    private static final Color COLOR_PENDING = new Color(0xF59E0B);
    private static final Color COLOR_OK = new Color(0x22C55E);
    private static final Color COLOR_NO = new Color(0xEF4444);
    private static final Color COLOR_REMOVED = new Color(0x6B7280);

    private PartnershipHandlers() {}

    // =====================================================================================
    // /parceria ...
    // =====================================================================================

    static void handle(SlashCommandInteractionEvent e) {
        if (e.getGuild() == null) {
            Reply.of(e, "Use este comando dentro de um servidor.", true);
            return;
        }
        String sub = e.getSubcommandName();
        if (sub == null) {
            Reply.of(e, "Subcomando desconhecido.", true);
            return;
        }
        switch (sub) {
            case "canal-divulgacao", "canal-analise", "cargo-parceiro", "cargo-ping", "regras", "alternar", "ver" -> {
                if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
                config(e, sub);
            }
            case "painel" -> {
                if (!Permissions.require(e, Permissions.GROUP_PARCERIAS)) return;
                panel(e);
            }
            case "divulgar" -> {
                if (!Permissions.require(e, Permissions.GROUP_PARCERIAS)) return;
                publishDirect(e);
            }
            case "listar" -> {
                if (!Permissions.require(e, Permissions.GROUP_PARCERIAS)) return;
                list(e);
            }
            case "remover" -> {
                if (!Permissions.require(e, Permissions.GROUP_PARCERIAS)) return;
                remove(e);
            }
            case "estatisticas" -> {
                if (!Permissions.require(e, Permissions.GROUP_PARCERIAS)) return;
                stats(e);
            }
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }

    // ---------- configuração ----------

    private static void config(SlashCommandInteractionEvent e, String sub) {
        Model.Database db = Store.db;
        switch (sub) {
            case "canal-divulgacao" -> {
                TextChannel ch = textChannel(e);
                if (ch == null) return;
                db.partnerAdChannelId = ch.getIdLong();
                Store.save();
                Reply.of(e, "✅ Os anúncios de parceria serão publicados em " + ch.getAsMention() + ".", true);
            }
            case "canal-analise" -> {
                TextChannel ch = textChannel(e);
                if (ch == null) return;
                db.partnerReviewChannelId = ch.getIdLong();
                Store.save();
                Reply.of(e, "✅ Os pedidos de parceria chegarão para análise em " + ch.getAsMention()
                        + ". Deixe esse canal visível só para a staff.", true);
            }
            case "cargo-parceiro" -> {
                var opt = e.getOption("cargo");
                db.partnerRoleId = opt == null ? 0 : opt.getAsRole().getIdLong();
                Store.save();
                Reply.of(e, db.partnerRoleId == 0
                        ? "Cargo de parceiro removido: ninguém recebe cargo ao ser aprovado."
                        : "✅ O representante receberá <@&" + db.partnerRoleId + "> quando a parceria for aprovada.", true);
            }
            case "cargo-ping" -> {
                var opt = e.getOption("cargo");
                db.partnerPingRoleId = opt == null ? 0 : opt.getAsRole().getIdLong();
                Store.save();
                Reply.of(e, db.partnerPingRoleId == 0
                        ? "Os anúncios não vão mais marcar nenhum cargo."
                        : "✅ Cada anúncio novo vai marcar <@&" + db.partnerPingRoleId + ">.", true);
            }
            case "regras" -> {
                db.partnerRules = Links.clamp(e.getOption("texto").getAsString().replace("\\n", "\n"), 1500);
                Store.save();
                Reply.of(e, "✅ Regras atualizadas. Rode `/parceria painel` de novo para o painel mostrar o texto novo.", true);
            }
            case "alternar" -> {
                db.partnerEnabled = e.getOption("ativo").getAsBoolean();
                Store.save();
                Reply.of(e, db.partnerEnabled ? "✅ Pedidos de parceria **ativados**." : "⏸️ Pedidos de parceria **desativados**.", true);
            }
            case "ver" -> {
                Guild g = e.getGuild();
                EmbedBuilder embed = new EmbedBuilder()
                        .setTitle("🤝 Configuração de parcerias")
                        .setColor(Reply.BRAND_COLOR)
                        .addField("Sistema", db.partnerEnabled ? "✅ Ativo" : "⏸️ Desativado", true)
                        .addField("Canal de divulgação", channelStatus(g, db.partnerAdChannelId), true)
                        .addField("Canal de análise", channelStatus(g, db.partnerReviewChannelId), true)
                        .addField("Cargo de parceiro", db.partnerRoleId == 0 ? "— (nenhum)" : "<@&" + db.partnerRoleId + ">", true)
                        .addField("Cargo marcado nos anúncios", db.partnerPingRoleId == 0 ? "— (nenhum)" : "<@&" + db.partnerPingRoleId + ">", true)
                        .addField("Regras do painel", Links.clamp(db.partnerRules, 1000), false);
                Reply.embed(e, embed, true);
            }
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }

    private static String channelStatus(Guild g, long id) {
        if (id == 0) return "❌ não configurado";
        return g.getTextChannelById(id) == null ? "⚠️ canal não existe mais" : "<#" + id + ">";
    }

    private static TextChannel textChannel(SlashCommandInteractionEvent e) {
        var channel = e.getOption("canal").getAsChannel();
        if (channel.getType() != ChannelType.TEXT) {
            Reply.of(e, "Escolha um canal de texto.", true);
            return null;
        }
        return channel.asTextChannel();
    }

    // ---------- painel com o botão ----------

    private static void panel(SlashCommandInteractionEvent e) {
        TextChannel target;
        if (e.getOption("canal") != null) {
            target = textChannel(e);
            if (target == null) return;
        } else if (e.getChannel() instanceof TextChannel tc) {
            target = tc;
        } else {
            Reply.of(e, "Use em um canal de texto ou informe o canal.", true);
            return;
        }
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("🤝 Parcerias")
                .setDescription("Quer firmar uma parceria com a gente? Clique no botão abaixo, preencha o formulário "
                        + "e nossa staff vai analisar o seu pedido.\n\n**Antes de pedir:**\n" + Store.db.partnerRules)
                .setColor(Reply.BRAND_COLOR);
        target.sendMessageEmbeds(embed.build())
                .setActionRow(Button.success(BTN_OPEN, "🤝 Solicitar parceria"))
                .queue(m -> Reply.of(e, "✅ Painel publicado em " + target.getAsMention() + ".", true),
                        err -> Reply.of(e, "Não consegui publicar lá: " + err.getMessage(), true));
    }

    // =====================================================================================
    // Formulário do parceiro
    // =====================================================================================

    static void onButton(ButtonInteractionEvent event) {
        String id = event.getComponentId();
        if (BTN_OPEN.equals(id)) {
            openForm(event);
        } else if (id.startsWith(BTN_APPROVE)) {
            approve(event, id.substring(BTN_APPROVE.length()));
        } else if (id.startsWith(BTN_REFUSE)) {
            askRefuseReason(event, id.substring(BTN_REFUSE.length()));
        }
    }

    private static void openForm(ButtonInteractionEvent event) {
        Model.Database db = Store.db;
        if (event.getGuild() == null) return;
        if (!db.partnerEnabled || db.partnerReviewChannelId == 0) {
            event.reply("🚧 O sistema de parcerias não está aberto no momento. Tente novamente mais tarde.")
                    .setEphemeral(true).queue();
            return;
        }
        long userId = event.getUser().getIdLong();
        boolean hasPending = db.partnerships.values().stream()
                .anyMatch(p -> p.requesterId == userId && "PENDENTE".equals(p.status));
        if (hasPending) {
            event.reply("⏳ Você já tem um pedido de parceria em análise. Aguarde a resposta da staff.")
                    .setEphemeral(true).queue();
            return;
        }
        Modal modal = buildForm();
        event.replyModal(modal).queue();
    }

    /** Formulário que o parceiro preenche (5 campos, o máximo que o Discord permite num modal). */
    static Modal buildForm() {
        return Modal.create(MODAL_FORM, "Pedido de parceria")
                .addComponents(
                        ActionRow.of(TextInput.create("nome", "Nome do seu servidor", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(80).build()),
                        ActionRow.of(TextInput.create("convite", "Convite permanente do servidor", TextInputStyle.SHORT)
                                .setPlaceholder("https://discord.gg/seuconvite")
                                .setRequired(true).setMaxLength(120).build()),
                        ActionRow.of(TextInput.create("descricao", "Descrição (aparece no anúncio)", TextInputStyle.PARAGRAPH)
                                .setPlaceholder("Fale sobre o servidor, o tema, o que ele oferece...")
                                .setRequired(true).setMinLength(30).setMaxLength(900).build()),
                        ActionRow.of(TextInput.create("banner", "Link de imagem/banner (opcional)", TextInputStyle.SHORT)
                                .setPlaceholder("https://...png / .jpg / .gif")
                                .setRequired(false).setMaxLength(400).build()),
                        ActionRow.of(TextInput.create("obs", "Observações para a staff (opcional)", TextInputStyle.PARAGRAPH)
                                .setRequired(false).setMaxLength(500).build()))
                .build();
    }

    static void onModal(ModalInteractionEvent event) {
        String id = event.getModalId();
        if (MODAL_FORM.equals(id)) {
            submitForm(event);
        } else if (id.startsWith(MODAL_REFUSE)) {
            submitRefusal(event, id.substring(MODAL_REFUSE.length()));
        }
    }

    private static void submitForm(ModalInteractionEvent event) {
        Model.Database db = Store.db;
        Guild guild = event.getGuild();
        if (guild == null) return;
        TextChannel review = guild.getTextChannelById(db.partnerReviewChannelId);
        if (!db.partnerEnabled || review == null) {
            event.reply("🚧 O sistema de parcerias não está aberto no momento.").setEphemeral(true).queue();
            return;
        }
        String name = value(event, "nome");
        String inviteRaw = value(event, "convite");
        String description = value(event, "descricao");
        String banner = Links.normalize(value(event, "banner"));
        String notes = value(event, "obs");

        String code = Links.extractInviteCode(inviteRaw);
        if (code == null) {
            event.reply("❌ Esse convite não parece válido. Use um link como `https://discord.gg/seuconvite`.")
                    .setEphemeral(true).queue();
            return;
        }
        if (banner != null && !Links.isHttpUrl(banner)) {
            event.reply("❌ O link da imagem/banner não é válido. Deixe em branco ou use um link completo (https://...).")
                    .setEphemeral(true).queue();
            return;
        }

        event.deferReply(true).queue();
        Invite.resolve(event.getJDA(), code, true).queue(invite -> {
            Invite.Guild partner = invite.getGuild();
            if (partner == null) {
                event.getHook().sendMessage("❌ Esse convite não é de um servidor.").setEphemeral(true).queue();
                return;
            }
            if (partner.getIdLong() == guild.getIdLong()) {
                event.getHook().sendMessage("❌ Esse é o convite do nosso próprio servidor. Envie o convite do **seu** servidor.")
                        .setEphemeral(true).queue();
                return;
            }
            if (alreadyPartnered(partner.getIdLong())) {
                event.getHook().sendMessage("ℹ️ Já existe uma parceria (ou pedido em análise) com esse servidor.")
                        .setEphemeral(true).queue();
                return;
            }
            Model.Partnership p = new Model.Partnership();
            p.id = UUID.randomUUID().toString().substring(0, 6);
            p.requesterId = event.getUser().getIdLong();
            p.serverName = name;
            p.inviteCode = code;
            p.inviteUrl = "https://discord.gg/" + code;
            p.description = description;
            p.bannerUrl = banner;
            p.notes = notes.isEmpty() ? null : notes;
            fillFromInvite(p, partner);
            p.createdAt = System.currentTimeMillis();
            p.reviewChannelId = review.getIdLong();

            review.sendMessageEmbeds(reviewEmbed(p, partner.getName()).build())
                    .setActionRow(
                            Button.success(BTN_APPROVE + p.id, "✅ Aprovar"),
                            Button.danger(BTN_REFUSE + p.id, "❌ Recusar"),
                            Button.link(p.inviteUrl, "🔎 Ver convite"))
                    .queue(msg -> {
                        p.reviewMessageId = msg.getIdLong();
                        db.partnerships.put(p.id, p);
                        Store.save();
                        event.getHook().sendMessage("✅ Pedido **#" + p.id + "** enviado! A staff vai analisar e "
                                + "você receberá a resposta por mensagem privada (deixe suas DMs abertas).")
                                .setEphemeral(true).queue();
                    }, err -> event.getHook().sendMessage("❌ Não consegui enviar seu pedido para a staff: "
                            + err.getMessage()).setEphemeral(true).queue());
        }, err -> event.getHook().sendMessage("❌ Não consegui validar esse convite. Ele pode ter expirado ou estar "
                + "errado. Gere um convite **permanente** e tente de novo.").setEphemeral(true).queue());
    }

    private static boolean alreadyPartnered(long partnerGuildId) {
        return Store.db.partnerships.values().stream().anyMatch(p ->
                p.partnerGuildId == partnerGuildId
                        && ("PENDENTE".equals(p.status) || "APROVADA".equals(p.status)));
    }

    private static void fillFromInvite(Model.Partnership p, Invite.Guild g) {
        p.partnerGuildId = g.getIdLong();
        p.iconUrl = g.getIconUrl();
        p.memberCount = Math.max(g.getMemberCount(), 0);
        p.onlineCount = Math.max(g.getOnlineCount(), 0);
    }

    private static String value(ModalInteractionEvent event, String id) {
        var mapping = event.getValue(id);
        return mapping == null ? "" : mapping.getAsString().trim();
    }

    // =====================================================================================
    // Aprovar / Recusar (botões no canal da staff)
    // =====================================================================================

    private static void approve(ButtonInteractionEvent event, String id) {
        Guild guild = event.getGuild();
        if (guild == null) return;
        if (!Permissions.canUse(event.getUser().getIdLong(), event.getMember(), Permissions.GROUP_PARCERIAS)) {
            event.reply("🚫 Você não tem permissão para analisar parcerias.").setEphemeral(true).queue();
            return;
        }
        Model.Partnership p = Store.db.partnerships.get(id);
        if (p == null || !"PENDENTE".equals(p.status)) {
            event.reply("Esse pedido já foi resolvido (ou não existe mais).").setEphemeral(true).queue();
            return;
        }
        event.deferEdit().queue();
        long staffId = event.getUser().getIdLong();
        publishAd(event.getJDA(), guild, p, staffId, () -> {
            event.getHook().editOriginalEmbeds(reviewEmbed(p, null).build()).setComponents(List.of()).queue();
            dm(event.getJDA(), p.requesterId, new EmbedBuilder()
                    .setTitle("🎉 Parceria aprovada!")
                    .setDescription("O pedido do servidor **" + p.serverName + "** foi aprovado em **" + guild.getName()
                            + "**. O anúncio já está no ar!")
                    .setColor(COLOR_OK));
        }, problem -> event.getHook().sendMessage("⚠️ " + problem).setEphemeral(true).queue());
    }

    private static void askRefuseReason(ButtonInteractionEvent event, String id) {
        if (!Permissions.canUse(event.getUser().getIdLong(), event.getMember(), Permissions.GROUP_PARCERIAS)) {
            event.reply("🚫 Você não tem permissão para analisar parcerias.").setEphemeral(true).queue();
            return;
        }
        Model.Partnership p = Store.db.partnerships.get(id);
        if (p == null || !"PENDENTE".equals(p.status)) {
            event.reply("Esse pedido já foi resolvido (ou não existe mais).").setEphemeral(true).queue();
            return;
        }
        Modal modal = buildRefuseModal(id);
        event.replyModal(modal).queue();
    }

    static Modal buildRefuseModal(String id) {
        return Modal.create(MODAL_REFUSE + id, "Recusar parceria")
                .addComponents(ActionRow.of(TextInput.create("motivo", "Motivo (enviado ao solicitante)", TextInputStyle.PARAGRAPH)
                        .setRequired(false).setMaxLength(400)
                        .setPlaceholder("Opcional, mas ajuda o solicitante a entender a decisão.").build()))
                .build();
    }

    private static void submitRefusal(ModalInteractionEvent event, String id) {
        Guild guild = event.getGuild();
        if (guild == null) return;
        if (!Permissions.canUse(event.getUser().getIdLong(), event.getMember(), Permissions.GROUP_PARCERIAS)) {
            event.reply("🚫 Você não tem permissão para analisar parcerias.").setEphemeral(true).queue();
            return;
        }
        Model.Partnership p = Store.db.partnerships.get(id);
        if (p == null || !"PENDENTE".equals(p.status)) {
            event.reply("Esse pedido já foi resolvido (ou não existe mais).").setEphemeral(true).queue();
            return;
        }
        String reason = value(event, "motivo");
        p.status = "RECUSADA";
        p.handledBy = event.getUser().getIdLong();
        p.handledAt = System.currentTimeMillis();
        p.rejectReason = reason.isEmpty() ? null : reason;
        Store.save();

        TextChannel review = guild.getTextChannelById(p.reviewChannelId);
        if (review != null && p.reviewMessageId != 0) {
            review.editMessageEmbedsById(p.reviewMessageId, reviewEmbed(p, null).build())
                    .setComponents(List.of()).queue(m -> {}, err -> {});
        }
        dm(event.getJDA(), p.requesterId, new EmbedBuilder()
                .setTitle("Parceria não aprovada")
                .setDescription("O pedido do servidor **" + p.serverName + "** em **" + guild.getName()
                        + "** não foi aprovado desta vez."
                        + (p.rejectReason == null ? "" : "\n\n**Motivo:** " + p.rejectReason))
                .setColor(COLOR_NO));
        event.reply("Pedido **#" + p.id + "** recusado.").setEphemeral(true).queue();
    }

    // =====================================================================================
    // Publicação do anúncio
    // =====================================================================================

    /**
     * Publica o anúncio no canal de divulgação, marca como APROVADA, dá o cargo de parceiro e avisa o resultado.
     * Só marca como aprovada se a mensagem realmente foi enviada.
     */
    private static void publishAd(JDA jda, Guild guild, Model.Partnership p, long staffId,
                                  Runnable onOk, Consumer<String> onProblem) {
        Model.Database db = Store.db;
        TextChannel ad = guild.getTextChannelById(db.partnerAdChannelId);
        if (ad == null) {
            onProblem.accept("O canal de divulgação não está configurado (ou foi apagado). "
                    + "Use `/parceria canal-divulgacao`.");
            return;
        }
        StringBuilder content = new StringBuilder();
        if (db.partnerPingRoleId != 0 && guild.getRoleById(db.partnerPingRoleId) != null) {
            content.append("<@&").append(db.partnerPingRoleId).append("> ");
        }
        content.append("🤝 Nova parceria com **").append(p.serverName).append("**!");

        ad.sendMessage(content.toString())
                .setEmbeds(adEmbed(p).build())
                .setActionRow(Button.link(p.inviteUrl, "🚀 Entrar no servidor"))
                .setAllowedMentions(EnumSet.of(Message.MentionType.ROLE))
                .queue(msg -> {
                    p.status = "APROVADA";
                    p.handledBy = staffId;
                    p.handledAt = System.currentTimeMillis();
                    p.adChannelId = ad.getIdLong();
                    p.adMessageId = msg.getIdLong();
                    Store.save();
                    giveRole(guild, p.requesterId);
                    onOk.run();
                }, err -> onProblem.accept("Não consegui publicar no canal de divulgação ("
                        + err.getMessage() + "). Confira se eu tenho permissão de enviar mensagens e links incorporados lá."));
    }

    private static void giveRole(Guild guild, long userId) {
        long roleId = Store.db.partnerRoleId;
        if (roleId == 0 || userId == 0) return;
        var role = guild.getRoleById(roleId);
        if (role == null) return;
        guild.retrieveMemberById(userId).queue(
                member -> guild.addRoleToMember(member, role).queue(v -> {}, err -> {}),
                err -> {});
    }

    private static void dm(JDA jda, long userId, EmbedBuilder embed) {
        if (userId == 0) return;
        jda.retrieveUserById(userId).queue(
                user -> user.openPrivateChannel().queue(
                        pc -> pc.sendMessageEmbeds(embed.build()).queue(v -> {}, err -> {}),
                        err -> {}),
                err -> {});
    }

    /** O anúncio que vai pro canal de divulgação. */
    private static EmbedBuilder adEmbed(Model.Partnership p) {
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("🤝 " + Links.clamp(p.serverName, 200))
                .setDescription(Links.clamp(p.description, 3500))
                .setColor(Reply.BRAND_COLOR)
                .setFooter("Parceria #" + p.id)
                .setTimestamp(Instant.now());
        if (p.memberCount > 0) {
            embed.addField("👥 Membros", p.memberCount + (p.onlineCount > 0 ? "  •  🟢 " + p.onlineCount + " online" : ""), true);
        }
        if (p.requesterId != 0) {
            embed.addField("👤 Representante", "<@" + p.requesterId + ">", true);
        }
        embed.addField("🔗 Convite", "[Clique para entrar](" + p.inviteUrl + ")", true);
        if (p.iconUrl != null) embed.setThumbnail(p.iconUrl);
        if (p.bannerUrl != null) embed.setImage(p.bannerUrl);
        return embed;
    }

    /** O pedido que a staff analisa (muda de cor/rodapé conforme o status). */
    private static EmbedBuilder reviewEmbed(Model.Partnership p, String realServerName) {
        Color color = switch (p.status) {
            case "APROVADA" -> COLOR_OK;
            case "RECUSADA" -> COLOR_NO;
            case "REMOVIDA" -> COLOR_REMOVED;
            default -> COLOR_PENDING;
        };
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("🤝 Pedido de parceria #" + p.id + " — " + Links.clamp(p.serverName, 150))
                .setDescription(Links.clamp(p.description, 3000))
                .setColor(color)
                .addField("👤 Solicitante", "<@" + p.requesterId + ">", true)
                .addField("👥 Membros", p.memberCount + " (🟢 " + p.onlineCount + " online)", true)
                .addField("🔗 Convite", p.inviteUrl, false);
        if (realServerName != null && !realServerName.equalsIgnoreCase(p.serverName)) {
            embed.addField("⚠️ Nome no Discord é diferente", "O convite aponta para **" + realServerName + "**.", false);
        }
        if (p.notes != null) embed.addField("📝 Observações do solicitante", Links.clamp(p.notes, 500), false);
        if (p.iconUrl != null) embed.setThumbnail(p.iconUrl);
        if (p.bannerUrl != null) embed.setImage(p.bannerUrl);
        switch (p.status) {
            case "APROVADA" -> embed.addField("✅ Aprovada",
                    "por <@" + p.handledBy + "> • <t:" + (p.handledAt / 1000) + ":R>", false);
            case "RECUSADA" -> embed.addField("❌ Recusada",
                    "por <@" + p.handledBy + "> • <t:" + (p.handledAt / 1000) + ":R>"
                            + (p.rejectReason == null ? "" : "\nMotivo: " + p.rejectReason), false);
            default -> embed.setFooter("Aguardando análise • use os botões abaixo");
        }
        return embed;
    }

    // =====================================================================================
    // /parceria divulgar  (a staff publica direto, sem formulário)
    // =====================================================================================

    private static void publishDirect(SlashCommandInteractionEvent e) {
        String code = Links.extractInviteCode(e.getOption("convite").getAsString());
        if (code == null) {
            Reply.of(e, "❌ Convite inválido. Use algo como `https://discord.gg/abc123`.", true);
            return;
        }
        String banner = e.getOption("imagem") == null ? null : Links.normalize(e.getOption("imagem").getAsString());
        if (banner != null && !Links.isHttpUrl(banner)) {
            Reply.of(e, "❌ O link da imagem não é válido (use https://...).", true);
            return;
        }
        if (Store.db.partnerAdChannelId == 0) {
            Reply.of(e, "❌ Configure primeiro o canal com `/parceria canal-divulgacao`.", true);
            return;
        }
        String name = Links.clamp(e.getOption("nome").getAsString().trim(), 80);
        String description = Links.clamp(e.getOption("descricao").getAsString().replace("\\n", "\n").trim(), 1500);
        long rep = e.getOption("representante") == null ? 0 : e.getOption("representante").getAsUser().getIdLong();
        Guild guild = e.getGuild();

        e.deferReply(true).queue();
        Invite.resolve(e.getJDA(), code, true).queue(invite -> {
            Invite.Guild partner = invite.getGuild();
            if (partner == null) {
                e.getHook().sendMessage("❌ Esse convite não é de um servidor.").setEphemeral(true).queue();
                return;
            }
            if (alreadyPartnered(partner.getIdLong())) {
                e.getHook().sendMessage("ℹ️ Já existe uma parceria ativa (ou pedido em análise) com esse servidor. "
                        + "Use `/parceria listar`.").setEphemeral(true).queue();
                return;
            }
            Model.Partnership p = new Model.Partnership();
            p.id = UUID.randomUUID().toString().substring(0, 6);
            p.requesterId = rep;
            p.serverName = name;
            p.inviteCode = code;
            p.inviteUrl = "https://discord.gg/" + code;
            p.description = description;
            p.bannerUrl = banner;
            p.createdAt = System.currentTimeMillis();
            fillFromInvite(p, partner);
            publishAd(e.getJDA(), guild, p, e.getUser().getIdLong(), () -> {
                Store.db.partnerships.put(p.id, p);
                Store.save();
                e.getHook().sendMessage("✅ Parceria **#" + p.id + "** publicada em <#" + p.adChannelId + ">.")
                        .setEphemeral(true).queue();
            }, problem -> e.getHook().sendMessage("⚠️ " + problem).setEphemeral(true).queue());
        }, err -> e.getHook().sendMessage("❌ Não consegui validar esse convite (expirado ou inválido).")
                .setEphemeral(true).queue());
    }

    // =====================================================================================
    // listar / remover / estatísticas
    // =====================================================================================

    private static void list(SlashCommandInteractionEvent e) {
        Guild guild = e.getGuild();
        List<Model.Partnership> active = Store.db.partnerships.values().stream()
                .filter(p -> "APROVADA".equals(p.status))
                .sorted(Comparator.comparingLong((Model.Partnership p) -> p.handledAt).reversed())
                .limit(20).toList();
        long pending = Store.db.partnerships.values().stream().filter(p -> "PENDENTE".equals(p.status)).count();
        StringBuilder text = new StringBuilder();
        if (active.isEmpty()) {
            text.append("Nenhuma parceria ativa ainda.");
        }
        for (Model.Partnership p : active) {
            String name = Links.clamp(p.serverName, 60).replace("[", "(").replace("]", ")");
            String label = p.adMessageId == 0 ? "**" + name + "**"
                    : "[" + name + "](https://discord.com/channels/" + guild.getId() + "/" + p.adChannelId + "/" + p.adMessageId + ")";
            text.append("`#").append(p.id).append("` ").append(label);
            if (p.requesterId != 0) text.append(" • <@").append(p.requesterId).append(">");
            text.append(" • <t:").append(p.handledAt / 1000).append(":d>\n");
        }
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("🤝 Parcerias ativas")
                .setDescription(Links.clamp(text.toString(), 4000))
                .setFooter(pending + " pedido(s) aguardando análise")
                .setColor(Reply.BRAND_COLOR);
        Reply.embed(e, embed, true);
    }

    private static void remove(SlashCommandInteractionEvent e) {
        String id = e.getOption("id").getAsString().trim().replace("#", "");
        Model.Partnership p = Store.db.partnerships.get(id);
        if (p == null) {
            Reply.of(e, "Não encontrei a parceria `#" + id + "`. Veja os IDs em `/parceria listar`.", true);
            return;
        }
        if ("REMOVIDA".equals(p.status)) {
            Reply.of(e, "Essa parceria já foi removida.", true);
            return;
        }
        Guild guild = e.getGuild();
        boolean wasApproved = "APROVADA".equals(p.status);
        p.status = "REMOVIDA";
        p.handledBy = e.getUser().getIdLong();
        p.handledAt = System.currentTimeMillis();
        Store.save();

        if (p.adMessageId != 0) {
            TextChannel ad = guild.getTextChannelById(p.adChannelId);
            if (ad != null) ad.deleteMessageById(p.adMessageId).queue(v -> {}, err -> {});
        }
        TextChannel review = guild.getTextChannelById(p.reviewChannelId);
        if (review != null && p.reviewMessageId != 0) {
            review.editMessageEmbedsById(p.reviewMessageId, reviewEmbed(p, null).build())
                    .setComponents(List.of()).queue(m -> {}, err -> {});
        }
        // Tira o cargo de parceiro só se o representante não tiver outra parceria ativa.
        boolean otherActive = Store.db.partnerships.values().stream().anyMatch(o ->
                o != p && o.requesterId == p.requesterId && "APROVADA".equals(o.status));
        if (wasApproved && !otherActive && Store.db.partnerRoleId != 0 && p.requesterId != 0) {
            var role = guild.getRoleById(Store.db.partnerRoleId);
            if (role != null) {
                guild.retrieveMemberById(p.requesterId).queue(
                        m -> guild.removeRoleFromMember(m, role).queue(v -> {}, err -> {}), err -> {});
            }
        }
        BotLog.write(guild, "🤝 Parceria #" + p.id + " (" + p.serverName + ") removida por " + e.getUser().getAsTag());
        Reply.of(e, "🗑️ Parceria **#" + p.id + "** removida (anúncio apagado e cargo retirado, se aplicável).", true);
    }

    private static void stats(SlashCommandInteractionEvent e) {
        Map<String, Long> byStatus = new HashMap<>();
        Map<Long, Long> byStaff = new HashMap<>();
        for (Model.Partnership p : Store.db.partnerships.values()) {
            byStatus.merge(p.status, 1L, Long::sum);
            if (("APROVADA".equals(p.status) || "RECUSADA".equals(p.status)) && p.handledBy != 0) {
                byStaff.merge(p.handledBy, 1L, Long::sum);
            }
        }
        StringBuilder top = new StringBuilder();
        byStaff.entrySet().stream()
                .sorted(Map.Entry.<Long, Long>comparingByValue().reversed())
                .limit(5)
                .forEach(en -> top.append("<@").append(en.getKey()).append("> — ").append(en.getValue()).append("\n"));
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("📊 Estatísticas de parcerias")
                .setColor(Reply.BRAND_COLOR)
                .addField("✅ Ativas", String.valueOf(byStatus.getOrDefault("APROVADA", 0L)), true)
                .addField("⏳ Em análise", String.valueOf(byStatus.getOrDefault("PENDENTE", 0L)), true)
                .addField("❌ Recusadas", String.valueOf(byStatus.getOrDefault("RECUSADA", 0L)), true)
                .addField("🗑️ Removidas", String.valueOf(byStatus.getOrDefault("REMOVIDA", 0L)), true)
                .addField("🏅 Staff que mais analisou", top.length() == 0 ? "—" : top.toString(), false);
        Reply.embed(e, embed, true);
    }
}
