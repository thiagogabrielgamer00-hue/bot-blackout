package br.blackout.community;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;

import java.time.Instant;
import java.time.Duration;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/** Comandos de utilidade/diversão soltos: ping, stats, 8-bola, moeda, dado, AFK, lembrete, sugestão. */
final class FunHandlers {

    private static final Random RANDOM = new Random();
    private static final List<String> EIGHT_BALL = List.of(
            "É certo.", "Sem dúvidas.", "Sim, definitivamente.", "Provavelmente sim.", "As perspectivas são boas.",
            "Resposta nebulosa, tente de novo.", "Pergunte novamente mais tarde.", "Melhor não te dizer agora.",
            "Não conte com isso.", "Minha resposta é não.", "As perspectivas não são boas.", "Muito duvidoso.");

    private FunHandlers() {}

    // ---------- Ping / Stats ----------

    static void ping(SlashCommandInteractionEvent e) {
        long start = System.currentTimeMillis();
        e.reply("🏓 Calculando...").queue(hook ->
                hook.editOriginal("🏓 Pong! Latência da API: " + e.getJDA().getGatewayPing() + "ms · Round-trip: "
                        + (System.currentTimeMillis() - start) + "ms").queue());
    }

    static void stats(SlashCommandInteractionEvent e) {
        var jda = e.getJDA();
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("📊 Estatísticas do bot")
                .addField("Servidores", String.valueOf(jda.getGuilds().size()), true)
                .addField("Usuários em cache", String.valueOf(jda.getUsers().size()), true)
                .addField("Ping da gateway", jda.getGatewayPing() + "ms", true)
                .addField("Perfis de RP", String.valueOf(Store.db.profiles.size()), true)
                .addField("Comandos customizados", String.valueOf(Store.db.customCommands.size()), true)
                .addField("Sorteios ativos", String.valueOf(Store.db.giveaways.values().stream().filter(g -> !g.ended).count()), true)
                .setColor(Reply.BRAND_COLOR);
        Reply.embed(e, embed, false);
    }

    // ---------- Diversão simples ----------

    static void eightBall(SlashCommandInteractionEvent e) {
        String pergunta = e.getOption("pergunta").getAsString();
        String resposta = EIGHT_BALL.get(RANDOM.nextInt(EIGHT_BALL.size()));
        Reply.of(e, "🎱 **Pergunta:** " + pergunta + "\n**Resposta:** " + resposta, false);
    }

    static void coinFlip(SlashCommandInteractionEvent e) {
        boolean heads = RANDOM.nextBoolean();
        Reply.of(e, heads ? "🪙 Caiu **cara**!" : "🪙 Caiu **coroa**!", false);
    }

    static void dice(SlashCommandInteractionEvent e) {
        int lados = e.getOption("lados") == null ? 6 : e.getOption("lados").getAsInt();
        if (lados < 2 || lados > 1000) {
            Reply.of(e, "Use um dado de 2 a 1000 lados.", true);
            return;
        }
        int resultado = 1 + RANDOM.nextInt(lados);
        Reply.of(e, "🎲 Você rolou um dado de " + lados + " lados e tirou **" + resultado + "**.", false);
    }

    // ---------- AFK ----------

    static void afkToggle(SlashCommandInteractionEvent e) {
        long userId = e.getUser().getIdLong();
        if (Store.db.afk.containsKey(userId)) {
            Store.db.afk.remove(userId);
            Store.save();
            Reply.of(e, "👋 Seu status de AFK foi removido.", true);
            return;
        }
        String motivo = e.getOption("motivo") == null ? "AFK" : e.getOption("motivo").getAsString();
        Store.db.afk.put(userId, new Model.AfkData(motivo, System.currentTimeMillis()));
        Store.save();
        Reply.of(e, "💤 Marcado(a) como AFK: " + motivo, false);
    }

    /** Chamado para toda mensagem não-bot. Remove o AFK de quem voltou e avisa quem mencionou alguém AFK. */
    static void handleAfk(MessageReceivedEvent event) {
        long authorId = event.getAuthor().getIdLong();
        Model.AfkData mine = Store.db.afk.remove(authorId);
        if (mine != null) {
            Store.save();
            event.getChannel().sendMessage("👋 Bem-vindo(a) de volta, " + event.getAuthor().getAsMention() + "! Removi seu AFK.")
                    .queue(m -> m.delete().queueAfter(8, java.util.concurrent.TimeUnit.SECONDS), err -> {});
        }
        if (event.getMessage().getMentions().getUsers().isEmpty()) return;
        StringBuilder notices = new StringBuilder();
        for (User mentioned : event.getMessage().getMentions().getUsers()) {
            Model.AfkData data = Store.db.afk.get(mentioned.getIdLong());
            if (data == null) continue;
            long minutesAgo = Duration.ofMillis(System.currentTimeMillis() - data.since).toMinutes();
            notices.append("💤 ").append(mentioned.getAsMention()).append(" está AFK: ").append(data.reason)
                    .append(" (há ").append(minutesAgo).append(" min)\n");
        }
        if (notices.length() > 0) {
            event.getChannel().sendMessage(notices.toString()).queue(m -> m.delete().queueAfter(10, java.util.concurrent.TimeUnit.SECONDS), err -> {});
        }
    }

    // ---------- Lembretes ----------

    static void remind(SlashCommandInteractionEvent e) {
        String sub = e.getSubcommandName();
        if ("listar".equals(sub)) {
            var mine = Store.db.reminders.values().stream()
                    .filter(r -> r.userId == e.getUser().getIdLong()).toList();
            if (mine.isEmpty()) {
                Reply.of(e, "Você não tem lembretes pendentes.", true);
                return;
            }
            StringBuilder text = new StringBuilder("**Seus lembretes:**\n");
            for (Model.Reminder r : mine) {
                text.append("• `").append(r.id).append("` — <t:").append(r.dueAtEpochMillis / 1000).append(":R> — ").append(r.message).append("\n");
            }
            Reply.of(e, text.toString(), true);
            return;
        }
        if ("cancelar".equals(sub)) {
            String id = e.getOption("id").getAsString();
            Model.Reminder r = Store.db.reminders.get(id);
            if (r == null || r.userId != e.getUser().getIdLong()) {
                Reply.of(e, "Lembrete não encontrado (ou não é seu).", true);
                return;
            }
            Store.db.reminders.remove(id);
            Store.save();
            Reply.of(e, "Lembrete cancelado.", true);
            return;
        }
        int minutos = e.getOption("minutos").getAsInt();
        if (minutos < 1 || minutos > 10080) {
            Reply.of(e, "Use de 1 a 10080 minutos (7 dias).", true);
            return;
        }
        String mensagem = e.getOption("mensagem").getAsString();
        String id = UUID.randomUUID().toString().substring(0, 8);
        long dueAt = System.currentTimeMillis() + Duration.ofMinutes(minutos).toMillis();
        Store.db.reminders.put(id, new Model.Reminder(id, e.getUser().getIdLong(), e.getChannel().getIdLong(), mensagem, dueAt));
        Store.save();
        Reply.of(e, "⏰ Beleza! Vou te lembrar em " + minutos + " minuto(s): " + mensagem, true);
    }

    /** Roda periodicamente (ver Main). Dispara e remove lembretes vencidos. */
    static void checkDueReminders(net.dv8tion.jda.api.JDA jda) {
        if (Store.db.reminders.isEmpty()) return;
        long now = System.currentTimeMillis();
        var due = Store.db.reminders.values().stream().filter(r -> r.dueAtEpochMillis <= now).toList();
        if (due.isEmpty()) return;
        for (Model.Reminder r : due) {
            var channel = jda.getTextChannelById(r.channelId);
            if (channel != null) {
                channel.sendMessage("⏰ <@" + r.userId + "> lembrete: " + r.message).queue(m -> {}, err -> {});
            }
            Store.db.reminders.remove(r.id);
        }
        Store.save();
    }

    // ---------- Sugestões ----------

    static void suggestionConfig(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        String sub = e.getSubcommandName();
        if ("canal".equals(sub)) {
            Store.db.suggestionChannelId = e.getOption("canal").getAsChannel().getIdLong();
            Store.db.suggestionEnabled = true;
            Store.save();
            Reply.of(e, "Canal de sugestões definido em <#" + Store.db.suggestionChannelId + ">.", true);
            return;
        }
        Store.db.suggestionEnabled = e.getOption("ativo").getAsBoolean();
        Store.save();
        Reply.of(e, "Sistema de sugestões " + (Store.db.suggestionEnabled ? "ativado." : "desativado."), true);
    }

    static void suggestionSend(SlashCommandInteractionEvent e) {
        if (!Store.db.suggestionEnabled || Store.db.suggestionChannelId == 0 || e.getGuild() == null) {
            Reply.of(e, "O sistema de sugestões não está configurado. Peça a um admin para usar `/sugestao canal`.", true);
            return;
        }
        var channel = e.getGuild().getTextChannelById(Store.db.suggestionChannelId);
        if (channel == null) {
            Reply.of(e, "O canal de sugestões configurado não existe mais.", true);
            return;
        }
        String texto = e.getOption("texto").getAsString();
        EmbedBuilder embed = new EmbedBuilder()
                .setAuthor(e.getUser().getName(), null, e.getUser().getEffectiveAvatarUrl())
                .setDescription(texto)
                .setColor(Reply.BRAND_COLOR)
                .setFooter("Sugestão")
                .setTimestamp(Instant.now());
        e.deferReply(true).queue();
        channel.sendMessageEmbeds(embed.build()).queue(msg -> {
            msg.addReaction(net.dv8tion.jda.api.entities.emoji.Emoji.fromUnicode("👍")).queue();
            msg.addReaction(net.dv8tion.jda.api.entities.emoji.Emoji.fromUnicode("👎")).queue();
            e.getHook().sendMessage("✅ Sugestão enviada em " + channel.getAsMention() + "!").setEphemeral(true).queue();
        }, error -> e.getHook().sendMessage("Não consegui enviar: " + error.getMessage()).setEphemeral(true).queue());
    }
}
