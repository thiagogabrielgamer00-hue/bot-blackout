package br.blackout.community;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.entities.emoji.Emoji;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.components.buttons.Button;

import java.time.Instant;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;

final class UtilityHandlers {

    private UtilityHandlers() {}

    static void embed(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_DIVERSAO)) return;
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle(Links.clamp(e.getOption("titulo").getAsString(), 250))
                .setDescription(Links.clamp(e.getOption("texto").getAsString().replace("\\n", "\n"), 4000))
                .setColor(Links.parseColor(optString(e, "cor"), Reply.BRAND_COLOR));
        if (!applyImage(e, embed)) return;
        List<Button> buttons = readLinkButtons(e);
        if (buttons == null) return;
        deliver(e, embed, null, buttons, EnumSet.noneOf(Message.MentionType.class));
    }

    private static String optString(SlashCommandInteractionEvent e, String name) {
        return e.getOption(name) == null ? null : e.getOption(name).getAsString();
    }

    /** Aplica a opção "imagem" ao embed. Retorna false (já respondendo o erro) se o link for inválido. */
    private static boolean applyImage(SlashCommandInteractionEvent e, EmbedBuilder embed) {
        String raw = optString(e, "imagem");
        if (raw == null) return true;
        String url = Links.normalize(raw);
        if (!Links.isHttpUrl(url)) {
            Reply.of(e, "❌ O link da imagem não é válido. Use um endereço completo, ex.: https://site.com/banner.png", true);
            return false;
        }
        embed.setImage(url);
        return true;
    }

    /**
     * Lê link/botao e link2/botao2 e devolve botões de link clicáveis.
     * Retorna null (já respondendo o erro) se algum link for inválido.
     */
    private static List<Button> readLinkButtons(SlashCommandInteractionEvent e) {
        List<Button> buttons = new ArrayList<>();
        String[][] pairs = {{"link", "botao"}, {"link2", "botao2"}};
        for (String[] pair : pairs) {
            String raw = optString(e, pair[0]);
            if (raw == null) continue;
            String url = Links.normalize(raw);
            if (!Links.isHttpUrl(url)) {
                Reply.of(e, "❌ O link `" + Links.clamp(raw, 100) + "` não é válido. Use um endereço completo, "
                        + "ex.: https://discord.gg/seuconvite", true);
                return null;
            }
            String label = optString(e, pair[1]);
            buttons.add(Button.link(url, label == null || label.isBlank() ? "🔗 Abrir link" : Links.clamp(label.trim(), 80)));
        }
        return buttons;
    }

    /** Envia o embed (com texto de menção e botões opcionais) como resposta pública ao comando. */
    private static void deliver(SlashCommandInteractionEvent e, EmbedBuilder embed, String content,
                                List<Button> buttons, EnumSet<Message.MentionType> allowedMentions) {
        e.deferReply().queue();
        var action = e.getHook().sendMessageEmbeds(embed.build()).setAllowedMentions(allowedMentions);
        if (content != null && !content.isEmpty()) action = action.setContent(content);
        if (!buttons.isEmpty()) action = action.setActionRow(buttons);
        action.queue();
    }

    static void poll(SlashCommandInteractionEvent e) {
        String question = e.getOption("pergunta").getAsString();
        e.reply("📊 **Enquete:** " + question + "\n👍 Sim   •   👎 Não").queue(hook ->
                hook.retrieveOriginal().queue(message -> {
                    message.addReaction(Emoji.fromUnicode("👍")).queue();
                    message.addReaction(Emoji.fromUnicode("👎")).queue();
                }));
    }

    /**
     * /avisar — aviso destacado no canal, com menção de verdade (cargo, usuário, @everyone/@here),
     * título/cor/imagem opcionais e até dois botões de link clicáveis (ex.: convite, site, loja).
     */
    static void announce(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_DIVERSAO)) return;
        String message = Links.clamp(e.getOption("mensagem").getAsString().replace("\\n", "\n"), 4000);
        Role role = e.getOption("cargo") != null ? e.getOption("cargo").getAsRole() : null;
        User user = e.getOption("usuario") != null ? e.getOption("usuario").getAsUser() : null;
        boolean everyone = e.getOption("todos") != null && e.getOption("todos").getAsBoolean();
        boolean here = e.getOption("aqui") != null && e.getOption("aqui").getAsBoolean();

        if ((everyone || here) && e.getGuild() != null) {
            Member author = e.getMember();
            if (author == null || !author.hasPermission(Permission.MESSAGE_MENTION_EVERYONE)) {
                Reply.of(e, "🚫 Você não tem permissão de \"Mencionar @everyone\" neste servidor, então não posso enviar esse aviso mencionando todos.", true);
                return;
            }
        }

        StringBuilder mention = new StringBuilder();
        if (everyone) mention.append("@everyone ");
        else if (here) mention.append("@here ");
        if (role != null) mention.append(role.getAsMention()).append(" ");
        if (user != null) mention.append(user.getAsMention()).append(" ");

        String title = optString(e, "titulo");
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle(title == null || title.isBlank() ? "📢 Aviso" : Links.clamp(title, 250))
                .setDescription(message)
                .setColor(Links.parseColor(optString(e, "cor"), Reply.BRAND_COLOR))
                .setFooter("Enviado por " + e.getUser().getName(), e.getUser().getEffectiveAvatarUrl())
                .setTimestamp(Instant.now());
        if (!applyImage(e, embed)) return;
        List<Button> buttons = readLinkButtons(e);
        if (buttons == null) return;

        var allowed = EnumSet.of(
                Message.MentionType.EVERYONE,
                Message.MentionType.HERE,
                Message.MentionType.ROLE,
                Message.MentionType.USER);
        deliver(e, embed, mention.toString().trim(), buttons, allowed);
    }

    static void role(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO) || e.getGuild() == null) return;
        Member member = e.getOption("usuario").getAsMember();
        Role role = e.getOption("cargo").getAsRole();
        if (member == null) {
            Reply.of(e, "Membro não encontrado.", true);
            return;
        }
        if ("dar".equals(e.getSubcommandName())) {
            e.getGuild().addRoleToMember(member, role).queue(
                    v -> Reply.of(e, "Cargo adicionado.", true),
                    error -> Reply.of(e, "Falha: " + error.getMessage(), true));
        } else {
            e.getGuild().removeRoleFromMember(member, role).queue(
                    v -> Reply.of(e, "Cargo removido.", true),
                    error -> Reply.of(e, "Falha: " + error.getMessage(), true));
        }
    }

    static void userInfo(SlashCommandInteractionEvent e) {
        User user = e.getOption("usuario") == null ? e.getUser() : e.getOption("usuario").getAsUser();
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("Usuário: " + user.getName())
                .setThumbnail(user.getEffectiveAvatarUrl())
                .addField("ID", user.getId(), true)
                .addField("Conta criada em", user.getTimeCreated().toLocalDate().toString(), true)
                .setColor(Reply.BRAND_COLOR);
        Model.LevelData level = Store.db.levels.get(user.getIdLong());
        if (level != null) embed.addField("Nível", String.valueOf(level.level), true);
        Reply.embed(e, embed, false);
    }

    static void serverInfo(SlashCommandInteractionEvent e) {
        if (e.getGuild() == null) {
            Reply.of(e, "Use este comando dentro de um servidor.", true);
            return;
        }
        var guild = e.getGuild();
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle(guild.getName())
                .setThumbnail(guild.getIconUrl())
                .addField("Membros", String.valueOf(guild.getMemberCount()), true)
                .addField("ID", guild.getId(), true)
                .addField("Tema de RP ativo", Store.db.activeTheme, true)
                .setColor(Reply.BRAND_COLOR);
        Reply.embed(e, embed, false);
    }

    static void invite(SlashCommandInteractionEvent e) {
        if (e.getGuild() == null) {
            Reply.of(e, "Use este comando dentro de um servidor.", true);
            return;
        }
        var channel = e.getGuild().getTextChannels().stream()
                .filter(c -> e.getGuild().getSelfMember().hasPermission(c, Permission.CREATE_INSTANT_INVITE))
                .findFirst().orElse(null);
        if (channel == null) {
            Reply.of(e, "Não encontrei um canal onde eu possa criar convites.", true);
            return;
        }
        e.deferReply(true).queue();
        channel.createInvite().setMaxAge(0).queue(
                invite -> e.getHook().sendMessage("🔗 " + invite.getUrl()).setEphemeral(true).queue(),
                error -> e.getHook().sendMessage("Não consegui criar um convite: " + error.getMessage()).setEphemeral(true).queue());
    }

    static void avatar(SlashCommandInteractionEvent e) {
        User user = e.getOption("usuario") == null ? e.getUser() : e.getOption("usuario").getAsUser();
        Reply.of(e, user.getEffectiveAvatarUrl() + "?size=1024", false);
    }

    static void ticket(SlashCommandInteractionEvent e) {
        if (e.getGuild() == null) {
            Reply.of(e, "Use este comando dentro de um servidor.", true);
            return;
        }
        long userId = e.getUser().getIdLong();
        if ("fechar".equals(e.getSubcommandName())) {
            Long channelId = Store.db.tickets.remove(userId);
            if (channelId == null) {
                Reply.of(e, "Você não tem um ticket aberto.", true);
                return;
            }
            var channel = e.getGuild().getTextChannelById(channelId);
            Store.save();
            Reply.of(e, "Ticket fechado.", true);
            if (channel != null) channel.delete().queueAfter(3, java.util.concurrent.TimeUnit.SECONDS);
            return;
        }
        Long existing = Store.db.tickets.get(userId);
        if (existing != null && e.getGuild().getTextChannelById(existing) != null) {
            Reply.of(e, "Você já tem um ticket aberto: <#" + existing + ">", true);
            return;
        }
        String subject = e.getOption("assunto") == null ? "Sem assunto informado" : e.getOption("assunto").getAsString();
        String channelName = "ticket-" + e.getUser().getName().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9-]", "-");
        e.deferReply(true).queue();
        var creation = e.getGuild().createTextChannel(channelName);
        if (Store.db.ticketCategoryId != 0) {
            var category = e.getGuild().getCategoryById(Store.db.ticketCategoryId);
            if (category != null) creation.setParent(category);
        }
        creation.queue(channel -> {
            Store.db.tickets.put(userId, channel.getIdLong());
            Store.save();
            channel.sendMessage("🎫 Ticket de " + e.getUser().getAsMention() + "\nAssunto: " + subject
                            + "\nUm administrador irá responder em breve.")
                    .setActionRow(Button.danger("ticket-close-" + userId, "Fechar ticket"))
                    .queue();
            e.getHook().sendMessage("Ticket criado: " + channel.getAsMention()).setEphemeral(true).queue();
        }, error -> e.getHook().sendMessage("Não consegui criar o ticket: " + error.getMessage()).setEphemeral(true).queue());
    }
}
