package br.blackout.community;

import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.guild.member.GuildMemberJoinEvent;
import net.dv8tion.jda.api.events.guild.member.GuildMemberRemoveEvent;
import net.dv8tion.jda.api.events.interaction.ModalInteractionEvent;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.events.message.react.MessageReactionAddEvent;
import net.dv8tion.jda.api.events.message.react.MessageReactionRemoveEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

final class DiscordListener extends ListenerAdapter {

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        try {
            switch (e.getName()) {
                case "roletar" -> RpHandlers.roll(e);
                case "perfil" -> RpHandlers.profile(e);
                case "tema" -> RpHandlers.theme(e);
                case "atributo" -> RpHandlers.field(e);
                case "giros" -> RpHandlers.rolls(e);
                case "perfil-admin" -> RpHandlers.profileAdmin(e);
                case "registrar" -> RankSyncHandlers.link(e);
                case "desvincular" -> RankSyncHandlers.unlink(e);
                case "vinculo" -> RankSyncHandlers.status(e);
                case "cargo-automatico" -> RankSyncHandlers.admin(e);
                case "permissao" -> PermissionHandlers.handle(e);
                case "warn" -> ModerationHandlers.warn(e);
                case "warnings" -> ModerationHandlers.warnings(e);
                case "mute" -> ModerationHandlers.mute(e);
                case "unmute" -> ModerationHandlers.unmute(e);
                case "kick" -> ModerationHandlers.kick(e);
                case "ban" -> ModerationHandlers.ban(e);
                case "limpar" -> ModerationHandlers.clear(e);
                case "config" -> ConfigHandlers.config(e);
                case "automod" -> ConfigHandlers.automod(e);
                case "nivel-cargo" -> ConfigHandlers.levelRole(e);
                case "verificacao" -> ConfigHandlers.verification(e);
                case "minecraft" -> dispatchMinecraft(e);
                case "embed" -> UtilityHandlers.embed(e);
                case "enquete" -> UtilityHandlers.poll(e);
                case "avisar" -> UtilityHandlers.announce(e);
                case "cargo" -> UtilityHandlers.role(e);
                case "userinfo" -> UtilityHandlers.userInfo(e);
                case "serverinfo" -> UtilityHandlers.serverInfo(e);
                case "avatar" -> UtilityHandlers.avatar(e);
                case "ticket" -> UtilityHandlers.ticket(e);
                case "comando-custom" -> CustomCommands.manage(e);
                case "cargo-reacao" -> ReactionRoles.manage(e);
                case "sorteio" -> dispatchGiveaway(e);
                case "rank" -> LevelSystem.rank(e);
                case "rank-top" -> LevelSystem.top(e);
                case "nivel-admin" -> LevelSystem.admin(e);
                case "slowmode" -> AdminExtraHandlers.slowmode(e);
                case "lock" -> AdminExtraHandlers.lock(e, true);
                case "unlock" -> AdminExtraHandlers.lock(e, false);
                case "apelido" -> AdminExtraHandlers.nick(e);
                case "limpar-usuario" -> AdminExtraHandlers.clearFromUser(e);
                case "ping" -> FunHandlers.ping(e);
                case "stats" -> FunHandlers.stats(e);
                case "bola8" -> FunHandlers.eightBall(e);
                case "moeda" -> FunHandlers.coinFlip(e);
                case "dado" -> FunHandlers.dice(e);
                case "afk" -> FunHandlers.afkToggle(e);
                case "convite" -> UtilityHandlers.invite(e);
                case "lembrete" -> FunHandlers.remind(e);
                case "sugestao" -> dispatchSuggestion(e);
                case "parceria" -> PartnershipHandlers.handle(e);
                default -> Reply.of(e, "Comando ainda não implementado.", true);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            Reply.of(e, "Ocorreu um erro ao executar o comando: " + ex.getMessage(), true);
        }
    }

    private void dispatchMinecraft(SlashCommandInteractionEvent e) {
        switch (e.getSubcommandName()) {
            case "status" -> MinecraftBridge.status(e);
            case "bridge-canal" -> MinecraftBridge.bridgeChannel(e);
            case "bridge-info" -> MinecraftBridge.bridgeInfo(e);
            case "bridge-regerar-chave" -> MinecraftBridge.regenerateSecret(e);
            case "anunciar" -> MinecraftBridge.announce(e);
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }

    private void dispatchSuggestion(SlashCommandInteractionEvent e) {
        switch (e.getSubcommandName()) {
            case "canal", "alternar" -> FunHandlers.suggestionConfig(e);
            case "enviar" -> FunHandlers.suggestionSend(e);
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }

    private void dispatchGiveaway(SlashCommandInteractionEvent e) {
        switch (e.getSubcommandName()) {
            case "criar" -> GiveawayManager.create(e);
            case "finalizar" -> GiveawayManager.finalizeNow(e);
            case "rerolar" -> GiveawayManager.reroll(e);
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }

    @Override
    public void onButtonInteraction(ButtonInteractionEvent event) {
        String id = event.getComponentId();
        try {
            if (id.startsWith("giveaway-join-")) {
                GiveawayManager.onButton(event);
            } else if ("verify".equals(id)) {
                handleVerifyButton(event);
            } else if (id.startsWith("ticket-close-")) {
                handleTicketCloseButton(event);
            } else if (id.startsWith("parceria-")) {
                PartnershipHandlers.onButton(event);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void onModalInteraction(ModalInteractionEvent event) {
        try {
            if (event.getModalId().startsWith("parceria-")) {
                PartnershipHandlers.onModal(event);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            if (!event.isAcknowledged()) {
                event.reply("Ocorreu um erro ao processar o formulário: " + ex.getMessage()).setEphemeral(true).queue();
            }
        }
    }

    private void handleVerifyButton(ButtonInteractionEvent event) {
        if (!Store.db.verificationEnabled || event.getGuild() == null) {
            event.reply("A verificação não está ativa no momento.").setEphemeral(true).queue();
            return;
        }
        var role = event.getGuild().getRoleById(Store.db.verificationRoleId);
        if (role == null) {
            event.reply("O cargo de verificação não existe mais. Avise um administrador.").setEphemeral(true).queue();
            return;
        }
        event.getGuild().addRoleToMember(event.getUser(), role).queue(
                v -> event.reply("✅ Conta verificada! Bem-vindo(a).").setEphemeral(true).queue(),
                error -> event.reply("Não consegui te dar o cargo: " + error.getMessage()).setEphemeral(true).queue());
    }

    private void handleTicketCloseButton(ButtonInteractionEvent event) {
        if (event.getGuild() == null) return;
        long channelId = event.getGuildChannel().getIdLong();
        event.reply("Fechando ticket em 3 segundos...").queue();
        event.getGuildChannel().delete().queueAfter(3, java.util.concurrent.TimeUnit.SECONDS);
        Store.db.tickets.values().removeIf(id -> id == channelId);
        Store.save();
    }

    @Override
    public void onGuildMemberJoin(GuildMemberJoinEvent event) {
        if (Store.db.welcomeEnabled && Store.db.welcomeChannelId != 0) {
            TextChannel channel = event.getGuild().getTextChannelById(Store.db.welcomeChannelId);
            if (channel != null) {
                String text = Store.db.welcomeMessage
                        .replace("{user}", event.getUser().getAsMention())
                        .replace("{server}", event.getGuild().getName())
                        .replace("{count}", String.valueOf(event.getGuild().getMemberCount()));
                channel.sendMessage(text).queue();
            }
        }
        BotLog.write(event.getGuild(), "➡️ Entrada: " + event.getUser().getAsTag());
    }

    @Override
    public void onGuildMemberRemove(GuildMemberRemoveEvent event) {
        if (Store.db.leaveEnabled && Store.db.leaveChannelId != 0) {
            TextChannel channel = event.getGuild().getTextChannelById(Store.db.leaveChannelId);
            if (channel != null) {
                String text = Store.db.leaveMessage
                        .replace("{user}", event.getUser().getAsTag())
                        .replace("{server}", event.getGuild().getName());
                channel.sendMessage(text).queue();
            }
        }
        BotLog.write(event.getGuild(), "⬅️ Saída: " + event.getUser().getAsTag());
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (event.getAuthor().isBot()) return;
        try {
            if (AutoMod.handle(event)) return; // mensagem removida, não processa mais nada
            if (CustomCommands.handle(event)) return;
            if (event.isFromGuild()) FunHandlers.handleAfk(event);
            LevelSystem.onMessage(event);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void onMessageReactionAdd(MessageReactionAddEvent event) {
        try {
            ReactionRoles.onReactionAdd(event);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void onMessageReactionRemove(MessageReactionRemoveEvent event) {
        try {
            ReactionRoles.onReactionRemove(event);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
