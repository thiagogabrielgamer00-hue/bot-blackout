package br.blackout.community;

import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * Filtro automático de mensagens. Roda ANTES de qualquer outra reação a uma mensagem.
 * Retorna true se a mensagem foi removida (para o chamador não processar mais nada nela).
 */
final class AutoMod {

    private static final Pattern URL_PATTERN = Pattern.compile("https?://\\S+", Pattern.CASE_INSENSITIVE);
    private static final Pattern INVITE_PATTERN = Pattern.compile("(discord\\.gg|discord\\.com/invite)/\\S+", Pattern.CASE_INSENSITIVE);

    // Histórico recente de mensagens por usuário, para detectar spam. Não é persistido em disco:
    // é só um controle de curto prazo em memória, reiniciado quando o bot reinicia.
    private static final Map<Long, Deque<Long>> RECENT_MESSAGES = new ConcurrentHashMap<>();

    private AutoMod() {}

    static boolean handle(MessageReceivedEvent event) {
        Model.AutoModConfig cfg = Store.db.automod;
        if (!cfg.enabled) return false;
        if (event.getAuthor().isBot()) return false;
        if (event.isFromGuild()) {
            Member member = event.getMember();
            if (member != null && member.getRoles().stream().anyMatch(role -> cfg.exemptRoleIds.contains(role.getIdLong()))) {
                return false;
            }
        }
        if (cfg.exemptChannelIds.contains(event.getChannel().getIdLong())) return false;

        String content = event.getMessage().getContentRaw();

        // Quem está no grupo "parcerias" (e o dono) pode postar convites e links: divulgar parceiros exige isso.
        boolean linkExempt = event.isFromGuild()
                && Permissions.canUse(event.getAuthor().getIdLong(), event.getMember(), Permissions.GROUP_PARCERIAS);

        if (cfg.blockInvites && !linkExempt && INVITE_PATTERN.matcher(content).find()) {
            return remove(event, "envio de convite de outro servidor");
        }
        if (cfg.blockLinks && !linkExempt && URL_PATTERN.matcher(content).find()) {
            return remove(event, "envio de link não permitido");
        }
        if (!cfg.bannedWords.isEmpty()) {
            String lower = content.toLowerCase(Locale.ROOT);
            for (String word : cfg.bannedWords) {
                if (!word.isBlank() && lower.contains(word)) {
                    return remove(event, "uso de palavra bloqueada");
                }
            }
        }
        if (cfg.blockExcessiveCaps && content.length() >= cfg.capsMinLength) {
            long upper = content.chars().filter(Character::isUpperCase).count();
            long letters = content.chars().filter(Character::isLetter).count();
            if (letters > 0 && (upper * 100L / letters) >= cfg.capsThresholdPercent) {
                return remove(event, "excesso de letras maiúsculas");
            }
        }
        if (cfg.blockSpam && isSpam(event)) {
            return remove(event, "envio repetido de mensagens em curto período (spam)");
        }
        return false;
    }

    private static boolean isSpam(MessageReceivedEvent event) {
        Model.AutoModConfig cfg = Store.db.automod;
        long userId = event.getAuthor().getIdLong();
        long now = System.currentTimeMillis();
        Deque<Long> timestamps = RECENT_MESSAGES.computeIfAbsent(userId, k -> new ArrayDeque<>());
        synchronized (timestamps) {
            timestamps.addLast(now);
            long windowStart = now - (cfg.spamWindowSeconds * 1000L);
            while (!timestamps.isEmpty() && timestamps.peekFirst() < windowStart) {
                timestamps.pollFirst();
            }
            return timestamps.size() >= cfg.spamMessageCount;
        }
    }

    private static boolean remove(MessageReceivedEvent event, String reason) {
        event.getMessage().delete().queue(v -> {}, error -> {});
        event.getChannel().sendMessage(event.getAuthor().getAsMention()
                + ", sua mensagem foi removida automaticamente (" + reason + ").").queue(msg ->
                msg.delete().queueAfter(6, java.util.concurrent.TimeUnit.SECONDS));
        if (event.isFromGuild()) {
            BotLog.write(event.getGuild(), "🛡️ Mensagem de " + event.getAuthor().getAsTag() + " removida pelo automod: " + reason);
        }
        return true;
    }
}
