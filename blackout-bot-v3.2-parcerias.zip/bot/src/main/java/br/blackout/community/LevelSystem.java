package br.blackout.community;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;

import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Sistema simples de XP por mensagem, no estilo Mee6/Loritta.
 * Fórmula: para chegar ao nível N são necessários N*N*100 pontos de XP acumulados.
 * Cada mensagem (respeitando um cooldown de 60s por usuário) dá entre 15 e 25 XP.
 */
final class LevelSystem {

    private static final int COOLDOWN_MILLIS = 60_000;
    private static final Random RANDOM = new Random();

    private LevelSystem() {}

    static void onMessage(MessageReceivedEvent event) {
        if (!Store.db.levelingEnabled) return;
        if (event.getAuthor().isBot() || event.isWebhookMessage()) return;
        if (!event.isFromGuild()) return; // XP só conta em servidor; getGuild() quebraria em DM
        long userId = event.getAuthor().getIdLong();
        Model.LevelData data = Store.db.levels.computeIfAbsent(userId, k -> new Model.LevelData());
        long now = System.currentTimeMillis();
        if (now - data.lastMessageTimestamp < COOLDOWN_MILLIS) return;
        data.lastMessageTimestamp = now;
        data.xp += 15 + RANDOM.nextInt(11);
        int newLevel = levelForXp(data.xp);
        if (newLevel > data.level) {
            data.level = newLevel;
            Store.save();
            announceLevelUp(event, newLevel);
            grantLevelRole(event, newLevel);
        } else {
            Store.save();
        }
    }

    private static void announceLevelUp(MessageReceivedEvent event, int newLevel) {
        event.getChannel().sendMessage("🎉 " + event.getAuthor().getAsMention() + " subiu para o **nível " + newLevel + "**!").queue();
    }

    private static void grantLevelRole(MessageReceivedEvent event, int newLevel) {
        Long roleId = Store.db.levelRoleRewards.get(newLevel);
        if (roleId == null) return;
        var role = event.getGuild().getRoleById(roleId);
        Member member = event.getMember();
        if (role != null && member != null) {
            event.getGuild().addRoleToMember(member, role).queue(v -> {}, error -> {});
        }
    }

    static int levelForXp(long xp) {
        int level = 0;
        while (xpForLevel(level + 1) <= xp) level++;
        return level;
    }

    static long xpForLevel(int level) {
        return (long) level * level * 100L;
    }

    static void rank(SlashCommandInteractionEvent e) {
        User user = e.getOption("usuario") == null ? e.getUser() : e.getOption("usuario").getAsUser();
        Model.LevelData data = Store.db.levels.get(user.getIdLong());
        if (data == null) {
            Reply.of(e, user.getAsMention() + " ainda não tem XP registrado.", true);
            return;
        }
        long nextLevelXp = xpForLevel(data.level + 1);
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("Nível de " + user.getName())
                .setThumbnail(user.getEffectiveAvatarUrl())
                .addField("Nível", String.valueOf(data.level), true)
                .addField("XP total", String.valueOf(data.xp), true)
                .addField("Próximo nível em", (nextLevelXp - data.xp) + " XP", true)
                .setColor(Reply.BRAND_COLOR);
        Reply.embed(e, embed, false);
    }

    /**
     * Administração de nível/XP: /nivel-admin. Permite setar XP ou nível exato de um jogador,
     * somar/subtrair XP, ou zerar — sem precisar que ele mande mensagens pra subir "no grind".
     */
    static void admin(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        User user = e.getOption("usuario").getAsUser();
        Model.LevelData data = Store.db.levels.computeIfAbsent(user.getIdLong(), k -> new Model.LevelData());
        String sub = e.getSubcommandName();
        switch (sub) {
            case "definir-xp" -> {
                long xp = e.getOption("quantidade").getAsLong();
                if (xp < 0) {
                    Reply.of(e, "A quantidade de XP não pode ser negativa.", true);
                    return;
                }
                data.xp = xp;
                data.level = levelForXp(xp);
            }
            case "definir-nivel" -> {
                int level = e.getOption("quantidade").getAsInt();
                if (level < 0) {
                    Reply.of(e, "O nível não pode ser negativo.", true);
                    return;
                }
                data.level = level;
                data.xp = xpForLevel(level);
            }
            case "adicionar-xp" -> {
                long delta = e.getOption("quantidade").getAsLong();
                data.xp = Math.max(0, data.xp + delta);
                data.level = levelForXp(data.xp);
            }
            case "resetar" -> {
                data.xp = 0;
                data.level = 0;
            }
            default -> {
                Reply.of(e, "Subcomando desconhecido.", true);
                return;
            }
        }
        Store.save();
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("Nível/XP atualizado — " + user.getName())
                .addField("Nível", String.valueOf(data.level), true)
                .addField("XP total", String.valueOf(data.xp), true)
                .setColor(Reply.BRAND_COLOR);
        Reply.embed(e, embed, true);
    }

    static void top(SlashCommandInteractionEvent e) {
        List<Map.Entry<Long, Model.LevelData>> sorted = Store.db.levels.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue().xp, a.getValue().xp))
                .limit(10)
                .toList();
        if (sorted.isEmpty()) {
            Reply.of(e, "Ninguém tem XP registrado ainda.", true);
            return;
        }
        StringBuilder text = new StringBuilder("**🏆 Ranking de níveis**\n");
        int position = 1;
        for (Map.Entry<Long, Model.LevelData> entry : sorted) {
            text.append(position).append(". <@").append(entry.getKey()).append("> — Nível ")
                    .append(entry.getValue().level).append(" (").append(entry.getValue().xp).append(" XP)\n");
            position++;
        }
        EmbedBuilder embed = new EmbedBuilder().setDescription(text.toString()).setColor(Reply.BRAND_COLOR);
        Reply.embed(e, embed, false);
    }
}
