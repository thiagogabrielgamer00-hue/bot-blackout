package br.blackout.community;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.message.react.MessageReactionAddEvent;
import net.dv8tion.jda.api.events.message.react.MessageReactionRemoveEvent;

import java.util.HashMap;
import java.util.Map;

final class ReactionRoles {

    private ReactionRoles() {}

    static void manage(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_DIVERSAO)) return;
        String sub = e.getSubcommandName();
        if ("criar".equals(sub)) {
            EmbedBuilder embed = new EmbedBuilder()
                    .setTitle(e.getOption("titulo").getAsString())
                    .setDescription(e.getOption("descricao").getAsString())
                    .setColor(Reply.BRAND_COLOR)
                    .setFooter("Reaja com o emoji correspondente para receber o cargo.");
            e.replyEmbeds(embed.build()).queue(hook ->
                    hook.retrieveOriginal().queue(message -> {
                        Store.db.reactionRoleMenus.put(message.getIdLong(), new HashMap<>());
                        Reply.of(e, "Menu criado. ID da mensagem: `" + message.getId()
                                + "`. Use `/cargo-reacao adicionar-opcao` para associar emojis a cargos.", true);
                    }));
            return;
        }
        if ("adicionar-opcao".equals(sub)) {
            long messageId;
            try {
                messageId = Long.parseLong(e.getOption("id-mensagem").getAsString().trim());
            } catch (NumberFormatException ex) {
                Reply.of(e, "ID de mensagem inválido.", true);
                return;
            }
            Map<String, Long> menu = Store.db.reactionRoleMenus.get(messageId);
            if (menu == null) {
                Reply.of(e, "Essa mensagem não é um menu de cargo por reação criado com `/cargo-reacao criar`.", true);
                return;
            }
            String emoji = e.getOption("emoji").getAsString();
            long roleId = e.getOption("cargo").getAsRole().getIdLong();
            menu.put(emoji, roleId);
            Store.save();
            e.getChannel().retrieveMessageById(messageId).queue(
                    message -> {
                        message.addReaction(net.dv8tion.jda.api.entities.emoji.Emoji.fromFormatted(emoji)).queue(
                                v -> Reply.of(e, "Opção adicionada: " + emoji + " → <@&" + roleId + ">", true),
                                error -> Reply.of(e, "Cargo associado, mas não consegui reagir na mensagem com esse emoji: " + error.getMessage(), true));
                    },
                    error -> Reply.of(e, "Cargo associado, mas não encontrei a mensagem neste canal para reagir automaticamente.", true));
            return;
        }
        Reply.of(e, "Subcomando desconhecido.", true);
    }

    static void onReactionAdd(MessageReactionAddEvent event) {
        if (event.getUser() == null || event.getUser().isBot()) return;
        if (!event.isFromGuild()) return; // getGuild() quebraria em reação de DM
        Map<String, Long> menu = Store.db.reactionRoleMenus.get(event.getMessageIdLong());
        if (menu == null) return;
        Long roleId = menu.get(event.getReaction().getEmoji().getFormatted());
        if (roleId == null) return;
        var role = event.getGuild().getRoleById(roleId);
        if (role == null) return;
        var target = net.dv8tion.jda.api.entities.UserSnowflake.fromId(event.getUserIdLong());
        event.getGuild().addRoleToMember(target, role).queue(v -> {}, error -> {});
    }

    static void onReactionRemove(MessageReactionRemoveEvent event) {
        if (event.getUser() == null || event.getUser().isBot()) return;
        if (!event.isFromGuild()) return; // getGuild() quebraria em reação de DM
        Map<String, Long> menu = Store.db.reactionRoleMenus.get(event.getMessageIdLong());
        if (menu == null) return;
        Long roleId = menu.get(event.getReaction().getEmoji().getFormatted());
        if (roleId == null) return;
        var role = event.getGuild().getRoleById(roleId);
        if (role == null) return;
        var target = net.dv8tion.jda.api.entities.UserSnowflake.fromId(event.getUserIdLong());
        event.getGuild().removeRoleFromMember(target, role).queue(v -> {}, error -> {});
    }
}
