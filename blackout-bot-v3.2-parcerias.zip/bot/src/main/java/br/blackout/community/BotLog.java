package br.blackout.community;

import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;

final class BotLog {

    private BotLog() {}

    static void write(Guild guild, String text) {
        if (guild == null || Store.db.logChannelId == 0) return;
        TextChannel channel = guild.getTextChannelById(Store.db.logChannelId);
        if (channel != null) channel.sendMessage("📋 " + text).queue();
    }
}
