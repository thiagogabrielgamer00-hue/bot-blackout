package br.blackout.community;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Guarda e carrega o estado do bot em data/blackout-community.json.
 * Usar JSON (em vez de serialização binária) foi proposital: é possível abrir o
 * arquivo em qualquer editor de texto para inspecionar ou corrigir algo manualmente
 * em caso de emergência, e ele não quebra entre versões diferentes do Java.
 */
final class Store {

    private static final Path FILE = Paths.get("data", "blackout-community.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    static Model.Database db = new Model.Database();

    static synchronized void load() {
        try {
            Files.createDirectories(FILE.getParent());
            if (Files.exists(FILE)) {
                String json = Files.readString(FILE, StandardCharsets.UTF_8);
                if (!json.isBlank()) {
                    Model.Database loaded = GSON.fromJson(json, Model.Database.class);
                    if (loaded != null) db = loaded;
                }
            }
        } catch (IOException e) {
            throw new IllegalStateException("Não consegui carregar data/blackout-community.json", e);
        }
        if (db.permissionGroups == null) db.permissionGroups = new LinkedHashMap<>();
        for (String group : List.of("rp", "moderacao", "configuracao", "diversao", "parcerias")) {
            db.permissionGroups.putIfAbsent(group, new java.util.HashSet<>());
        }
        if (db.minecraftBridgeSecret == null || db.minecraftBridgeSecret.isBlank()) {
            db.minecraftBridgeSecret = generateSecret();
        }
        if (db.afk == null) db.afk = new java.util.HashMap<>();
        if (db.partnerships == null) db.partnerships = new LinkedHashMap<>();
        if (db.partnerRules == null) db.partnerRules = Model.Database.DEFAULT_PARTNER_RULES;
        if (db.reminders == null) db.reminders = new LinkedHashMap<>();
        if (db.warnings == null) db.warnings = new java.util.HashMap<>();
        if (db.tickets == null) db.tickets = new java.util.HashMap<>();
        if (db.minecraftLinks == null) db.minecraftLinks = new java.util.HashMap<>();
        if (db.levels == null) db.levels = new java.util.HashMap<>();
        if (db.levelRoleRewards == null) db.levelRoleRewards = new LinkedHashMap<>();
        if (db.customCommands == null) db.customCommands = new LinkedHashMap<>();
        if (db.reactionRoleMenus == null) db.reactionRoleMenus = new java.util.HashMap<>();
        if (db.giveaways == null) db.giveaways = new LinkedHashMap<>();
        if (db.profiles == null) db.profiles = new java.util.HashMap<>();
        if (db.themes == null) db.themes = new LinkedHashMap<>();
        if (db.automod == null) db.automod = new Model.AutoModConfig();
        if (db.automod.bannedWords == null) db.automod.bannedWords = new java.util.HashSet<>();
        if (db.automod.exemptRoleIds == null) db.automod.exemptRoleIds = new java.util.HashSet<>();
        if (db.automod.exemptChannelIds == null) db.automod.exemptChannelIds = new java.util.HashSet<>();
        if (db.rankSync == null) db.rankSync = new Model.RankSyncConfig();
        if (db.rankSync.valueToGroup == null) db.rankSync.valueToGroup = new LinkedHashMap<>();
        for (Model.Theme t : db.themes.values()) {
            if (t.fields == null) { t.fields = new LinkedHashMap<>(); continue; }
            for (Model.Field f : t.fields.values()) {
                if (f.options == null) f.options = new ArrayList<>();
                if (f.weights == null) f.weights = new LinkedHashMap<>();
                if (f.optionRoles == null) f.optionRoles = new LinkedHashMap<>();
            }
        }
        seedDefaultTheme();
        save();
    }

    static synchronized void save() {
        try {
            Files.createDirectories(FILE.getParent());
            String json = GSON.toJson(db);
            Files.writeString(FILE, json, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            System.err.println("Falha ao salvar dados: " + e.getMessage());
        }
    }

    private static String generateSecret() {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (int i = 0; i < 32; i++) sb.append(chars.charAt(random.nextInt(chars.length())));
        return sb.toString();
    }

    private static void seedDefaultTheme() {
        if (db.themes.containsKey("medieval")) return;
        Model.Theme t = new Model.Theme("medieval", "Medieval RP");
        t.fields.put("reino", new Model.Field("reino", "Reino", List.of("Eldoria", "Valoria", "Astoria")));
        t.fields.put("classe", new Model.Field("classe", "Classe", List.of("Guerreiro", "Mago", "Arqueiro")));
        t.fields.put("subclasse", new Model.Field("subclasse", "Subclasse", List.of("Ferreiro", "Caçador", "Pescador")));
        db.themes.put(t.id, t);
    }

    static Model.Theme theme() {
        return db.themes.get(db.activeTheme);
    }

    static Model.Profile profile(long userId) {
        Model.UserProfiles user = db.profiles.computeIfAbsent(userId, k -> new Model.UserProfiles());
        if (user.byTheme == null) user.byTheme = new LinkedHashMap<>();
        Model.Profile p = user.byTheme.computeIfAbsent(db.activeTheme, k -> new Model.Profile());
        Model.Theme t = theme();
        if (t != null) {
            for (String fieldId : t.fields.keySet()) {
                p.rolls.putIfAbsent(fieldId, t.defaultRolls);
            }
        }
        return p;
    }

    /** Apaga o perfil de UM jogador no tema ativo. */
    static void deleteProfile(long userId) {
        Model.UserProfiles user = db.profiles.get(userId);
        if (user != null && user.byTheme != null) {
            user.byTheme.remove(db.activeTheme);
            if (user.byTheme.isEmpty()) db.profiles.remove(userId);
        }
        save();
    }

    /** Apaga TODOS os perfis do tema ativo (ex.: antes de trocar de universo de RP). */
    static void resetProfilesForActiveTheme() {
        resetProfilesForTheme(db.activeTheme);
    }

    /** Apaga todos os perfis de um tema específico, mesmo que não esteja ativo. */
    static void resetProfilesForTheme(String themeId) {
        for (Model.UserProfiles user : db.profiles.values()) {
            if (user.byTheme != null) user.byTheme.remove(themeId);
        }
        db.profiles.entrySet().removeIf(entry ->
                entry.getValue().byTheme == null || entry.getValue().byTheme.isEmpty());
        save();
    }

    /** Apaga literalmente TODOS os perfis de TODOS os temas de TODOS os jogadores. */
    static void resetAllProfilesEverywhere() {
        db.profiles.clear();
        save();
    }
}
