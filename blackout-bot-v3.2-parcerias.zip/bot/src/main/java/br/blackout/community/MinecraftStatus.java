package br.blackout.community;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Cliente mínimo do protocolo "Server List Ping" do Minecraft; não depende de nenhum serviço externo. */
final class MinecraftStatus {

    private MinecraftStatus() {}

    static String query(String host, int port) throws IOException {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), 4000);
            socket.setSoTimeout(4000);
            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            ByteArrayOutputStream handshakeBody = new ByteArrayOutputStream();
            DataOutputStream handshake = new DataOutputStream(handshakeBody);
            writeVarInt(handshake, 0);
            writeVarInt(handshake, 760);
            writeString(handshake, host);
            handshake.writeShort(port);
            handshake.writeByte(1);
            writePacket(out, handshakeBody.toByteArray());
            writePacket(out, new byte[]{0});

            readVarInt(in);
            if (readVarInt(in) != 0) throw new IOException("Resposta inválida do servidor");
            String json = readString(in);

            String online = extract(json, "\"online\"\\s*:\\s*(\\d+)");
            String max = extract(json, "\"max\"\\s*:\\s*(\\d+)");
            String version = extract(json, "\"name\"\\s*:\\s*\"([^\"]+)\"");

            return "🟢 **Servidor online**\n"
                    + "Jogadores: `" + online + "/" + max + "`\n"
                    + "Versão: `" + version + "`\n"
                    + "Endereço: `" + host + ":" + port + "`";
        }
    }

    private static String extract(String source, String regex) {
        Matcher matcher = Pattern.compile(regex).matcher(source);
        return matcher.find() ? matcher.group(1) : "?";
    }

    private static void writePacket(DataOutputStream out, byte[] payload) throws IOException {
        writeVarInt(out, payload.length);
        out.write(payload);
    }

    private static void writeString(DataOutputStream out, String value) throws IOException {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        writeVarInt(out, bytes.length);
        out.write(bytes);
    }

    private static String readString(DataInputStream in) throws IOException {
        int length = readVarInt(in);
        byte[] bytes = new byte[length];
        in.readFully(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private static void writeVarInt(DataOutputStream out, int value) throws IOException {
        while ((value & ~0x7F) != 0) {
            out.writeByte((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        out.writeByte(value);
    }

    private static int readVarInt(DataInputStream in) throws IOException {
        int result = 0;
        int shift = 0;
        int b;
        do {
            b = in.readUnsignedByte();
            result |= (b & 0x7F) << (7 * shift);
            if (++shift > 5) throw new IOException("VarInt muito grande");
        } while ((b & 0x80) != 0);
        return result;
    }
}
