package br.blackout.community;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.utils.cache.CacheFlag;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class Main {

    public static void main(String[] args) throws Exception {
        String token = System.getenv("DISCORD_TOKEN");
        if (token == null || token.isBlank()) {
            System.err.println("A variável de ambiente DISCORD_TOKEN não foi definida. O bot não pode iniciar sem ela.");
            return;
        }

        Store.load();

        JDA jda = JDABuilder.createDefault(token)
                .enableIntents(
                        GatewayIntent.GUILD_MEMBERS,
                        GatewayIntent.MESSAGE_CONTENT,
                        GatewayIntent.GUILD_MESSAGES,
                        GatewayIntent.GUILD_MESSAGE_REACTIONS)
                .enableCache(CacheFlag.EMOJI)
                .addEventListeners(new DiscordListener())
                .build();
        jda.awaitReady();

        CommandRegistry.register(jda);
        MinecraftBridge.start(jda);

        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(() -> {
            try {
                GiveawayManager.checkExpired(jda);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }, 30, 30, TimeUnit.SECONDS);

        scheduler.scheduleAtFixedRate(() -> {
            try {
                FunHandlers.checkDueReminders(jda);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }, 20, 20, TimeUnit.SECONDS);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            Store.save();
            scheduler.shutdownNow();
        }));

        System.out.println("Blackout Community Bot v3 online como " + jda.getSelfUser().getName());
        System.out.println("Lembre-se: no Discord Developer Portal, ative 'Server Members Intent' "
                + "e 'Message Content Intent' para todas as funções funcionarem.");
    }
}
