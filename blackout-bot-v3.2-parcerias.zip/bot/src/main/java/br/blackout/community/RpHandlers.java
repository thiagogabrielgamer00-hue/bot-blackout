package br.blackout.community;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;

import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Tudo relacionado a temas, atributos, roleta e perfis de RP. */
final class RpHandlers {

    private RpHandlers() {}

    static void roll(SlashCommandInteractionEvent e) {
        Model.Theme theme = Store.theme();
        if (theme == null) {
            Reply.of(e, "Nenhum tema ativo. Peça a um administrador para configurar um com /tema.", true);
            return;
        }
        String fieldId = e.getOption("atributo").getAsString().toLowerCase(Locale.ROOT);
        Model.Field field = theme.fields.get(fieldId);
        if (field == null) {
            Reply.of(e, "Atributo não encontrado. Use `/atributo listar` para ver os atributos disponíveis.", true);
            return;
        }
        if (field.options.isEmpty()) {
            Reply.of(e, "Este atributo ainda não possui opções configuradas.", true);
            return;
        }
        Model.Profile profile = Store.profile(e.getUser().getIdLong());
        int rollsLeft = profile.rolls.getOrDefault(fieldId, 0);
        if (rollsLeft < 1) {
            Reply.of(e, "Você não possui mais giros para **" + field.label + "**.", true);
            return;
        }
        String previousValue = profile.values.get(fieldId);
        String value = weightedRandom(field);
        profile.values.put(fieldId, value);
        profile.rolls.put(fieldId, rollsLeft - 1);
        Store.save();
        String roleNote = applyOptionRole(e, field, previousValue, value);
        Reply.of(e, "🎲 **" + field.label + " definido:** " + value + "\nGiros restantes: `" + (rollsLeft - 1) + "`" + roleNote, false);
        if (fieldId.equals(Store.db.rankSync.themeFieldId)) {
            RankSyncHandlers.trySync(e.getUser().getIdLong());
        }
    }

    /**
     * Se o atributo tiver um cargo do Discord mapeado para o valor sorteado (configurado com
     * /atributo opcao-cargo), concede esse cargo ao membro agora e remove o cargo referente ao
     * valor anterior do mesmo atributo (se houver), para não acumular cargos ao rerolar.
     * Retorna um texto curto para anexar à resposta, informando o que aconteceu com o cargo.
     */
    private static String applyOptionRole(SlashCommandInteractionEvent e, Model.Field field, String previousValue, String newValue) {
        if (e.getGuild() == null || field.optionRoles == null || field.optionRoles.isEmpty()) return "";
        Member member = e.getMember();
        if (member == null) return "";
        Long oldRoleId = previousValue == null ? null : field.roleFor(previousValue);
        Long newRoleId = field.roleFor(newValue);
        if (oldRoleId != null && !oldRoleId.equals(newRoleId)) {
            Role oldRole = e.getGuild().getRoleById(oldRoleId);
            if (oldRole != null && member.getRoles().contains(oldRole)) {
                e.getGuild().removeRoleFromMember(member, oldRole).queue(v -> {}, error -> {});
            }
        }
        if (newRoleId == null) return "";
        Role newRole = e.getGuild().getRoleById(newRoleId);
        if (newRole == null) return "\n⚠️ Cargo configurado para esse valor não existe mais no servidor.";
        if (!member.getRoles().contains(newRole)) {
            e.getGuild().addRoleToMember(member, newRole).queue(v -> {}, error -> {});
        }
        return "\n🏷️ Cargo " + newRole.getAsMention() + " atribuído.";
    }

    /** Sorteia uma opção do campo respeitando a raridade (peso) configurada de cada uma. */
    private static String weightedRandom(Model.Field field) {
        int totalWeight = 0;
        for (String option : field.options) totalWeight += Math.max(1, field.weightOf(option));
        int roll = new Random().nextInt(totalWeight);
        int cumulative = 0;
        for (String option : field.options) {
            cumulative += Math.max(1, field.weightOf(option));
            if (roll < cumulative) return option;
        }
        return field.options.get(field.options.size() - 1);
    }

    static void profile(SlashCommandInteractionEvent e) {
        Model.Theme theme = Store.theme();
        if (theme == null) {
            Reply.of(e, "Nenhum tema ativo no momento.", true);
            return;
        }
        User user = e.getOption("usuario") == null ? e.getUser() : e.getOption("usuario").getAsUser();
        Model.Profile profile = Store.profile(user.getIdLong());
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("Perfil de " + user.getName() + " • " + theme.displayName)
                .setThumbnail(user.getEffectiveAvatarUrl())
                .setColor(Reply.BRAND_COLOR);
        for (Model.Field field : theme.fields.values()) {
            String value = profile.values.getOrDefault(field.id, "Não definido");
            int rolls = profile.rolls.getOrDefault(field.id, 0);
            embed.addField(field.label, value + "\nGiros: `" + rolls + "`", true);
        }
        Reply.embed(e, embed, false);
    }

    static void theme(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_RP)) return;
        String sub = e.getSubcommandName();
        if ("listar".equals(sub)) {
            Reply.of(e, "**Temas cadastrados:** " + String.join(", ", Store.db.themes.keySet())
                    + "\nTema ativo: **" + Store.db.activeTheme + "**", true);
            return;
        }
        if ("copiar".equals(sub)) {
            String origem = normalize(e.getOption("origem").getAsString());
            String novoId = normalize(e.getOption("novo-id").getAsString());
            Model.Theme source = Store.db.themes.get(origem);
            if (source == null) {
                Reply.of(e, "Tema de origem não existe.", true);
                return;
            }
            if (Store.db.themes.containsKey(novoId)) {
                Reply.of(e, "Já existe um tema com esse novo ID.", true);
                return;
            }
            Model.Theme copy = new Model.Theme(novoId, e.getOption("novo-nome").getAsString());
            copy.defaultRolls = source.defaultRolls;
            for (Model.Field field : source.fields.values()) {
                Model.Field newField = new Model.Field(field.id, field.label, field.options);
                newField.maxValueLength = field.maxValueLength;
                copy.fields.put(field.id, newField);
            }
            Store.db.themes.put(novoId, copy);
            Store.save();
            Reply.of(e, "Tema **" + copy.displayName + "** criado com os mesmos campos de **" + source.displayName
                    + "**. Ninguém tem perfil nele ainda — os jogadores começam do zero.", true);
            return;
        }
        String id = normalize(e.getOption("id").getAsString());
        switch (sub) {
            case "criar" -> {
                if (Store.db.themes.containsKey(id)) {
                    Reply.of(e, "Esse tema já existe.", true);
                    return;
                }
                Store.db.themes.put(id, new Model.Theme(id, e.getOption("nome").getAsString()));
                Store.save();
                Reply.of(e, "Tema criado. Adicione atributos com `/atributo adicionar`.", true);
            }
            case "usar" -> {
                if (!Store.db.themes.containsKey(id)) {
                    Reply.of(e, "Tema inexistente. Use `/tema listar`.", true);
                    return;
                }
                Store.db.activeTheme = id;
                Store.save();
                Reply.of(e, "Tema ativo agora: **" + Store.theme().displayName
                        + "**. Cada jogador mantém um perfil separado por tema — voltar a um tema antigo restaura o perfil antigo dele.", false);
            }
            case "remover" -> {
                if (id.equals(Store.db.activeTheme)) {
                    Reply.of(e, "Ative outro tema antes de remover este.", true);
                    return;
                }
                Store.db.themes.remove(id);
                Store.save();
                Reply.of(e, "Tema removido. Os perfis salvos desse tema continuam guardados; use "
                        + "`/perfil-admin limpar-tema` se quiser apagá-los também.", true);
            }
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }

    static void field(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_RP)) return;
        Model.Theme theme = Store.theme();
        if (theme == null) {
            Reply.of(e, "Nenhum tema ativo.", true);
            return;
        }
        String sub = e.getSubcommandName();
        if ("listar".equals(sub)) {
            StringBuilder text = new StringBuilder("**Atributos de ").append(theme.displayName).append("**\n");
            if (theme.fields.isEmpty()) text.append("Nenhum atributo cadastrado ainda.");
            for (Model.Field field : theme.fields.values()) {
                text.append("• `").append(field.id).append("` — ").append(field.label)
                        .append(" (limite ").append(field.maxValueLength).append(" caracteres)\n")
                        .append("  Opções: ").append(field.options.isEmpty() ? "nenhuma" : describeOptions(field))
                        .append("\n");
                if (field.optionRoles != null && !field.optionRoles.isEmpty()) {
                    text.append("  Cargos: ");
                    field.optionRoles.forEach((val, roleId) -> text.append(val).append(" → <@&").append(roleId).append("> "));
                    text.append("\n");
                }
            }
            Reply.of(e, text.toString(), true);
            return;
        }
        String id = normalize(e.getOption("atributo") != null ? e.getOption("atributo").getAsString() : e.getOption("id").getAsString());
        if ("adicionar".equals(sub)) {
            if (theme.fields.containsKey(id)) {
                Reply.of(e, "Esse atributo já existe.", true);
                return;
            }
            theme.fields.put(id, new Model.Field(id, e.getOption("nome").getAsString(), List.of()));
            Store.save();
            Reply.of(e, "Atributo `" + id + "` criado. Adicione opções com `/atributo opcao-adicionar`.", true);
            return;
        }
        Model.Field field = theme.fields.get(id);
        if (field == null) {
            Reply.of(e, "Atributo inexistente. Use `/atributo listar`.", true);
            return;
        }
        switch (sub) {
            case "remover" -> theme.fields.remove(id);
            case "limite" -> {
                int max = e.getOption("maximo").getAsInt();
                if (max < 1 || max > 100) {
                    Reply.of(e, "O limite deve ser de 1 a 100 caracteres.", true);
                    return;
                }
                field.maxValueLength = max;
            }
            case "opcao-adicionar" -> {
                String value = e.getOption("valor").getAsString().trim();
                if (value.length() > field.maxValueLength) {
                    Reply.of(e, "Esse valor passa do limite de " + field.maxValueLength + " caracteres.", true);
                    return;
                }
                if (!field.options.contains(value)) field.options.add(value);
            }
            case "opcao-remover" -> {
                String value = e.getOption("valor").getAsString().trim();
                field.options.removeIf(existing -> existing.equalsIgnoreCase(value));
                field.weights.remove(value);
            }
            case "opcao-raridade" -> {
                String value = e.getOption("valor").getAsString().trim();
                if (!field.options.contains(value)) {
                    Reply.of(e, "Essa opção não existe nesse atributo. Use `/atributo listar`.", true);
                    return;
                }
                int peso = e.getOption("peso").getAsInt();
                if (peso < 1 || peso > 1000) {
                    Reply.of(e, "O peso deve ser de 1 a 1000. Padrão é " + Model.Field.DEFAULT_WEIGHT
                            + " — valores menores tornam a opção mais rara, maiores tornam mais comum.", true);
                    return;
                }
                field.weights.put(value, peso);
            }
            case "opcao-cargo" -> {
                String value = e.getOption("valor").getAsString().trim();
                if (!field.options.contains(value)) {
                    Reply.of(e, "Essa opção não existe nesse atributo. Use `/atributo listar`.", true);
                    return;
                }
                long roleId = e.getOption("cargo").getAsRole().getIdLong();
                field.optionRoles.put(value, roleId);
                Store.save();
                Reply.of(e, "Cargo <@&" + roleId + "> será atribuído automaticamente a quem tiver **" + field.label
                        + "** = **" + value + "**. Já vale para o próximo /roletar de cada jogador.", true);
                return;
            }
            case "opcao-cargo-remover" -> {
                String value = e.getOption("valor").getAsString().trim();
                field.optionRoles.remove(value);
            }
            default -> {
                Reply.of(e, "Subcomando desconhecido.", true);
                return;
            }
        }
        Store.save();
        Reply.of(e, "Configuração salva.", true);
    }

    private static String describeOptions(Model.Field field) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < field.options.size(); i++) {
            String option = field.options.get(i);
            if (i > 0) out.append(", ");
            out.append(option).append(" (peso ").append(field.weightOf(option)).append(")");
        }
        return out.toString();
    }

    static void rolls(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_RP)) return;
        Model.Theme theme = Store.theme();
        if (theme == null) {
            Reply.of(e, "Nenhum tema ativo.", true);
            return;
        }
        Model.Profile profile = Store.profile(e.getOption("usuario").getAsUser().getIdLong());
        String fieldId = e.getOption("atributo").getAsString().toLowerCase(Locale.ROOT);
        int amount = e.getOption("quantidade").getAsInt();
        if (amount < 0 || amount > 1000) {
            Reply.of(e, "Quantidade inválida. Use de 0 a 1000.", true);
            return;
        }
        if ("todos".equals(fieldId)) {
            for (String id : theme.fields.keySet()) profile.rolls.put(id, amount);
        } else if (theme.fields.containsKey(fieldId)) {
            profile.rolls.put(fieldId, amount);
        } else {
            Reply.of(e, "Atributo inexistente.", true);
            return;
        }
        Store.save();
        Reply.of(e, "Giros atualizados.", true);
    }

    static void profileAdmin(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_RP)) return;
        String sub = e.getSubcommandName();
        switch (sub) {
            case "apagar" -> {
                long userId = e.getOption("usuario").getAsUser().getIdLong();
                RankSyncHandlers.revokeBeforeWipe(userId, Store.db.activeTheme);
                revokeAllOptionRoles(e, userId);
                Store.deleteProfile(userId);
                Reply.of(e, "Perfil desse jogador apagado no tema atual. O vínculo da conta com o Minecraft "
                        + "continua igual — só os cargos referentes aos atributos dele (se houver) foram revogados.", true);
            }
            case "limpar-todos" -> {
                RankSyncHandlers.revokeForTheme(Store.db.activeTheme);
                Store.resetProfilesForActiveTheme();
                Reply.of(e, "Todos os perfis do tema **" + Store.db.activeTheme + "** foram apagados. Outros temas foram preservados.\n"
                        + "Vínculos de conta com o Minecraft continuam salvos — só os cargos automáticos referentes ao atributo "
                        + "configurado foram revogados de quem estava vinculado.", true);
            }
            case "limpar-tema" -> {
                String id = normalize(e.getOption("id").getAsString());
                if (!Store.db.themes.containsKey(id)) {
                    Reply.of(e, "Esse tema não existe.", true);
                    return;
                }
                RankSyncHandlers.revokeForTheme(id);
                Store.resetProfilesForTheme(id);
                Reply.of(e, "Todos os perfis do tema `" + id + "` foram apagados. Vínculos de conta continuam salvos; "
                        + "os cargos automáticos referentes a esse tema foram revogados de quem estava vinculado.", true);
            }
            case "limpar-tudo" -> {
                RankSyncHandlers.revokeForAllThemes();
                Store.resetAllProfilesEverywhere();
                Reply.of(e, "⚠️ TODOS os perfis de TODOS os temas foram apagados permanentemente.\n"
                        + "Vínculos de conta com o Minecraft continuam salvos; os cargos automáticos de quem estava "
                        + "vinculado foram revogados.", true);
            }
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }

    /** Remove, do membro informado, todos os cargos concedidos via /atributo opcao-cargo no tema ativo. */
    private static void revokeAllOptionRoles(SlashCommandInteractionEvent e, long userId) {
        Model.Theme t = Store.theme();
        if (t == null || e.getGuild() == null) return;
        Model.Profile profile = Store.profile(userId);
        Member member = e.getGuild().getMemberById(userId);
        if (member == null) return;
        for (Model.Field field : t.fields.values()) {
            String value = profile.values.get(field.id);
            Long roleId = value == null ? null : field.roleFor(value);
            if (roleId == null) continue;
            Role role = e.getGuild().getRoleById(roleId);
            if (role != null && member.getRoles().contains(role)) {
                e.getGuild().removeRoleFromMember(member, role).queue(v -> {}, error -> {});
            }
        }
    }

    private static String normalize(String raw) {
        return raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "");
    }
}
