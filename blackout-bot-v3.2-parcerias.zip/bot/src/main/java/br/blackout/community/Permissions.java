package br.blackout.community;

import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;

/**
 * Controla quem pode usar o quê.
 *
 * O dono permanente (Store.db.ownerId) sempre pode tudo e NUNCA perde acesso,
 * mesmo que ele mesmo tente se remover de um cargo autorizado.
 *
 * Além do dono, existem 5 grupos de permissão configuráveis com /permissao:
 *   - "rp"            -> /tema, /atributo (incl. opcao-cargo), /giros, /perfil-admin, /vinculo (de outra pessoa)
 *   - "moderacao"      -> /warn, /mute, /ban, /kick, /limpar, /slowmode, /lock, /unlock, /apelido, /limpar-usuario
 *   - "configuracao"   -> /config, /automod, /nivel-cargo, /nivel-admin, /verificacao, /minecraft bridge-canal,
 *                          /cargo-automatico, /sugestao canal|alternar
 *   - "diversao"       -> /sorteio, /comando-custom, /cargo-reacao, /embed, /avisar
 *   - "parcerias"      -> /parceria (divulgar, remover, listar, painel, estatisticas), botões Aprovar/Recusar
 *                          dos pedidos de parceria. Quem está neste grupo também pode postar links/convites
 *                          no chat sem o automod apagar (parceiros costumam ter convite).
 * Comandos soltos de utilidade/diversão (/ping, /stats, /8bola, /moeda, /dado, /afk, /convite, /lembrete,
 * /sugestao enviar) são públicos e não passam por nenhum grupo.
 *
 * Um cargo pode estar em vários grupos ao mesmo tempo.
 */
final class Permissions {

    static final String GROUP_RP = "rp";
    static final String GROUP_MODERACAO = "moderacao";
    static final String GROUP_CONFIGURACAO = "configuracao";
    static final String GROUP_DIVERSAO = "diversao";
    static final String GROUP_PARCERIAS = "parcerias";

    private Permissions() {}

    static boolean isOwner(long userId) {
        return userId == Store.db.ownerId;
    }

    static boolean canUse(SlashCommandInteractionEvent e, String group) {
        return canUse(e.getUser().getIdLong(), e.getMember(), group);
    }

    /** Versão genérica (serve para botões, modais e automod): dono sempre pode; senão, precisa de um cargo do grupo. */
    static boolean canUse(long userId, Member member, String group) {
        if (isOwner(userId)) return true;
        if (member == null) return false;
        var allowedRoles = Store.db.permissionGroups.get(group);
        if (allowedRoles == null || allowedRoles.isEmpty()) return false;
        return member.getRoles().stream().anyMatch(role -> allowedRoles.contains(role.getIdLong()));
    }

    /** Responde com erro e retorna false se o usuário não tiver permissão do grupo informado. */
    static boolean require(SlashCommandInteractionEvent e, String group) {
        if (canUse(e, group)) return true;
        Reply.of(e, "🚫 Você não tem permissão para usar comandos do grupo **" + group + "**.", true);
        return false;
    }
}
