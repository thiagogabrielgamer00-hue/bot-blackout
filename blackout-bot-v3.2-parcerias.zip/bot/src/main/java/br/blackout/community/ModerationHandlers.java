package br.blackout.community;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

final class ModerationHandlers {

    private ModerationHandlers() {}

    static void warn(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO)) return;
        User user = e.getOption("usuario").getAsUser();
        String reason = e.getOption("motivo").getAsString();
        List<Model.Warning> list = Store.db.warnings.computeIfAbsent(user.getIdLong(), k -> new ArrayList<>());
        list.add(new Model.Warning(reason, e.getUser().getIdLong(), Instant.now().toEpochMilli()));
        Store.save();
        Reply.of(e, "⚠️ Advertência `" + list.size() + "` aplicada a " + user.getAsMention() + ". Motivo: " + reason, false);
        BotLog.write(e.getGuild(), "⚠️ " + user.getAsTag() + " advertido por " + e.getUser().getAsTag() + ": " + reason);
    }

    static void warnings(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO)) return;
        User user = e.getOption("usuario").getAsUser();
        String sub = e.getSubcommandName();
        if ("limpar".equals(sub)) {
            Store.db.warnings.remove(user.getIdLong());
            Store.save();
            Reply.of(e, "Advertências de " + user.getAsMention() + " removidas.", true);
            return;
        }
        List<Model.Warning> list = Store.db.warnings.getOrDefault(user.getIdLong(), List.of());
        if (list.isEmpty()) {
            Reply.of(e, user.getAsMention() + " não possui advertências.", true);
            return;
        }
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("Advertências de " + user.getName())
                .setColor(Reply.BRAND_COLOR);
        int index = 1;
        for (Model.Warning w : list) {
            embed.addField("#" + index + " — por <@" + w.moderatorId + ">", w.reason, false);
            index++;
        }
        Reply.embed(e, embed, true);
    }

    static void mute(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO) || e.getGuild() == null) return;
        int minutes = e.getOption("minutos").getAsInt();
        if (minutes < 1 || minutes > 40320) {
            Reply.of(e, "Duração inválida. Use de 1 a 40320 minutos (28 dias).", true);
            return;
        }
        Member member = e.getOption("usuario").getAsMember();
        if (member == null) {
            Reply.of(e, "Membro não encontrado neste servidor.", true);
            return;
        }
        String reason = e.getOption("motivo") == null ? "Comando /mute" : e.getOption("motivo").getAsString();
        e.getGuild().timeoutFor(member, Duration.ofMinutes(minutes)).reason(reason).queue(
                v -> {
                    Reply.of(e, "🔇 " + member.getAsMention() + " silenciado por " + minutes + " minutos.", true);
                    BotLog.write(e.getGuild(), "🔇 " + member.getUser().getAsTag() + " silenciado por " + e.getUser().getAsTag() + " (" + minutes + " min): " + reason);
                },
                error -> Reply.of(e, "Não foi possível silenciar: " + error.getMessage(), true));
    }

    static void unmute(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO) || e.getGuild() == null) return;
        Member member = e.getOption("usuario").getAsMember();
        if (member == null) {
            Reply.of(e, "Membro não encontrado neste servidor.", true);
            return;
        }
        e.getGuild().removeTimeout(member).queue(
                v -> Reply.of(e, "🔊 Silenciamento removido de " + member.getAsMention() + ".", true),
                error -> Reply.of(e, "Não foi possível remover o silenciamento: " + error.getMessage(), true));
    }

    static void kick(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO) || e.getGuild() == null) return;
        Member member = e.getOption("usuario").getAsMember();
        if (member == null) {
            Reply.of(e, "Membro não encontrado neste servidor.", true);
            return;
        }
        String reason = e.getOption("motivo") == null ? "Comando /kick" : e.getOption("motivo").getAsString();
        String tag = member.getUser().getAsTag();
        e.getGuild().kick(member).reason(reason).queue(
                v -> {
                    Reply.of(e, "👢 Membro expulso.", true);
                    BotLog.write(e.getGuild(), "👢 " + tag + " expulso por " + e.getUser().getAsTag() + ": " + reason);
                },
                error -> Reply.of(e, "Não foi possível expulsar: " + error.getMessage(), true));
    }

    static void ban(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO) || e.getGuild() == null) return;
        User user = e.getOption("usuario").getAsUser();
        String reason = e.getOption("motivo") == null ? "Comando /ban" : e.getOption("motivo").getAsString();
        e.getGuild().ban(user, 0, TimeUnit.SECONDS).reason(reason).queue(
                v -> {
                    Reply.of(e, "🔨 Membro banido.", true);
                    BotLog.write(e.getGuild(), "🔨 " + user.getAsTag() + " banido por " + e.getUser().getAsTag() + ": " + reason);
                },
                error -> Reply.of(e, "Não foi possível banir: " + error.getMessage(), true));
    }

    static void clear(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO)) return;
        int amount = e.getOption("quantidade").getAsInt();
        if (amount < 1 || amount > 100) {
            Reply.of(e, "Use uma quantidade de 1 a 100.", true);
            return;
        }
        e.deferReply(true).queue();
        e.getChannel().getHistory().retrievePast(amount).queue(messages -> {
            e.getChannel().purgeMessages(messages);
            e.getHook().sendMessage("🧹 " + messages.size() + " mensagens removidas.").setEphemeral(true).queue();
        });
    }
}
