package br.blackout.community;

import java.awt.Color;
import java.net.URI;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pequenas utilidades para links, convites e cores usadas por /avisar, /embed e /parceria. */
final class Links {

    private static final Pattern INVITE = Pattern.compile(
            "(?:discord\\.gg|discord(?:app)?\\.com/invite)/([A-Za-z0-9-]{2,64})", Pattern.CASE_INSENSITIVE);

    private Links() {}

    /** Aceita "meusite.com" e vira "https://meusite.com". Retorna null se vazio. */
    static String normalize(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty()) return null;
        if (!s.regionMatches(true, 0, "http://", 0, 7) && !s.regionMatches(true, 0, "https://", 0, 8)) {
            s = "https://" + s;
        }
        return s;
    }

    /** true se for uma URL http(s) válida e pequena o bastante para caber num botão do Discord (512). */
    static boolean isHttpUrl(String s) {
        if (s == null || s.length() > 512 || s.contains(" ")) return false;
        try {
            URI uri = new URI(s);
            String scheme = uri.getScheme();
            return scheme != null
                    && (scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))
                    && uri.getHost() != null && uri.getHost().contains(".");
        } catch (Exception ex) {
            return false;
        }
    }

    /** Extrai o código de um convite (discord.gg/abc, discord.com/invite/abc, com ou sem https). */
    static String extractInviteCode(String raw) {
        if (raw == null) return null;
        Matcher m = INVITE.matcher(raw.trim());
        return m.find() ? m.group(1) : null;
    }

    /** "#ff8800", "ff8800" ou "0xff8800" -> Color. Retorna o fallback se for inválido. */
    static Color parseColor(String hex, Color fallback) {
        if (hex == null) return fallback;
        String h = hex.trim().replace("#", "").replace("0x", "");
        if (h.length() != 6) return fallback;
        try {
            return new Color(Integer.parseInt(h, 16));
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    static String clamp(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }
}
