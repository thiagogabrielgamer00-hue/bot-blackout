package br.blackout.community;

import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;

final class ConfigHandlers {

    private ConfigHandlers() {}

    // ---------------- /config ----------------

    static void config(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        String sub = e.getSubcommandName();
        switch (sub) {
            case "ver" -> {
                String text = "**Boas-vindas:** " + describe(Store.db.welcomeEnabled, Store.db.welcomeChannelId) + "\n"
                        + "**Despedida:** " + describe(Store.db.leaveEnabled, Store.db.leaveChannelId) + "\n"
                        + "**Logs:** " + (Store.db.logChannelId == 0 ? "desativado" : "<#" + Store.db.logChannelId + ">");
                Reply.of(e, text, true);
            }
            case "boas-vindas" -> {
                Store.db.welcomeChannelId = e.getOption("canal").getAsChannel().getIdLong();
                Store.db.welcomeMessage = e.getOption("mensagem").getAsString();
                Store.save();
                Reply.of(e, "Mensagem de boas-vindas configurada.", true);
            }
            case "boas-vindas-alternar" -> {
                Store.db.welcomeEnabled = e.getOption("ativo").getAsBoolean();
                Store.save();
                Reply.of(e, "Boas-vindas " + (Store.db.welcomeEnabled ? "ativadas" : "desativadas") + ".", true);
            }
            case "despedida" -> {
                Store.db.leaveChannelId = e.getOption("canal").getAsChannel().getIdLong();
                Store.db.leaveMessage = e.getOption("mensagem").getAsString();
                Store.save();
                Reply.of(e, "Mensagem de despedida configurada.", true);
            }
            case "despedida-alternar" -> {
                Store.db.leaveEnabled = e.getOption("ativo").getAsBoolean();
                Store.save();
                Reply.of(e, "Despedida " + (Store.db.leaveEnabled ? "ativada" : "desativada") + ".", true);
            }
            case "logs" -> {
                Store.db.logChannelId = e.getOption("canal").getAsChannel().getIdLong();
                Store.save();
                Reply.of(e, "Canal de logs configurado.", true);
            }
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }

    private static String describe(boolean enabled, long channelId) {
        if (!enabled) return "desativado";
        if (channelId == 0) return "ativado, mas sem canal configurado";
        return "ativado em <#" + channelId + ">";
    }

    // ---------------- /automod ----------------

    static void automod(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        Model.AutoModConfig cfg = Store.db.automod;
        String sub = e.getSubcommandName();
        switch (sub) {
            case "ativar" -> cfg.enabled = e.getOption("ativo").getAsBoolean();
            case "anti-link" -> cfg.blockLinks = e.getOption("ativo").getAsBoolean();
            case "anti-convite" -> cfg.blockInvites = e.getOption("ativo").getAsBoolean();
            case "anti-caps" -> cfg.blockExcessiveCaps = e.getOption("ativo").getAsBoolean();
            case "anti-spam" -> cfg.blockSpam = e.getOption("ativo").getAsBoolean();
            case "palavra-adicionar" -> cfg.bannedWords.add(e.getOption("palavra").getAsString().toLowerCase());
            case "palavra-remover" -> cfg.bannedWords.remove(e.getOption("palavra").getAsString().toLowerCase());
            case "cargo-isento" -> cfg.exemptRoleIds.add(e.getOption("cargo").getAsRole().getIdLong());
            case "ver" -> {
                String text = "**Automod:** " + (cfg.enabled ? "ativado" : "desativado")
                        + "\nAnti-link: " + cfg.blockLinks
                        + "\nAnti-convite: " + cfg.blockInvites
                        + "\nAnti-caps: " + cfg.blockExcessiveCaps
                        + "\nAnti-spam: " + cfg.blockSpam
                        + "\nPalavras bloqueadas: " + cfg.bannedWords.size()
                        + "\nCargos isentos: " + cfg.exemptRoleIds.size();
                Reply.of(e, text, true);
                return;
            }
            default -> {
                Reply.of(e, "Subcomando desconhecido.", true);
                return;
            }
        }
        Store.save();
        Reply.of(e, "Configuração do automod atualizada.", true);
    }

    // ---------------- /nivel-cargo ----------------

    static void levelRole(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        String sub = e.getSubcommandName();
        switch (sub) {
            case "definir" -> {
                int level = e.getOption("nivel").getAsInt();
                long roleId = e.getOption("cargo").getAsRole().getIdLong();
                Store.db.levelRoleRewards.put(level, roleId);
                Store.save();
                Reply.of(e, "A partir do nível " + level + ", os membros recebem <@&" + roleId + ">.", true);
            }
            case "remover" -> {
                int level = e.getOption("nivel").getAsInt();
                Store.db.levelRoleRewards.remove(level);
                Store.save();
                Reply.of(e, "Recompensa do nível " + level + " removida.", true);
            }
            case "listar" -> {
                if (Store.db.levelRoleRewards.isEmpty()) {
                    Reply.of(e, "Nenhuma recompensa de nível configurada.", true);
                    return;
                }
                StringBuilder text = new StringBuilder("**Recompensas de nível:**\n");
                Store.db.levelRoleRewards.forEach((level, roleId) -> text.append("Nível ").append(level).append(" → <@&").append(roleId).append(">\n"));
                Reply.of(e, text.toString(), true);
            }
            case "alternar" -> {
                Store.db.levelingEnabled = e.getOption("ativo").getAsBoolean();
                Store.save();
                Reply.of(e, "Sistema de níveis " + (Store.db.levelingEnabled ? "ativado" : "desativado") + ".", true);
            }
            default -> Reply.of(e, "Subcomando desconhecido.", true);
        }
    }

    // ---------------- /verificacao ----------------

    static void verification(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_CONFIGURACAO)) return;
        if ("desativar".equals(e.getSubcommandName())) {
            Store.db.verificationEnabled = false;
            Store.save();
            Reply.of(e, "Verificação desativada.", true);
            return;
        }
        long channelId = e.getOption("canal").getAsChannel().getIdLong();
        long roleId = e.getOption("cargo").getAsRole().getIdLong();
        Store.db.verificationEnabled = true;
        Store.db.verificationChannelId = channelId;
        Store.db.verificationRoleId = roleId;
        Store.save();
        var channel = e.getJDA().getTextChannelById(channelId);
        if (channel != null) {
            channel.sendMessage("✅ Clique no botão abaixo para verificar sua conta e liberar o acesso ao servidor.")
                    .setActionRow(net.dv8tion.jda.api.interactions.components.buttons.Button.success("verify", "Verificar"))
                    .queue();
        }
        Reply.of(e, "Verificação configurada em <#" + channelId + ">.", true);
    }
}
