package br.blackout.community;

import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;

/** Comandos administrativos extras: slowmode, trancar/destrancar canal, apelido e limpar por usuário. */
final class AdminExtraHandlers {

    private AdminExtraHandlers() {}

    static void slowmode(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO) || e.getGuild() == null) return;
        if (!(e.getChannel() instanceof TextChannel channel)) {
            Reply.of(e, "Use este comando em um canal de texto.", true);
            return;
        }
        int seconds = e.getOption("segundos").getAsInt();
        if (seconds < 0 || seconds > 21600) {
            Reply.of(e, "Use de 0 (desligado) a 21600 segundos (6 horas).", true);
            return;
        }
        channel.getManager().setSlowmode(seconds).queue(
                v -> Reply.of(e, seconds == 0 ? "🐇 Modo lento desligado neste canal." : "🐢 Modo lento definido para " + seconds + "s neste canal.", true),
                error -> Reply.of(e, "Falha: " + error.getMessage(), true));
    }

    static void lock(SlashCommandInteractionEvent e, boolean locking) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO) || e.getGuild() == null) return;
        if (!(e.getChannel() instanceof TextChannel channel)) {
            Reply.of(e, "Use este comando em um canal de texto.", true);
            return;
        }
        var everyone = e.getGuild().getPublicRole();
        var upsert = channel.upsertPermissionOverride(everyone);
        if (locking) {
            upsert = upsert.deny(Permission.MESSAGE_SEND);
        } else {
            upsert = upsert.clear(Permission.MESSAGE_SEND);
        }
        upsert.queue(
                v -> Reply.of(e, locking ? "🔒 Canal trancado: ninguém sem cargo de exceção pode enviar mensagens." : "🔓 Canal destrancado.", false),
                error -> Reply.of(e, "Falha: " + error.getMessage(), true));
    }

    static void nick(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO) || e.getGuild() == null) return;
        Member member = e.getOption("usuario").getAsMember();
        if (member == null) {
            Reply.of(e, "Membro não encontrado neste servidor.", true);
            return;
        }
        String novo = e.getOption("apelido") == null ? null : e.getOption("apelido").getAsString();
        member.modifyNickname(novo).queue(
                v -> Reply.of(e, "✏️ Apelido de " + member.getAsMention() + " atualizado.", true),
                error -> Reply.of(e, "Não consegui alterar o apelido: " + error.getMessage(), true));
    }

    static void clearFromUser(SlashCommandInteractionEvent e) {
        if (!Permissions.require(e, Permissions.GROUP_MODERACAO)) return;
        var user = e.getOption("usuario").getAsUser();
        int amount = e.getOption("quantidade").getAsInt();
        if (amount < 1 || amount > 200) {
            Reply.of(e, "Use uma quantidade de 1 a 200 (mensagens verificadas, não necessariamente todas apagadas).", true);
            return;
        }
        e.deferReply(true).queue();
        e.getChannel().getHistory().retrievePast(Math.min(amount, 100)).queue(messages -> {
            var toDelete = messages.stream().filter(m -> m.getAuthor().getIdLong() == user.getIdLong()).toList();
            if (toDelete.isEmpty()) {
                e.getHook().sendMessage("Nenhuma mensagem recente desse usuário encontrada nas últimas " + messages.size() + " mensagens.").setEphemeral(true).queue();
                return;
            }
            e.getChannel().purgeMessages(toDelete);
            e.getHook().sendMessage("🧹 " + toDelete.size() + " mensagens de " + user.getAsMention() + " removidas.").setEphemeral(true).queue();
        });
    }
}
