# Blackout Community — Bot 3.0 + Plugin de Minecraft

Projeto com duas partes:

- **`bot/`** — o bot do Discord (Java + JDA), agora com sistema de RP multi-tema,
  permissões granulares por cargo, moderação, automod, níveis/XP, comandos
  customizados, cargos por reação, sorteios, verificação, tickets e uma ponte
  HTTP para o Minecraft.
- **`minecraft-plugin/`** — um único plugin `.jar` pensado para funcionar do
  **1.7.10 ao 1.21.1** sem precisar recompilar para cada versão, que espelha
  entradas/saídas/chat do servidor com um canal do Discord.

## Antes de tudo: o que eu (a IA) NÃO consegui testar

Não tenho acesso à internet nem a um compilador Java neste ambiente — então não
consegui rodar `mvn package` nem `javac` para confirmar que tudo compila 100%
sem erro. Revisei o código com cuidado (sintaxe, imports, balanceamento de
chaves), mas o primeiro build real vai acontecer no GitHub Actions (workflow
já incluído em `.github/workflows/build.yml`) ou na sua máquina. Se algo não
compilar, **me mande o erro exato** que eu corrijo rapidamente — é bem mais
fácil consertar um erro de compilação apontado do que adivinhar tudo às cegas.

## O que ficou de fora, e por quê

- **IA própria dentro do bot**: você mesmo disse que dava pra descartar. Uma IA de
  verdade precisa de um provedor de modelo, custo por uso e moderação de
  conteúdo — não é algo pra improvisar direto no bot sem token/orçamento
  próprios. O código ficou organizado para, no futuro, plugar um serviço de IA
  por uma variável de ambiente separada, se você quiser.
- **"Todas as funções de todos os bots que existem"**: impossível de fazer
  literalmente (nem eu tenho a lista fechada de features de bots fechados). Em
  vez disso, implementei um conjunto profissional real, inspirado no que
  Loritta/Carl-bot mais oferecem: níveis, automod, cargos por reação,
  sorteios, comandos customizados, verificação, logs, tickets e permissões
  granulares — tudo isso somado ao seu sistema de RP.

## Como rodar o bot no WispByte (gratuito)

1. Crie um servidor Java 17 no WispByte.
2. Gere o `.jar` (veja seção de compilação abaixo) e envie
   `blackout-community-bot.jar` para o servidor.
3. Crie a variável de ambiente `DISCORD_TOKEN` com o token do bot. **Nunca**
   coloque o token dentro de um arquivo ou do GitHub.
4. Comando de início: `java -jar blackout-community-bot.jar`
5. No [Discord Developer Portal](https://discord.com/developers/applications),
   na aba **Bot**, ative:
   - **Server Members Intent**
   - **Message Content Intent** (necessário para automod, níveis e comandos
     customizados lerem o texto das mensagens)
6. Os dados ficam em `data/blackout-community.json`, criado automaticamente.
   É um arquivo de texto simples — dá pra abrir e inspecionar/editar em caso
   de emergência. Faça backup dele antes de qualquer limpeza em massa.

## Como compilar (você não precisa ter Maven instalado)

O jeito mais simples é deixar o GitHub fazer isso:

1. Crie um repositório no GitHub e suba esta pasta inteira (`bot/`,
   `minecraft-plugin/`, `.github/`, etc).
2. O workflow em `.github/workflows/build.yml` roda automaticamente a cada
   push e gera dois arquivos prontos em **Actions → (seu último run) →
   Artifacts**: `blackout-community-bot` e `blackout-mc-bridge`.
3. Baixe o `.jar` de dentro do artifact e suba pro WispByte (bot) ou pra pasta
   `plugins/` do seu servidor de Minecraft (plugin).

Se preferir compilar localmente, com Maven instalado:
```
cd bot && mvn package            # gera bot/target/blackout-community-bot.jar
cd ../minecraft-plugin && mvn package  # gera minecraft-plugin/target/blackout-mc-bridge.jar
```

## Novidades (v3.2): sistema de parcerias + avisos com links

### Parcerias (`/parceria`)

Antes: o parceiro abria ticket e a staff montava e postava o anúncio na mão.
Agora o fluxo é automático e o anúncio sai padronizado e bonito:

1. A staff publica o painel uma vez: `/parceria painel` (no canal que quiser).
   O painel tem o texto de regras e o botão **🤝 Solicitar parceria**.
2. O parceiro clica no botão e preenche um formulário (nome, convite, descrição,
   banner opcional, observações pra staff). Só pode ter **um pedido em análise
   por vez**.
3. O bot **valida o convite de verdade no Discord**: rejeita convite inválido/
   expirado, convite do próprio servidor e servidor que já é parceiro (ou já tem
   pedido pendente). Ele lê o ícone e a contagem de membros/online do servidor.
4. O pedido cai no **canal de análise** da staff, com os números reais, um alerta
   se o nome digitado não bate com o nome real do servidor, e os botões
   **✅ Aprovar** / **❌ Recusar** (recusar pede um motivo opcional).
5. Aprovar publica o anúncio no **canal de divulgação** (embed com ícone, banner,
   membros, representante e botão **🚀 Entrar no servidor**), dá o cargo de
   parceiro ao representante e avisa ele por DM. Recusar também avisa por DM.

Configuração (grupo `configuracao`):

```
/parceria canal-divulgacao canal:#parcerias
/parceria canal-analise canal:#staff-parcerias
/parceria cargo-parceiro cargo:@Parceiro      (opcional; sem cargo = não dá cargo)
/parceria cargo-ping cargo:@Avisos-Parceria   (opcional; marcado em cada anúncio)
/parceria regras texto:"• Regra 1\n• Regra 2"
/parceria alternar ativo:true                 (liga os pedidos)
/parceria ver                                 (confere se está tudo configurado)
```

Uso da staff (grupo `parcerias`):

- `/parceria divulgar nome convite descricao [representante] [imagem]` — publica
  direto, sem formulário (útil quando a parceria foi combinada por fora).
- `/parceria listar` — parcerias ativas, com link pro anúncio.
- `/parceria remover id:ABC123` — encerra: apaga o anúncio e retira o cargo de
  parceiro (se o representante não tiver outra parceria ativa).
- `/parceria estatisticas` — ativas/pendentes/recusadas/removidas e ranking da staff.

**Importante:** é um grupo de permissão novo. Dê o grupo à sua staff:
`/permissao adicionar-cargo grupo:parcerias cargo:@Staff`.
O bot também precisa de permissão de **enviar mensagens e links incorporados**
nos dois canais.

### `/avisar` e `/embed` agora aceitam links

- `link:` + `botao:` criam um **botão clicável** (ex.: convite, site, loja);
  `link2:` + `botao2:` adicionam um segundo botão. `discord.gg/abc` sem
  `https://` também funciona.
- Dentro do texto, links em markdown funcionam: `[clique aqui](https://...)`.
- Novos opcionais: `imagem:` (banner grande), `cor:` (hex, ex.: `#ff8800`) e,
  no `/avisar`, `titulo:`.
- Links inválidos são recusados com mensagem clara, em vez de quebrar o comando.
- **AutoMod:** quem está no grupo `parcerias` (e o dono) pode postar convites e
  links no chat sem ser apagado. Antes, o anti-convite apagava a divulgação de
  parceiros postada na mão por qualquer um que não fosse cargo isento.

## Novidades desta atualização (v3.1)

Pedido do dono do projeto: melhorar tudo, consertar o `/avisar` (que não
mencionava ninguém), dar um jeito de setar nível/XP na mão, e permitir dar
cargo do Discord direto por uma opção de atributo (ex.: reino → cargo).
Resumo do que mudou:

- **`/avisar` consertado**: agora manda um embed bonito de verdade e
  **menciona** quem você escolher — `cargo:`, `usuario:`, `todos:true`
  (@everyone) ou `aqui:true` (@here). Só deixa mencionar @everyone/@here quem
  já tem essa permissão no servidor, pra ninguém abusar.
- **Cargo do Discord direto por atributo** — exatamente o pedido de
  `/atributo opção reino aethelgard cargo: ID_DO_CARGO`:
  ```
  /atributo opcao-cargo atributo:reino valor:Aethelgard cargo:@Aethelgard
  ```
  A partir daí, todo `/roletar atributo:reino` que cair em "Aethelgard" já
  dá o cargo `@Aethelgard` automaticamente pro jogador, e tira o cargo do
  valor anterior dele (não acumula). Pra remover a associação:
  `/atributo opcao-cargo-remover atributo:reino valor:Aethelgard`. Isso é
  **diferente** do `/cargo-automatico` (que manda comando de console pro
  Minecraft, ex.: LuckPerms) — os dois podem ser usados juntos, um cuida do
  cargo no Discord e o outro do grupo no Minecraft.
- **`/nivel-admin`** — seta nível/XP de qualquer jogador na mão, sem ele
  precisar mandar mensagem pra "grindar":
  `definir-xp`, `definir-nivel`, `adicionar-xp` (soma/subtrai) e `resetar`.
- **Administração extra**: `/slowmode`, `/lock`, `/unlock`, `/apelido`,
  `/limpar-usuario` (apaga só as mensagens de uma pessoa no canal).
- **Utilidade/diversão nova**: `/ping`, `/stats`, `/convite`, `/bola8`,
  `/moeda`, `/dado`, `/afk` (marca ausência e avisa quem te mencionar
  enquanto você tá fora), `/lembrete` (cria/lista/cancela lembretes
  pessoais) e `/sugestao` (canal de sugestões com 👍/👎 automático).
- **Plugin de Minecraft**: novo `/blackoutbridge status`, que testa a conexão
  com o bot e avisa na hora se `bot-url`/`secret` estão errados — antes só
  dava pra saber que tava errado olhando o log do servidor.
- **Nada foi apagado**: `data/blackout-community.json` continua exatamente o
  mesmo arquivo, todos os temas/perfis/configurações salvos foram
  preservados. Os campos novos (AFK, lembretes, cargo por atributo, etc.)
  têm valor padrão seguro pra bancos de dados antigos.
- Música ficou de fora de propósito, a pedido do dono do projeto.

A tabela de permissões abaixo e `bot/README.md` já refletem os comandos
novos.



O **dono permanente** do bot é o ID que já veio no projeto original — ele
sempre pode tudo e **nunca perde acesso**, nem por comando, nem sem querer.
Só ele usa `/permissao`.

Além do dono, existem 5 grupos de permissão configuráveis por cargo:

| Grupo | Comandos que controla |
|---|---|
| `rp` | `/tema`, `/atributo` (incl. `opcao-cargo`), `/giros`, `/perfil-admin` |
| `moderacao` | `/warn`, `/warnings`, `/mute`, `/unmute`, `/kick`, `/ban`, `/limpar`, `/cargo`, `/slowmode`, `/lock`, `/unlock`, `/apelido`, `/limpar-usuario` |
| `configuracao` | `/config`, `/automod`, `/nivel-cargo`, `/nivel-admin`, `/verificacao`, `/minecraft bridge-*`, `/cargo-automatico`, `/sugestao canal`/`alternar`, `/parceria` (canais, cargos, regras, alternar, ver) |
| `diversao` | `/sorteio`, `/comando-custom`, `/cargo-reacao`, `/embed`, `/avisar` |
| `parcerias` | `/parceria` (painel, divulgar, listar, remover, estatisticas) e os botões Aprovar/Recusar |

Comandos soltos de utilidade/diversão (`/ping`, `/stats`, `/bola8`, `/moeda`,
`/dado`, `/afk`, `/convite`, `/lembrete`, `/sugestao enviar`, `/rank`,
`/perfil`, `/roletar`) são públicos e não passam por nenhum grupo.

Exemplo: `/permissao adicionar-cargo grupo:rp cargo:@Staff-RP` — agora
`@Staff-RP` pode usar tudo do grupo `rp`, mas não vira admin geral. Um cargo
pode estar em vários grupos ao mesmo tempo.

## Trocar de tema de RP sem misturar dados antigos

Exemplo saindo de Medieval para Naruto (clã/vila/prodígio) e depois pra Dragon
Ball (raça/origem/linhagem):

```
/tema criar id:naruto nome:Naruto RP
/tema usar id:naruto
/atributo adicionar id:cla nome:Clã
/atributo adicionar id:vila nome:Vila
/atributo adicionar id:prodigio nome:Prodígio
/atributo opcao-adicionar atributo:cla valor:Uchiha
/atributo opcao-adicionar atributo:vila valor:Konoha
```

Cada opção começa com peso `10` (raridade "normal"). Pra deixar uma opção mais
rara ou mais comum na roleta:

```
/atributo opcao-raridade atributo:cla valor:Uchiha peso:2
```

Valores menores = mais raro; valores maiores = mais comum. Isso vale pra
qualquer atributo, incluindo o que for usado pelo cargo automático (ex.: reino).

Cada jogador tem um perfil **separado por tema** automaticamente — voltar ao
tema Naruto restaura o perfil Naruto de cada um, sem misturar com Dragon Ball.
Quando for encerrar de vez um tema antigo:

- `/perfil-admin limpar-tema id:naruto` — apaga só os perfis daquele tema
  (mesmo que não esteja mais ativo).
- `/perfil-admin limpar-todos` — apaga todos os perfis do tema **ativo** no
  momento.
- `/perfil-admin limpar-tudo` — apaga literalmente tudo, de todos os temas, de
  todos os jogadores (irreversível — use com cuidado).
- `/perfil-admin apagar usuario:@Fulano` — apaga só o perfil de uma pessoa no
  tema ativo.
- `/tema copiar origem:medieval novo-id:medieval2 novo-nome:"Medieval RP 2"` —
  duplica a estrutura de atributos de um tema pra outro, sem copiar perfis de
  jogador (todo mundo começa do zero no novo).

## Registro de conta e cargo automático (ex.: LuckPerms/reino)

Fluxo pensado pro tema medieval, mas funciona pra qualquer tema/atributo:

1. O jogador já se registrou normalmente no servidor de Minecraft (o plugin
   de login que você já usa, ex.: AuthMe — isso é externo a este projeto).
2. No Discord, o jogador usa `/registrar nick:SeuNickNoServidor` pra vincular
   a conta dele. Ele mesmo pode ver o vínculo com `/vinculo` e desfazer com
   `/desvincular`.
3. Um admin liga e configura o cargo automático (nada disso é fixo no código —
   tudo é configurável):

```
/cargo-automatico ativar ativo:true
/cargo-automatico atributo atributo:reino
/cargo-automatico comando modelo:"lp user %jogador% parent set %grupo%"
/cargo-automatico mapear valor:Eldoria grupo:reino_eldoria
/cargo-automatico mapear valor:Valoria grupo:reino_valoria
/cargo-automatico mapear valor:Astoria grupo:reino_astoria
```

A partir daí, toda vez que o atributo `reino` do jogador for definido (por
`/roletar atributo:reino`, ou de novo por um admin), o bot manda o plugin de
Minecraft executar o comando configurado — por padrão um comando do LuckPerms,
mas pode ser qualquer coisa, já que o modelo (`comando`) é livre. Use
`/cargo-automatico sincronizar usuario:@Fulano` pra forçar a sincronização de
alguém específico (ex.: depois de mudar um mapeamento), ou
`/cargo-automatico sincronizar-todos` pra todo mundo já vinculado de uma vez.
Veja `/cargo-automatico listar` para conferir a configuração atual.

O comando de console só chega até o plugin do Minecraft e só é executado se
`execute-remote-commands: true` estiver no `config.yml` dele (veja
`minecraft-plugin/README.md`).

## Lista completa de comandos

Veja `bot/README.md` para a lista detalhada com todos os subcomandos.

## Integração com o Minecraft

O bridge é **sob demanda, não automático** — pensado pra servidor 100% RP,
onde chat do Discord não pode vazar pro jogo (e vice-versa) sem alguém
decidir isso de propósito. Veja `minecraft-plugin/README.md` pro passo a
passo de configuração, a tabela explicando o que é automático (só
entrada/saída de jogador, e só aparece no Discord) versus o que é sob
demanda (`/minecraft anunciar` no Discord, `/discord` no jogo), e a
limitação real de rede que você precisa resolver com o seu host (a porta
HTTP do bot precisa ficar acessível para o servidor de Minecraft alcançar).
