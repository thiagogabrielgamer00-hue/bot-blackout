package br.blackout.mcbridge;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Um leitor/escritor de JSON minimalista, sem nenhuma dependência externa.
 * Existe só para este plugin não precisar empacotar uma biblioteca inteira de
 * JSON dentro do .jar — o protocolo do bridge é pequeno e simples o bastante
 * para isso ser seguro de fazer na mão.
 *
 * Suporta: objetos, arrays, strings (com escapes básicos), números, true/false/null.
 */
final class MiniJson {

    private MiniJson() {}

    // ---------------- escrita ----------------

    static String escape(String value) {
        if (value == null) return "";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"':
                    out.append("\\\"");
                    break;
                case '\\':
                    out.append("\\\\");
                    break;
                case '\n':
                    out.append("\\n");
                    break;
                case '\r':
                    out.append("\\r");
                    break;
                case '\t':
                    out.append("\\t");
                    break;
                default:
                    if (c < 0x20) {
                        out.append(String.format("\\u%04x", (int) c));
                    } else {
                        out.append(c);
                    }
                    break;
            }
        }
        return out.toString();
    }

    // ---------------- leitura ----------------

    @SuppressWarnings("unchecked")
    static Map<String, Object> parseObject(String json) {
        if (json == null || json.isBlank()) return new LinkedHashMap<>();
        Object result = new Parser(json).parseValue();
        if (result instanceof Map) return (Map<String, Object>) result;
        return new LinkedHashMap<>();
    }

    private static final class Parser {
        private final String text;
        private int pos = 0;

        Parser(String text) {
            this.text = text;
        }

        Object parseValue() {
            skipWhitespace();
            if (pos >= text.length()) return null;
            char c = text.charAt(pos);
            if (c == '{') return parseObject();
            if (c == '[') return parseArray();
            if (c == '"') return parseString();
            if (text.startsWith("true", pos)) {
                pos += 4;
                return Boolean.TRUE;
            }
            if (text.startsWith("false", pos)) {
                pos += 5;
                return Boolean.FALSE;
            }
            if (text.startsWith("null", pos)) {
                pos += 4;
                return null;
            }
            return parseNumber();
        }

        private Map<String, Object> parseObject() {
            Map<String, Object> map = new LinkedHashMap<>();
            pos++; // consome '{'
            skipWhitespace();
            if (peek() == '}') {
                pos++;
                return map;
            }
            while (true) {
                skipWhitespace();
                String key = parseString();
                skipWhitespace();
                if (peek() == ':') pos++;
                Object value = parseValue();
                map.put(key, value);
                skipWhitespace();
                char c = peek();
                if (c == ',') {
                    pos++;
                    continue;
                }
                if (c == '}') {
                    pos++;
                }
                break;
            }
            return map;
        }

        private List<Object> parseArray() {
            List<Object> list = new ArrayList<>();
            pos++; // consome '['
            skipWhitespace();
            if (peek() == ']') {
                pos++;
                return list;
            }
            while (true) {
                Object value = parseValue();
                list.add(value);
                skipWhitespace();
                char c = peek();
                if (c == ',') {
                    pos++;
                    continue;
                }
                if (c == ']') {
                    pos++;
                }
                break;
            }
            return list;
        }

        private String parseString() {
            skipWhitespace();
            if (peek() != '"') return "";
            pos++; // consome a aspas de abertura
            StringBuilder out = new StringBuilder();
            while (pos < text.length()) {
                char c = text.charAt(pos);
                if (c == '"') {
                    pos++;
                    break;
                }
                if (c == '\\' && pos + 1 < text.length()) {
                    char next = text.charAt(pos + 1);
                    switch (next) {
                        case 'n':
                            out.append('\n');
                            break;
                        case 'r':
                            out.append('\r');
                            break;
                        case 't':
                            out.append('\t');
                            break;
                        case '"':
                            out.append('"');
                            break;
                        case '\\':
                            out.append('\\');
                            break;
                        case '/':
                            out.append('/');
                            break;
                        case 'u':
                            if (pos + 6 <= text.length()) {
                                String hex = text.substring(pos + 2, pos + 6);
                                out.append((char) Integer.parseInt(hex, 16));
                                pos += 4;
                            }
                            break;
                        default:
                            out.append(next);
                            break;
                    }
                    pos += 2;
                } else {
                    out.append(c);
                    pos++;
                }
            }
            return out.toString();
        }

        private Object parseNumber() {
            int start = pos;
            while (pos < text.length() && "-+.0123456789eE".indexOf(text.charAt(pos)) >= 0) pos++;
            String number = text.substring(start, pos);
            if (number.isEmpty()) {
                pos++;
                return null;
            }
            try {
                return Double.parseDouble(number);
            } catch (NumberFormatException e) {
                return null;
            }
        }

        private void skipWhitespace() {
            while (pos < text.length() && Character.isWhitespace(text.charAt(pos))) pos++;
        }

        private char peek() {
            return pos < text.length() ? text.charAt(pos) : '\0';
        }
    }
}
