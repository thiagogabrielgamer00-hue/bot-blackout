package br.blackout.mcbridge;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Fala HTTP puro (java.net.HttpURLConnection) com o bot, sem nenhuma biblioteca externa.
 * Propositalmente NÃO usa java.net.http.HttpClient porque essa API só existe a partir
 * do Java 11, e alguns servidores antigos (1.7.10, 1.8...) ainda rodam em Java 8.
 */
final class BridgeClient {

    private String botUrl;
    private String secret;
    private final Logger logger;

    BridgeClient(String botUrl, String secret, Logger logger) {
        this.botUrl = normalize(botUrl);
        this.secret = secret;
        this.logger = logger;
    }

    void updateCredentials(String botUrl, String secret) {
        this.botUrl = normalize(botUrl);
        this.secret = secret;
    }

    private static String normalize(String url) {
        if (url == null) return "";
        return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }

    void sendEvent(String type, String player, String message) {
        if (botUrl.isEmpty()) return;
        try {
            StringBuilder json = new StringBuilder("{");
            json.append("\"type\":\"").append(MiniJson.escape(type)).append("\",");
            json.append("\"player\":\"").append(MiniJson.escape(player)).append("\"");
            if (message != null) {
                json.append(",\"message\":\"").append(MiniJson.escape(message)).append("\"");
            }
            json.append("}");

            HttpURLConnection connection = (HttpURLConnection) new URL(botUrl + "/event").openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setConnectTimeout(4000);
            connection.setReadTimeout(4000);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("X-Bridge-Secret", secret);
            byte[] body = json.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(body);
            }
            drain(connection);
        } catch (Exception e) {
            logger.log(Level.WARNING, "Não consegui enviar evento para o bot: " + e.getMessage());
        }
    }

    /** Testa a conexão com o bot fazendo um /poll simples. Usado por /blackoutbridge status. */
    boolean testConnection() {
        return poll(0L) != null;
    }

    PollResult poll(long since) {
        if (botUrl.isEmpty()) return null;
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(botUrl + "/poll?since=" + since).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(4000);
            connection.setReadTimeout(4000);
            connection.setRequestProperty("X-Bridge-Secret", secret);
            String body = readAll(connection);
            Map<String, Object> json = MiniJson.parseObject(body);
            PollResult result = new PollResult();
            Object now = json.get("now");
            result.serverNow = now instanceof Number ? ((Number) now).longValue() : since;
            Object messagesRaw = json.get("messages");
            if (messagesRaw instanceof List) {
                for (Object item : (List<?>) messagesRaw) {
                    if (!(item instanceof Map)) continue;
                    @SuppressWarnings("unchecked")
                    Map<String, Object> map = (Map<String, Object>) item;
                    DiscordMessage message = new DiscordMessage();
                    message.author = String.valueOf(map.getOrDefault("author", "?"));
                    message.content = String.valueOf(map.getOrDefault("content", ""));
                    result.messages.add(message);
                }
            }
            Object commandsRaw = json.get("commands");
            if (commandsRaw instanceof List) {
                for (Object item : (List<?>) commandsRaw) {
                    if (!(item instanceof Map)) continue;
                    @SuppressWarnings("unchecked")
                    Map<String, Object> map = (Map<String, Object>) item;
                    Object command = map.get("command");
                    if (command != null) result.commands.add(String.valueOf(command));
                }
            }
            return result;
        } catch (Exception e) {
            logger.log(Level.FINE, "Não consegui consultar o bot (bridge offline?): " + e.getMessage());
            return null;
        }
    }

    private static void drain(HttpURLConnection connection) throws IOException {
        InputStream in = connection.getResponseCode() < 400 ? connection.getInputStream() : connection.getErrorStream();
        if (in == null) return;
        try {
            byte[] buffer = new byte[512];
            while (in.read(buffer) != -1) {
                // só precisamos consumir a resposta para a conexão poder ser reutilizada
            }
        } finally {
            in.close();
        }
    }

    private static String readAll(HttpURLConnection connection) throws IOException {
        InputStream in = connection.getResponseCode() < 400 ? connection.getInputStream() : connection.getErrorStream();
        if (in == null) return "";
        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        try {
            byte[] chunk = new byte[512];
            int read;
            while ((read = in.read(chunk)) != -1) {
                buffer.write(chunk, 0, read);
            }
        } finally {
            in.close();
        }
        return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
    }

    static final class PollResult {
        long serverNow;
        List<DiscordMessage> messages = new ArrayList<>();
        List<String> commands = new ArrayList<>();
    }

    static final class DiscordMessage {
        String author;
        String content;
    }
}
