package br.blackout.mcbridge;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;

/**
 * Plugin universal de ponte com o Discord. Usa só API básica do Bukkit
 * (ver comentário no pom.xml) para funcionar sem recompilar do 1.7.10 ao 1.21.1.
 *
 * IMPORTANTE: isto NÃO espelha o chat do servidor automaticamente. Servidor 100% RP
 * precisa que nada "vaze" sozinho entre o jogo e o Discord. Por isso:
 *   - Entrada/saída de jogador: opcional, só aparece no Discord (nunca dentro do jogo).
 *   - Do Discord pro jogo: só quando um administrador usa /minecraft anunciar no Discord.
 *   - Do jogo pro Discord: só quando um jogador usa /discord <mensagem>, de propósito.
 * Nenhuma fala normal do chat do jogo é enviada automaticamente para lugar nenhum.
 */
public final class BlackoutBridgePlugin extends JavaPlugin implements Listener, CommandExecutor {

    private BridgeClient client;
    private long lastPollTimestamp = 0L;
    private final Map<String, Long> lastDiscordCommandUse = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadConfig();

        String botUrl = getConfig().getString("bot-url", "");
        String secret = getConfig().getString("secret", "");
        if (botUrl.isEmpty() || botUrl.contains("SEU_HOST_DO_BOT") || secret.contains("COLE_AQUI")) {
            getLogger().warning("Configure bot-url e secret em plugins/BlackoutBridge/config.yml antes de usar. "
                    + "Pegue os valores com /minecraft bridge-info no Discord.");
        }

        client = new BridgeClient(botUrl, secret, getLogger());

        Bukkit.getPluginManager().registerEvents(this, this);
        if (getCommand("blackoutbridge") != null) {
            getCommand("blackoutbridge").setExecutor(this);
        }
        if (getCommand("discord") != null) {
            getCommand("discord").setExecutor(this);
        }

        int intervalSeconds = getConfig().getInt("poll-interval-seconds", 3);
        long intervalTicks = Math.max(20L, intervalSeconds * 20L);
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, this::pollDiscordAnnouncements, intervalTicks, intervalTicks);

        getLogger().info("BlackoutBridge ativo. Nada de chat é espelhado automaticamente — "
                + "só avisos deliberados via /minecraft anunciar (Discord) e /discord (jogo).");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!getConfig().getBoolean("relay-join", true)) return;
        String playerName = event.getPlayer().getName();
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> client.sendEvent("join", playerName, null));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (!getConfig().getBoolean("relay-leave", true)) return;
        String playerName = event.getPlayer().getName();
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> client.sendEvent("leave", playerName, null));
    }

    /**
     * Consulta o bot por AVISOS DELIBERADOS criados com /minecraft anunciar, e também
     * por comandos de console enfileirados pelo cargo automático (ex.: LuckPerms) — nada
     * disso é automático/espelhado, só o que foi explicitamente configurado no Discord.
     */
    private void pollDiscordAnnouncements() {
        BridgeClient.PollResult result = client.poll(lastPollTimestamp);
        if (result == null) return;
        lastPollTimestamp = result.serverNow;

        if (!result.messages.isEmpty()) {
            String format = getConfig().getString("discord-to-minecraft-format", "§c§l[AVISO] §r§f%player%: %message%");
            Bukkit.getScheduler().runTask(this, () -> {
                for (BridgeClient.DiscordMessage message : result.messages) {
                    String line = ChatColor.translateAlternateColorCodes('&',
                            format.replace("%player%", message.author).replace("%message%", message.content));
                    Bukkit.broadcastMessage(line);
                }
            });
        }

        if (!result.commands.isEmpty() && getConfig().getBoolean("execute-remote-commands", true)) {
            Bukkit.getScheduler().runTask(this, () -> {
                for (String command : result.commands) {
                    getLogger().info("Executando comando remoto vindo do Discord (cargo automático): " + command);
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
                }
            });
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if ("discord".equalsIgnoreCase(command.getName())) {
            return handleDiscordCommand(sender, args);
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            client.updateCredentials(getConfig().getString("bot-url", ""), getConfig().getString("secret", ""));
            sender.sendMessage(ChatColor.GREEN + "[BlackoutBridge] Configuração recarregada.");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("status")) {
            sender.sendMessage(ChatColor.YELLOW + "[BlackoutBridge] Testando conexão com o bot...");
            Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
                boolean ok = client.testConnection();
                Bukkit.getScheduler().runTask(this, () -> sender.sendMessage(ok
                        ? ChatColor.GREEN + "[BlackoutBridge] Conectado com sucesso ao bot."
                        : ChatColor.RED + "[BlackoutBridge] Não consegui falar com o bot. Confira bot-url e secret "
                                + "em config.yml (pegue os valores certos com /minecraft bridge-info no Discord)."));
            });
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "[BlackoutBridge] Ponte com o Discord ativa (sem espelho automático de chat). "
                + "Configure em plugins/BlackoutBridge/config.yml. Use /blackoutbridge reload para recarregar ou "
                + "/blackoutbridge status para testar a conexão.");
        return true;
    }

    private boolean handleDiscordCommand(CommandSender sender, String[] args) {
        if (!getConfig().getBoolean("discord-command-enabled", true)) {
            sender.sendMessage(ChatColor.RED + "O comando /discord está desativado neste servidor.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(ChatColor.YELLOW + "Uso: /discord <mensagem>");
            return true;
        }
        if (sender instanceof Player) {
            String key = sender.getName();
            long now = System.currentTimeMillis();
            long cooldownMillis = getConfig().getInt("discord-command-cooldown-seconds", 10) * 1000L;
            Long last = lastDiscordCommandUse.get(key);
            if (last != null && now - last < cooldownMillis) {
                long waitSeconds = (cooldownMillis - (now - last)) / 1000L + 1;
                sender.sendMessage(ChatColor.RED + "Aguarde " + waitSeconds + "s para usar /discord de novo.");
                return true;
            }
            lastDiscordCommandUse.put(key, now);
        }
        String message = String.join(" ", args);
        String playerName = sender.getName();
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> client.sendEvent("chat", playerName, message));
        sender.sendMessage(ChatColor.GREEN + "Mensagem enviada para a equipe no Discord.");
        return true;
    }
}
